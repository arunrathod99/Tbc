/*
 * Copyright (c) 2018-2024 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */

import Settings.{vasapiSettings, integrationTestSettings}
import Package.packageSettings
import Tasks.{
  debugLogFilePubTask,
  installGenTask,
  installPubTask,
  logFileGenTask,
  logFilePubTask,
  resourceGenTask,
  resourcePubTask
}

lazy val vasapi = (project in file("."))
  .enablePlugins(
    ParadoxPlugin,
    SitePreviewPlugin,
    ParadoxSitePlugin,
    Tasks,
    ScalaUnidocPlugin)
  .settings(
    vasapiSettings,
    packageSettings,
    name := "vasapi",
    semanticdbEnabled := true,
    semanticdbVersion := scalafixSemanticdb.revision
  )

lazy val it = (project in file("integrationTests"))
  .settings(
    integrationTestSettings
  )
  .dependsOn(vasapi % "compile->compile;test->test")

enablePlugins(ParadoxPlugin)
enablePlugins(SitePreviewPlugin, ParadoxSitePlugin)
enablePlugins(Tasks)
enablePlugins(ScalaUnidocPlugin)
enablePlugins(ScoverageSbtPlugin)
enablePlugins(ScalafixPlugin)

credentials += Credentials(Path.userHome / ".sbt" / ".credentials")

(Compile / compile) := {
  ((Compile / compile) dependsOn resourceGenTask).value
  ((Compile / compile) dependsOn installGenTask).value
  ((Compile / compile) dependsOn logFileGenTask).value
  (Compile / compile).value
}

addArtifact(Artifact("resources_tar", "zip", "gz"), resourcePubTask)
addArtifact(Artifact("installer_tar", "zip", "gz"), installPubTask)
addArtifact(Artifact("logback", "xml", "xml"), logFilePubTask)
addArtifact(Artifact("logback_debug", "xml", "xml"), debugLogFilePubTask)

publishConfiguration := publishConfiguration.value.withOverwrite(true)
publishLocalConfiguration := publishLocalConfiguration.value.withOverwrite(true)
