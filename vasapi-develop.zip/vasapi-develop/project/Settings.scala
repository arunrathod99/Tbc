/*
 *  Copyright (c) 2023 Robert Bosch GmbH and its subsidiaries.
 *  This program and the accompanying materials are made available under
 *  the terms of the Bosch Internal Open Source License v4
 *  which accompanies this distribution, and is available at
 *  http://bios.intranet.bosch.com/bioslv4.txt
 */

import Dependencies.*
import com.lightbend.paradox.sbt.ParadoxPlugin.autoImport.*
import com.typesafe.sbt.site.SitePlugin.autoImport.{
  makeSite,
  siteSourceDirectory,
  siteSubdirName
}
import com.typesafe.sbt.site.SiteScaladocPlugin.autoImport.SiteScaladoc
import sbt.Keys.{mappings, *}
import sbt.{Def, *}
import scoverage.ScoverageKeys.{
  coverageDataDir,
  coverageEnabled,
  coverageExcludedFiles
}

/** Definition of settings for build instances
  *
  * All project related settings are set here
  */
object Settings {

  /** General project related startup configuration
    *
    * Operations are only executed during startup process
    */
  lazy private val startupSettings = Seq(
    Global / onLoad := {
      val old = (Global / onLoad).value
      val startupTransition: State => State = { s: State => "writeHooks" :: s }
      startupTransition compose old
    }
  )

  /** General project related configuration
    *
    * Define common project related properties
    */
  lazy private val baseSettings = Seq(
    organization := "com.bosch.asc",

    /** General Scala configuration
      *
      * Define scala/scalac options
      *
      * scalaVersion: scala version to be used in the project scalacOptions:
      * scala compiler settings doc / scalacOptions: scala compiler options for
      * scaladoc creation
      */
    scalaVersion := "2.12.15", // Change also in Dependencies.scala
    scalacOptions := Seq(
      // warnings are reported as errors
      "-Xfatal-warnings",
      // linting options
      "-unchecked",
      "-feature",
      "-deprecation",
      "-encoding",
      "UTF-8",
      "-Xlint",
      "-Xmacro-settings:materialize-derivations",
      "-Ywarn-dead-code",
      "-Ywarn-numeric-widen",
      "-Ywarn-value-discard",
      "-Ywarn-adapted-args"
    ),
    Compile / doc / scalacOptions := Seq(
      "-diagrams",
      "-groups",
      "-implicits",
      "-no-link-warnings"
    ),
    Compile / unmanagedResourceDirectories += baseDirectory.value / "examples",
    autoAPIMappings := true
  )

  /** add additional resolvers here if needed (e.g. for Bosch-internal
    * dependency resolution)
    */
  lazy private val addResolvers = Seq(
    // TODO: PJASC-10257
    resolvers += "bidos" at "https://artifactory.boschdevcloud.com/artifactory/asc-de-generic-local/",
    resolvers += "cloudera-remote" at "https://artifactory.boschdevcloud.com/artifactory/cloudera-maven-remote/",

    // resolve androidx.annotation, required since Spark 3.3
    resolvers += "maven-google" at "https://maven.google.com/"
  )

  /** Test configuration
    *
    * Define the settings only applied for testing.
    *
    * fork: Test task need to be forked into new JVM to activate test-only JVM
    * options parallelExecution: Run tests sequentially to easily spot failed
    * tests logBuffered: Disable the buffered logging for each test source.
    * javaOptions: Additional JVM options used only for testing (note that
    * sequence needs to be appended).
    */
  lazy private val testSettings = Seq(
    Test / fork := true,
    Test / parallelExecution := false,
    Test / logBuffered := false,
    Test / unmanagedResourceDirectories += baseDirectory.value / "examples",
    Test / javaOptions ++= Seq(
      "-Xms1G",
      "-Xmx8G",
      "-XX:+CMSClassUnloadingEnabled"
    )
  )

  lazy val vasapiParadoxSettings: Seq[Def.Setting[?]] = Seq(
    makeSite / mappings ++= Seq(
      file("LICENSE") -> "LICENSE",
      file("src/assets/favicon.ico") -> "favicon.ico"
    ),
    paradoxProperties ++= Map(
      "extref.rfc.base_url" -> "https://tools.ietf.org/html/rfc%s"
    ),
    paradoxTheme := Some(builtinParadoxTheme("generic")),
    paradox / sourceDirectory := sourceDirectory.value / "src" / "main" / "paradox",
    paradoxOverlayDirectories := Seq(
      baseDirectory.value / "src" / "main" / "paradox"
    ),
    paradoxIllegalLinkPath := raw".*\.md".r,
    paradoxRoots := Seq("index.html", "code-coverage-results.html").toList,
    Compile / paradoxProperties ++= Map(
      "scaladoc.com.example.package_name_style" -> s"startWithAnycase",
      "extref.rfc.base_url" -> "http://tools.ietf.org/html/rfc%s",
      "scaladoc.akka.base_url" -> "http://doc.akka.io/api/akka/2.4.10",
      "scaladoc.akka.http.base_url" -> "http://doc.akka.io/api/akka-http/10.0.0",
      "project.url" -> "https://developer.lightbend.com/docs/paradox/current/",
      "canonical.base_url" -> "https://developer.lightbend.com/docs/paradox/current/"
    ),
    SiteScaladoc / siteSubdirName := Seq(
      baseDirectory.value / "src" / "main" / "paradox"
    ).toString()
  )

  lazy val commonSettings: Seq[Def.Setting[?]] =
    baseSettings ++ testSettings ++ addResolvers ++
      Seq(
        libraryDependencies ++= vasapiDependencies ++ coreDependencies,
        dependencyOverrides ++= fixedDependencies,
        excludeDependencies ++= excludedDependencies
      )

  lazy val coverageSettings: Seq[Def.Setting[?]] = Seq(
    Test / coverageEnabled := true,
    coverageExcludedFiles := "target/.*;project/.*;./*.;api/.*;pipelines/.*;.github/.*;sbom/.*;"
  )

  /** Configuration of the VASAPI project
    *
    * Use all common project related properties
    */
  lazy val vasapiSettings: Seq[Def.Setting[?]] =
    commonSettings ++ testSettings ++ integrationTestSettings ++ addResolvers ++ vasapiParadoxSettings ++ coverageSettings ++
      Seq(
        libraryDependencies ++= vasapiDependencies ++ coreDependencies ++ testDependencies,
        dependencyOverrides ++= fixedDependencies,
        excludeDependencies ++= excludedDependencies
      )

  /** Configuration of the integrationTests sub-project
    *
    * Use all common project related properties
    */
  lazy val integrationTestSettings: Seq[Def.Setting[?]] =
    commonSettings ++ testSettings

}
