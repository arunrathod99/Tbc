addSbtPlugin("com.github.sbt" % "sbt-site-paradox" % "1.5.0")
addSbtPlugin("com.lightbend.paradox" % "sbt-paradox-theme" % "0.10.5")
