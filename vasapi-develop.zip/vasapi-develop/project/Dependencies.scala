/*
 * Copyright (c) 2018-2024 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */

import sbt.*
import scala.language.postfixOps

/** sbt dependencies for all (sub-)projects defined in build.sbt
  */
object Dependencies {

  /** build parameters
    *
    * Define general versions of used libraries
    */
  private val scalaVersion: String = "2.12.15" // Change also in Settings.scala
  private val hadoopVersion: String = "3.1.1.7.1.9.7-2" // CDP 7.1.9
  private val sparkOSSVersion: String = "3.3.2"
  private val clouderaExtension = "3.3.7191000.0-78" // CDP 7.1.9
  private val sparkVersion = s"$sparkOSSVersion.$clouderaExtension"
  private val solaceJMSApiVersion: String = "10.24.1"
  private val icebergOSSVersion: String = "1.3.0"
  private val sparkVersionPrefix = "3.3"
  private val icebergVersion = s"$icebergOSSVersion.$clouderaExtension"

  /** Core dependencies - Spark
    *
    * [[sparkCore]]: Apache Spark core features
    * [[sparkSql]]: Apache Spark SQL features
    * [[sparkStreaming]]: Apache Spark Structured Streaming features
    * [[sparkKafka]]: Spark kafka integration
    * [[sparkHive]]: Spark Hive integration
    * [[sparkAvro]]: Spark Avro integration
    */
  private val sparkCore: ModuleID =
    "org.apache.spark" %% "spark-core" % sparkVersion
  private val sparkSql: ModuleID =
    "org.apache.spark" %% "spark-sql" % sparkVersion
  private val sparkStreaming: ModuleID =
    "org.apache.spark" %% "spark-streaming" % sparkVersion
  private val sparkKafka: ModuleID =
    "org.apache.spark" %% "spark-sql-kafka-0-10" % sparkVersion
  private val sparkHive: ModuleID =
    "org.apache.spark" %% "spark-hive" % sparkVersion
  private val sparkAvro: ModuleID =
    "org.apache.spark" %% "spark-avro" % sparkVersion

  /** Core dependencies - Vasapi
    *
    * all core dependencies other than Spark
    *
    * [[pureConfig]]: Configuration library based on the standard configuration
    * factory
    * [[solace4Spark]]: Solace interface for Spark Structured Streaming
    * [[scalaCompiler]]: Scala compiler for runtime compilation
    * [[scalactic]]: Used for functional error handling
    * [[everit]]: used for JSON schema validation
    * [[json4sXML]]: JSON4s XML support
    * factory [[solace4Spark]]: Solace interface for Spark Structured Streaming
    * [[scalaCompiler]]: Scala compiler for runtime compilation dependent on the
    * Play framework
    */
  private val pureConfig: ModuleID =
    "com.github.pureconfig" %% "pureconfig" % "0.15.0"
  private val solace4Spark: ModuleID =
    "com.bosch.asc" %% "solace-source-sink" % "2.1.1"
  private val scalaCompiler: ModuleID =
    "org.scala-lang" % "scala-compiler" % scalaVersion
  private val scalactic: ModuleID = "org.scalactic" %% "scalactic" % "3.2.18"
  private val everit: ModuleID =
    "org.everit.json" % "org.everit.json.schema" % "1.5.1"
  // versions > 4.0.0 lead to stackoverflow during compilation
  private val json4sXML: ModuleID = "org.json4s" %% "json4s-xml" % "3.6.12"
  private val databricksDButils: ModuleID = "com.databricks" %% "databricks-dbutils-scala" % "0.1.4"

  /** Common and integration test only dependencies
    *
    * [[scalaTest]]: Scala library for common and integration tests
    * [[scalaMock]]: Scala mocking framework [[scalaMockito]]: Scala wrapper
    * around Java's mockito library [[sparkTest]]: Spark testing base with data
    * frame comparison, requires JVM resource adaptions in testing.
    * [[embeddedKafka]]: In-memory Kafka instance convenient for unit /
    * integration tests
    * [[icebergSparkRuntime]]: Spark Iceberg integration
   * [[icebergHiveRuntime]]: Iceberg Hive integration
   */
  private val scalaTest: ModuleID = "org.scalatest" %% "scalatest" % "3.2.18"
  private val scalaMock: ModuleID = "org.scalamock" %% "scalamock" % "6.0.0"
  private val scalaMockito: ModuleID = "org.mockito" %% "mockito-scala" % "1.17.31"
  private val sparkTest: ModuleID = "com.holdenkarau" %% "spark-testing-base" % s"${sparkOSSVersion}_1.5.3"
  private val embeddedKafka: ModuleID = "io.github.embeddedkafka" %% "embedded-kafka" % "3.9.0"
  private val hadoopCore: ModuleID = "org.apache.hadoop" % "hadoop-common" % hadoopVersion
  private val icebergSparkRuntime: ModuleID =
    "org.apache.iceberg" % "iceberg-spark-runtime-3.3_2.12" % s"1.3.0.$clouderaExtension"
  private val icebergHiveRuntime: ModuleID =
    "org.apache.iceberg" % "iceberg-hive-runtime" % s"1.3.0.$clouderaExtension"

  // log dependencies
  private val log4jApi: ModuleID =
    "org.apache.logging.log4j" % "log4j-api" % "2.18.0"
  private val logToSlf4j: ModuleID =
    "org.apache.logging.log4j" % "log4j-to-slf4j" % "2.18.0"
  private val logback: ModuleID =
    "ch.qos.logback" % "logback-classic" % "1.2.13"
  private val logstashLogbackEncoder: ModuleID =
    "net.logstash.logback" % "logstash-logback-encoder" % "7.3"
  private val apacheAvro: ModuleID = "org.apache.avro" % "avro" % "1.11.4"
  private val scalaXML: ModuleID =
    "org.scala-lang.modules" %% "scala-xml" % "2.2.0"

  /** Module specific dependencies to allow a flexible usage of the libraries
    * and to handle dependency conflicts better.
    *
    * [[coreDependencies]]: Selected and filtered libraries for the core module.
    * [[vasapiDependencies]]: Selected and filtered libraries for vasapi.
    * [[excludedDependencies]]: Dependencies which shall be excluded from all
    * modules [[fixedDependencies]]: Fix versions of modules which are used by
    * different dependencies but in different versions
    */
  val coreDependencies: Seq[ModuleID] = Seq(sparkSql % "provided") ++
    Seq(sparkCore % "provided") ++
    Seq(sparkSql % "provided") ++
    Seq(sparkHive % "provided") ++
    Seq(sparkStreaming % "provided") ++
    Seq(sparkKafka % "provided") ++
    Seq(sparkAvro % "provided")

  val vasapiDependencies: Seq[ModuleID] = Seq(solace4Spark) ++
    Seq(pureConfig) ++
    Seq(scalaCompiler) ++
    Seq(json4sXML) ++
    Seq(scalaXML) ++
    Seq(scalactic) ++
    Seq(logToSlf4j) ++
    Seq(log4jApi) ++
    Seq(logback) ++
    Seq(logstashLogbackEncoder) ++
    Seq(everit) ++
    Seq(embeddedKafka) ++
    Seq(databricksDButils)

  val testDependencies: Seq[ModuleID] = Seq(scalaTest % "test") ++
    Seq(sparkTest % "test") ++
    Seq(hadoopCore % "test") ++
    Seq(scalaMock % "test") ++
    Seq(scalaMockito % "test") ++
    Seq(icebergSparkRuntime % "test") ++
    Seq(icebergHiveRuntime % "test")

  val excludedDependencies: Seq[ExclusionRule] = Seq(
    // ExclusionRule(organization = "*",name = "log4j-core"),
    ExclusionRule(organization = "*", name = "slf4j-log4j12"),
    ExclusionRule(
      organization = "com.sksamuel.scapegoat",
      name = "scalac-scapegoat-plugin_2.12"
    )
  )

  val fixedDependencies: Seq[ModuleID] = Seq(
    apacheAvro,
    scalaXML
  )
}
