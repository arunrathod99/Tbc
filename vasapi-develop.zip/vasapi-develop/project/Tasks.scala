/*
 * Copyright (c) 2018-2024 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */

import sbt.Keys.streams
import sbt.{AutoPlugin, taskKey, Def, IO}

import scala.sys.process.*
import java.io.*

object Tasks extends AutoPlugin {

  // Create a custom task to generate the resource file that contains configuration files
  lazy val resourceGenTask = taskKey[Unit]("Generate Resources.tar.gz")
  // Create a custom task to generate the install file that contains start & stop scripts
  lazy val installGenTask = taskKey[Unit]("Generate Installer.tar.gz")
  // Create a custom task to generate the resource file that contains logback file
  lazy val logFileGenTask = taskKey[Unit]("Generate logback.xml")
  // Add the resource file to artifact repository
  lazy val resourcePubTask = taskKey[File]("Return the resource file")
  // Add the resource file to artifact repository
  lazy val installPubTask = taskKey[File]("Return the installation file")
  // Add the logback file to artifact repository
  lazy val logFilePubTask = taskKey[File]("Return the logback file")
  // Add the logback file to artifact repository
  lazy val debugLogFilePubTask = taskKey[File]("Return the logback debug file")

  override def projectSettings: Seq[Def.Setting[?]] = Seq(
    resourceGenTask := {
      val logger = streams.value.log
      IO.createDirectory(new File("target/pipelines/"))
      IO.copyDirectory(new File("pipelines/"), new File("target/pipelines/"))
      Process(
        "tar pczf target/resources.tar.gz target/pipelines"
      ) ! logger match {
        case 0 => // Ok
        case n =>
          sys.error(s"Could not create target/resources.tar.gz, exit code: $n")
      }
    },
    installGenTask := {
      val logger = streams.value.log
      IO.createDirectory(new File("target/api/"))
      IO.copyDirectory(new File("api/"), new File("target/api"))

      Process("tar pczf target/installer.tar.gz target/api") ! logger match {
        case 0 => // Ok
        case n =>
          sys.error(s"Could not create target/installer.tar.gz, exit code: $n")
      }
    },
    logFileGenTask := {
      try {
        IO.copyFile(
          new File("src/main/resources/logback.xml"),
          new File("target/logback.xml")
        )
        IO.copyFile(
          new File("src/main/resources/logback_debug.xml"),
          new File("target/logback_debug.xml")
        )
      } catch {
        case ex: IOException =>
          sys.error(
            s"Could not create target/logback.xml and target/logback_debug.xml, exit code: $ex"
          )
      }
    },
    resourcePubTask := new File("target/resources.tar.gz"),
    installPubTask := new File("target/installer.tar.gz"),
    logFilePubTask := new File("target/logback.xml"),
    debugLogFilePubTask := new File("target/logback_debug.xml")
  )
}
