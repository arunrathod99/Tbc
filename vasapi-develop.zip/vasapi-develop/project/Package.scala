/*
 * > Copyright (c) 2009, 2018 Robert Bosch GmbH and its subsidiaries.
 * > This program and the accompanying materials are made available under
 * > the terms of the Bosch Internal Open Source License v4
 * > which accompanies this distribution, and is available at
 * > http://bios.intranet.bosch.com/bioslv4.txt
 */

import sbt.Keys.*
import sbt.{Credentials, Def, *}
import sbtassembly.AssemblyPlugin.autoImport.*
import sbtrelease.ReleasePlugin.autoImport

object Package {
  lazy val packageSettings: Seq[Def.Setting[?]] = Seq(

    /** sbt-assembly plugin configuration
      *
      * Configuration for creating assemblies/fat/uber jars
      *
      * Prerequisite: {{{import sbtassembly.AssemblyPlugin.autoImport.*}}}
      *
      */
    // assembly / assemblyOption := (assembly / assemblyOption).value.copy(includeScala = false),
    assembly / assemblyJarName := s"${name.value}.jar",

    // avoid errors due to duplicate files in assembly
    assembly / assemblyMergeStrategy := {
      case PathList("META-INF", xs*) => MergeStrategy.discard
      case x if x.endsWith("module-info.class") => MergeStrategy.discard
      case x =>
        val oldStrategy = (assembly / assemblyMergeStrategy).value
        oldStrategy(x)
    },

    /** Publish configuration
      *
      * Publish configuration sets implicit definition to be used with
      * `UniversalDeployPlugin` as well as the dependency on universal:publish
      *
      * Enable plugin in build.sbt per project via
      * {{{enablePlugins(UniversalDeployPlugin)}}}
      *
      *   publishArtifact: Boolean flag to decide if artifact is published
      *   publishTo: Defines publishTo tasks target repositories
      */

    homepage := Some(url("https://github.boschdevcloud.com/bios-asc/vasapi")),
    publish / skip := false,
    ThisBuild / publishTo := Some(
      "Artifactory Realm" at "https://artifactory.boschdevcloud.com/artifactory/asc-de-generic-local/"
    ),
    autoImport.releaseIgnoreUntrackedFiles := true,
    credentials += Credentials(Path.userHome / ".sbt" / ".credentials"),
    publishMavenStyle := true,
    ThisBuild / versionScheme := Some("early-semver"),
    scmInfo := Some(
      ScmInfo(
        url("https://github.boschdevcloud.com/bios-asc/vasapi"),
        "scm:git:ssh://git@github.boschdevcloud.com/bios-asc/vasapi.git"
      )
    ),
    licenses := Seq(
      "Bosch Internal Open Source License v4" -> url(
        "http://bios.intranet.bosch.com/bioslv4.txt"
      )
    )
  )
}
