<!---

	Copyright (c) 2016, 2023 Robert Bosch GmbH and its subsidiaries.
	This program and the accompanying materials are made available under
	the terms of the Bosch Internal Open Source License v4
	which accompanies this distribution, and is available at
	http://bios.intranet.bosch.com/bioslv4.txt

-->

<div style="text-align:left"><img src="vasapi.png" /></div>

## <a name="vasapi">vasapi</a>

* [About](#about)
* [Maintainers](#maintainers)
* [License](#license)
* [How to use it](#use)
* [How to build and test it](#build)
* [Coverage Data](#coveragedata)
* [How to contribute](#contribute)
* [Used 3rd party Licenses](#licenses)
* [Used encryption](#encryption)
* [Feedback](#feedback)

## <a name="about">About</a>

This repository contains all code related to the unified data pipeline for complete
value streams or **VA**lue-**S**tream-d**A**ta-**PI**peline in short VASAPI.
Use is only allowed internally of the Robert Bosch group.

More information can be found in the [documentation](https://pages.github.boschdevcloud.com/bios-asc/vasapi/)

## <a name="maintainers">Maintainers</a>

* [Andreas Kreitschmann (AE/MSD-DAP)](mailto:andreas.kreitschmann@de.bosch.com)
* [Sanjay Kumar Sahu (AE/MSD-DAP-IN)](mailto:SanjayKumar.Sahu@bosch.com)
* [Gururajan Sinduja (ME/MSD-DAP-IN)](mailto:sinduja.gururajan@bosch.com)

## <a name="license">License</a>

>	Copyright (c) 2024 Robert Bosch GmbH and its subsidiaries.
>	This program and the accompanying materials are made available under
>	the terms of the Bosch Internal Open Source License v4
>	which accompanies this distribution, and is available at
>	http://bios.intranet.bosch.com/bioslv4.txt

## <a name="use">How to use it</a>

Refer to the [documentation](https://pages.github.boschdevcloud.com/bios-asc/vasapi/) for more information.
Although vasapi is mostly written in Scala, you do not need to write any Scala code to build vasapi pipelines.
If you want to do so anyway, add vasapi as a library to your own project (assuming you are using sbt):

``` scala
libraryDependencies ++= Seq("com.bosch.asc" %% "vasapi" % "<version>")
```

Vasapi artifacts are published to the following JFrog repositories:

| Vasapi Version   | Spark Version   | JFrog Artifactory Location                                                                                                                                                                                           |
|------------------|-----------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 1.0.0 and lower  | 2.4.7 or lower  | [see here](https://rb-artifactory.bosch.com/artifactory/BIDOS/com/bosch/asc/vasapi_2.11/)                                                                                                                            |
| 1.0.0, 1.0.1     | 3.2.1           | [see here](https://rb-artifactory.bosch.com/artifactory/BIDOS/com/bosch/asc/vasapi_2.12/)                                                                                                                            |
| 1.1.0 and higher | 3.2.3 or higher | BDC location: [see here](https://artifactory.boschdevcloud.com/artifactory/asc-de-generic-local)<br/>Bosch internal Artifactory: [see here](https://rb-artifactory.bosch.com:443/artifactory/asc-de-generic-remote/) |

Make sure to add the respective location to your build tool's configuration (sbt / maven / gradle)

## <a name="build">How to build and test it</a>

This application is a sbt project and can be built, tested and published using sbt.
For details on how to set up and use sbt we refer to the [sbt documentation](https://www.scala-sbt.org/1.x/docs/index.html)
and our internal [sbt configuration guidelines](https://inside-docupedia.bosch.com/confluence/x/ZVrq0).

## <a name="coveragedata">Code Coverage</a>

a code coverage report of this repository can be accessed here:

:eight_spoked_asterisk: [Current code coverage](https://pages.github.boschdevcloud.com/bios-asc/vasapi/code-coverage-results.html)

## <a name="contribute">How to contribute</a>

We follow the [BIOS way of facilitating contributions](http://bos.ch/ygF).

We're happy about contributions to this project. In order to do so, request access to our [bios-asc](https://github.boschdevcloud.com/bios-asc) GitHub organization.
Then, reach out to the maintainers for write access.

## <a name="licenses">Used 3rd party Licenses</a>

For a complete list of used 3rd party components (incl. OSS components), go the sbom folder in this repository. In this list, you will also find the license under which each component is distributed.

## <a name="encryption">Used encryption</a>

Declaration of the usage of any encryption (see BIOS Repository Policy §4.a ).

No encryption technology is used in the application itself
(may not extend to used frameworks).

## <a name="feedback">Feedback</a>

For questions, ideas or requests please contact us per email.


<!---

	Copyright (c) 2024 Robert Bosch GmbH and its subsidiaries.
	This program and the accompanying materials are made available under
	the terms of the Bosch Internal Open Source License v4
	which accompanies this distribution, and is available at
	http://bios.intranet.bosch.com/bioslv4.txt

-->

