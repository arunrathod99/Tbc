#!/bin/python

import glob
import subprocess
import getpass
import os.path
import sys
import urllib.request
import re
import argparse
import tarfile


def sparkSubmitString(
        configurationFiles,
        principal,
        keytab,
        name,
        queue,
        memoryOverheadDriver,
        memoryOverheadExecutor,
        VERSION,
        DATA_SIZE,
        NUM_EXECUTORS,
        DRIVER_MEMORY,
        DRIVER_CORES,
        EXECUTOR_MEMORY,
        EXECUTOR_CORES,
        ARTIFACTID,
        PACKAGE,
        REPOSITORIES,
        DEPLOYMODE,
        WAITAPPCOMPLETION,
        DYNAMIC_MEMORY_ALLOCATION,
        DYNAMIC_MAXEXECUTOR,
        DYNAMIC_MINEXECUTOR,
        DYNAMIC_IDLETIMEOUT,
        DYNAMIC_SCHEDULERBACKLOG_TIMEOUT,
):
    ARTIFACTORY_BASE = "https://rb-artifactory.bosch.com/artifactory"
    VASAPI_ARTIFACTORY_BASE = (
        "https://rb-artifactory.bosch.com/artifactory/asc-de-generic-remote"
    )
    JAR = "{0}/com/bosch/asc/{1}/{2}/{1}-{2}.jar".format(
        VASAPI_ARTIFACTORY_BASE, ARTIFACTID, VERSION
    )
    # required dependencies to make spark use logback over log4j as logging library
    LOGBACK_URLS = ",".join(
        [
            ARTIFACTORY_BASE
            + "/maven-central-remote-cache/org/slf4j/log4j-over-slf4j/2.0.7/log4j-over-slf4j-2.0.7.jar",
            ARTIFACTORY_BASE
            + "/jcenter-cache/ch/qos/logback/logback-classic/1.2.12/logback-classic-1.2.12.jar",
            ARTIFACTORY_BASE
            + "/jcenter-cache/ch/qos/logback/logback-core/1.2.12/logback-core-1.2.12.jar",
            ARTIFACTORY_BASE
            + "/jcenter-cache/net/logstash/logback/logstash-logback-encoder/6.4/logstash-logback-encoder-6.4.jar",
            ]
    )
    LOGBACK_JARS = "log4j-over-slf4j-2.0.7.jar:logback-classic-1.2.12.jar:logback-core-1.2.12.jar:logstash-logback-encoder-6.4.jar"

    # First all immutable stuff ...
    submitString = "spark3-submit"
    submitString += " --master yarn --deploy-mode " + DEPLOYMODE
    submitString += (
            " --conf "
            + "'spark.driver.extraJavaOptions=-Dconfig.file=application.conf -Dcom.bosch.asc.sparkstreamssolace.replay.block.size=100 -Duser.timezone=UTC -Djava.io.tmpdir=/tmp'"
    )
    submitString += " --class " + "com.bosch.asc.vasapi.Pipeline"
    submitString += " --conf " + "spark.executor.extraJavaOptions=-Duser.timezone=UTC"
    submitString += " --conf " + "spark.sql.session.timeZone=UTC"
    submitString += " --conf spark.yarn.submit.waitAppCompletion=" + WAITAPPCOMPLETION
    submitString += " --conf spark.sql.shuffle.partitions=5"
    if DYNAMIC_MEMORY_ALLOCATION == "true":
        submitString += " --conf spark.dynamicAllocation.enabled=true"
        if DYNAMIC_MAXEXECUTOR:
            submitString += (
                    " --conf spark.dynamicAllocation.maxExecutors=" + DYNAMIC_MAXEXECUTOR
            )
        if DYNAMIC_MINEXECUTOR:
            submitString += (
                    " --conf spark.dynamicAllocation.minExecutors=" + DYNAMIC_MINEXECUTOR
            )
        if DYNAMIC_IDLETIMEOUT:
            submitString += (
                    " --conf spark.dynamicAllocation.executorIdleTimeout="
                    + DYNAMIC_IDLETIMEOUT
            )
        if DYNAMIC_SCHEDULERBACKLOG_TIMEOUT:
            submitString += (
                    " --conf spark.dynamicAllocation.schedulerBacklogTimeout="
                    + DYNAMIC_SCHEDULERBACKLOG_TIMEOUT
            )
    submitString += " --conf spark.sql.streaming.schemaInference=true"
    submitString += " --conf spark.sql.files.ignoreCorruptFiles=true"
    submitString += " --conf spark.shuffle.service.enabled=true"
    submitString += " --conf spark.cleaner.referenceTracking.cleanCheckpoints=true"
    submitString += (
            " --jars " + LOGBACK_URLS
    )  # these jars are downloaded from artifactory
    submitString += (
            " --conf spark.executor.extraClassPath=" + LOGBACK_JARS
    )  # prioritize logback libs over log4j which is on cluster by default
    submitString += " --conf spark.driver.extraClassPath=" + LOGBACK_JARS
    submitString += " --conf spark.acls.enable=true"

    # ... then the configurable parameters ...
    submitString += " --conf spark.ui.view.acls.groups=DE/idm2bcd_aesi01dev_global_read"
    submitString += " --principal " + principal + " --keytab " + keytab
    submitString += f" --num-executors {int(NUM_EXECUTORS)}"
    submitString += f" --driver-memory {int(DRIVER_MEMORY)}G"
    submitString += f" --driver-cores {int(DRIVER_CORES)}"
    submitString += f" --executor-memory {int(EXECUTOR_MEMORY)}G"
    submitString += f" --executor-cores {int(EXECUTOR_CORES)}"
    submitString += " --conf spark.driver.memoryOverhead=" + str(memoryOverheadDriver)
    submitString += " --conf spark.executor.memoryOverhead=" + str(
        memoryOverheadExecutor
    )
    submitString += " --name " + name
    # submitString += " --queue " + queue
    # ... and finally the arrays, they need some extra care
    submitString += " --files " + configurationFiles
    submitString += " --packages "
    for n, p in enumerate(PACKAGE):
        submitString += p
        if n < len(PACKAGE) - 1:
            submitString += ","
    submitString += " --repositories "
    for n, r in enumerate(REPOSITORIES):
        submitString += r
        if n < len(REPOSITORIES) - 1:
            submitString += ","
    submitString += " " + JAR
    return submitString


def downloadConfigurationFiles(server_url, artifactid, version, resource_list):
    for r in resource_list:
        filename, headers = urllib.request.urlretrieve(
            server_url + "/" + artifactid + "/" + version + "/" + r, "my_tar.tgz"
        )
        tar_file = tarfile.open("my_tar.tgz")
        tar_file.extractall()
        tar_file.close()


def createJceksFile(jceks_file_path, user_password, user_provider):
    def run_cmd(args_list):
        print("Running system command: {0}".format(" ".join(args_list)))
        proc = subprocess.Popen(
            args_list, stdout=subprocess.PIPE, stderr=subprocess.PIPE
        )
        s_output, s_err = proc.communicate()
        s_return = proc.returncode
        return s_return, s_output, s_err

    cmd = ["hdfs", "dfs", "-test", "-e", jceks_file_path]
    ret, out, err = run_cmd(cmd)
    if ret:
        print("file does not exist")
        createString = (
                "hadoop"
                + " "
                + "credential"
                + " "
                + "create"
                + " "
                + user_password
                + " "
                + "-provider"
                + " "
                + user_provider
        )
        os.system(createString)


def writeToFile(s):
    file = open("sparkSubmit.txt", "w")
    file.write(s)
    file.close()


# To copy keytab file to local space- for Ansible to submit spark job
def copyKeytabtoLocal(username):
    keytab_file = "/user/" + username + "/" + username + ".keytab"
    cmd = ["hdfs", "dfs", "-get", "-f", keytab_file, "~"]
    file_copy = subprocess.getoutput(" ".join(cmd))


def main():
    parser = argparse.ArgumentParser(
        "Arguments to the script are :[project] [realm] [version]"
    )
    parser.add_argument("project", type=str, help="Name of your project e.g, vasapi")
    parser.add_argument(
        "realm", type=str, help="REALM: e.g, RB-AE-SI01.BDPS.BOSCH-ORG.COM"
    )
    parser.add_argument(
        "version",
        type=str,
        help="the version of vasapi to be used, e.g. 0.0.2-SNAPSHOT",
    )
    parser.add_argument(
        "--memoryOverheadDriver",
        type=str,
        help="the memory overhead for driver e.g. 1024",
    )
    parser.add_argument(
        "--memoryOverheadExecutor",
        type=str,
        help="the memory overhead for the executors e.g. 1024",
    )
    parser.add_argument(
        "--datasize", default=1, help="provide a Datasize value (default: 1)"
    )
    parser.add_argument(
        "--numexecutor",
        default=None,
        help="provide a Numexecutor value (default: None)",
    )
    parser.add_argument(
        "--drivermemory",
        default=None,
        help="provide a Drivermemory value (default: None)",
    )
    parser.add_argument(
        "--drivercore", default=None, help="provide a Drivercore value (default: None)"
    )
    parser.add_argument(
        "--executormemory",
        default=None,
        help="provide a Executormemory value (default: None)",
    )
    parser.add_argument(
        "--executorcore", default=1, help="provide a Executorcore value (default: 1)"
    )
    parser.add_argument(
        "--username",
        type=str,
        help="User in which pipeline will run e.g, t_vasapi_proc",
    )
    parser.add_argument(
        "--package",
        action="store",
        dest="package",
        type=str,
        nargs="*",
        default=[
            "com.github.pureconfig:pureconfig_2.12:0.15.0",
            "org.apache.spark:spark-avro_2.12:3.2.3",
            "org.json4s:json4s-xml_2.12:3.6.0-M4",
            "com.bosch.bidos:solace-source-sink_2.12:2.0.1",
            "org.everit.json:org.everit.json.schema:1.5.1",
            "org.apache.iceberg:iceberg-spark-runtime-3.2_2.12:1.2.0",
            "org.apache.iceberg:iceberg-hive-runtime:1.2.1",
            "org.apache.hadoop:hadoop-aws:3.1.1.7.1.7.2047-1",
            "com.bosch.asc:",
        ],
        help="list of packages",
    )
    parser.add_argument(
        "--repositories",
        action="store",
        dest="repositories",
        type=str,
        nargs="*",
        default=[
            "https://rb-artifactory.bosch.com/artifactory/asc-de-generic-remote",
            "https://rb-artifactory.bosch.com/artifactory/BIDOS",
            "https://rb-artifactory.bosch.com/artifactory/maven-central-remote",
            "https://rb-artifactory.bosch.com/artifactory/cloudera-maven-remote",
            "https://rb-artifactory.bosch.com/artifactory/maven2-remote",
        ],
        help="list of repositories",
    )
    parser.add_argument(
        "--additionalfiles",
        action="store",
        dest="additionalfiles",
        type=str,
        nargs="*",
        default=[],
        help="list of additonal files",
    )
    parser.add_argument(
        "--deploymode",
        type=str,
        default="cluster",
        help="deploy mode for Spark application (client/cluster)",
    )
    parser.add_argument(
        "--waitappcompletion",
        type=str,
        default="false",
        help="wait for job to complete (false/true)",
    )
    parser.add_argument(
        "--dynamicmemoryallocation",
        type=str,
        default="false",
        help="static or dynamic memory allocation (false/true)",
    )
    parser.add_argument(
        "--dynamicmaxexecutor",
        help="maximum executors for dynamic memory allocation (default: None)",
    )
    parser.add_argument(
        "--dynamicminexecutor",
        help="minumum executors for dynamic memory allocation (default: None)",
    )
    parser.add_argument(
        "--dynamicidletimeout",
        help="idle timeout for dynamic memory allocation (default: None)",
    )
    parser.add_argument(
        "--dynamicschedulerbacklogtimeout",
        help="idle timeout for dynamic memory allocation (default: None)",
    )
    parser.add_argument(
        "--logginglevel",
        type=str,
        default="info",
        help="logging level for the application (info/debug)",
    )
    args = parser.parse_args()
    PROJECT = args.project
    REALM = args.realm
    DATA_SIZE = args.datasize
    NUM_EXECUTORS = (
        args.numexecutor if args.numexecutor is not None else 4 * int(DATA_SIZE)
    )
    DRIVER_MEMORY = (
        args.drivermemory if args.drivermemory is not None else 4 * int(DATA_SIZE)
    )
    DRIVER_CORES = (
        args.drivercore if args.drivercore is not None else 2 * int(DATA_SIZE)
    )
    EXECUTOR_MEMORY = (
        args.executormemory if args.executormemory is not None else 2 * int(DATA_SIZE)
    )
    EXECUTOR_CORES = args.executorcore
    MEMORY_OVERHEAD_DRIVER = args.memoryOverheadDriver
    MEMORY_OVERHEAD_EXECUTOR = args.memoryOverheadExecutor
    VERSION = args.version
    PACKAGE = args.package
    REPOSITORIES = args.repositories
    ADDITIONALFILES = args.additionalfiles
    if args.username:
        username = args.username
        copyKeytabtoLocal(username)
    else:
        username = getpass.getuser()
    DEPLOYMODE = args.deploymode
    WAITAPPCOMPLETION = args.waitappcompletion
    DYNAMIC_MEMORY_ALLOCATION = args.dynamicmemoryallocation
    DYNAMIC_MAXEXECUTOR = (
        args.dynamicmaxexecutor if args.dynamicmemoryallocation == "true" else None
    )
    DYNAMIC_MINEXECUTOR = (
        args.dynamicminexecutor if args.dynamicmemoryallocation == "true" else None
    )
    DYNAMIC_IDLETIMEOUT = (
        args.dynamicidletimeout if args.dynamicmemoryallocation == "true" else None
    )
    DYNAMIC_SCHEDULERBACKLOG_TIMEOUT = (
        args.dynamicschedulerbacklogtimeout
        if args.dynamicmemoryallocation == "true"
        else None
    )
    LOGBACK_FILE_NAME = "logback_debug_" if args.logginglevel == "debug" else "logback_"
    homedir = os.path.expanduser("~")
    workdir = os.getcwd()
    jceks_file_path = "/user/" + username + "/" + username + ".jceks"
    user_password = username + ".password"
    user_provider = "jceks:///user/" + username + "/" + username + ".jceks"
    SERVER_URL = "https://rb-artifactory.bosch.com/artifactory/BIDOS/com/bosch/asc"
    LOGBACK_SERVER_URL = "https://rb-artifactory.bosch.com/artifactory/asc-de-generic-remote/com/bosch/asc"
    SCALA_VERSION = "2.12"
    ARTIFACTID = "vasapi_" + SCALA_VERSION
    IFS = REALM.split("-")
    PLANT = IFS[2]
    IFS = PLANT.split(".")
    PLANT = IFS[0]
    # add logging config if file exists, skip otherwise
    localConf = PLANT + "." + PROJECT + ".conf"
    if not os.path.isfile(localConf):
        # Hadoop distributed file cache archive for Oozie
        localConf = "vasapi-configuration.tar/" + localConf
    CONF = localConf + "#application.conf"
    APP_NAME = "vasapi." + PLANT + "." + PROJECT
    CONFFILES = ""
    # Additional Configuration files
    files_added = []
    for files in ADDITIONALFILES:
        files_added.extend(glob.glob(files))
    joined_string = ",".join([str(v) for v in files_added])
    if len(joined_string) == 0:
        CONFFILES = CONF
    else:
        CONFFILES = CONF + "," + joined_string

    # Retrieval of logback from artifactory
    BASE_URL = LOGBACK_SERVER_URL + "/" + ARTIFACTID + "/" + VERSION
    logback_pattern = LOGBACK_FILE_NAME + SCALA_VERSION + "-" + VERSION + ".xml"
    CONFFILES = CONFFILES + "," + BASE_URL + "/" + logback_pattern + "#logback.xml"

    createJceksFile(jceks_file_path, user_password, user_provider)

    # Retrieval of correct principal and roletype in case of multiple token
    IFS = username.split("_")
    if len(IFS) > 1:
        ROLETYPE = IFS[-1]
        PIPELINE = "_".join(IFS[1:-1])
    else:
        print("User name is empty")
    PRINCIPAL = "t_" + PIPELINE + "_" + ROLETYPE + "@" + REALM
    KEYTAB = workdir + "/" + username + ".keytab"
    hdfsKeytab = "hdfs:///user/" + username + "/" + username + ".keytab"
    QUEUE = "root." + ROLETYPE + "." + PIPELINE

    # Definition of variables, used to control the spark submit and the creation of the initial table
    response = urllib.request.urlopen(
        SERVER_URL + "/" + ARTIFACTID + "/" + "maven-metadata.xml"
    )
    xml_data = response.read()
    if len(VERSION) == 0:
        VERSION = re.search("<latest>(.*)</latest>", xml_data).group(1)
    resource_response = urllib.request.urlopen(
        SERVER_URL + "/" + ARTIFACTID + "/" + VERSION
    ).read()
    # Check if the resource and installer file are present in Artifact
    try:
        resource_file = re.search("resources_tar_.*>(.*)</a>", resource_response).group(
            1
        )
        installer_file = re.search(
            "installer_tar_.*>(.*)</a>", resource_response
        ).group(1)
        resourcelist = [resource_file, installer_file]
        # ...Download the configuration files
        downloadConfigurationFiles(SERVER_URL, ARTIFACTID, VERSION, resourcelist)
    except:
        print("ERROR: Resource file and installer file not found in artifactory.")

    subprocess.call(["kinit", "-kt", KEYTAB, PRINCIPAL])
    PACKAGE[-1] = PACKAGE[-1] + ARTIFACTID + ":" + VERSION
    # pull keytab from HDFS
    os.system("hdfs dfs -get " + hdfsKeytab + " " + KEYTAB)
    submitString = sparkSubmitString(
        CONFFILES,
        PRINCIPAL,
        KEYTAB,
        APP_NAME,
        QUEUE,
        MEMORY_OVERHEAD_DRIVER,
        MEMORY_OVERHEAD_EXECUTOR,
        VERSION,
        float(DATA_SIZE),
        float(NUM_EXECUTORS),
        float(DRIVER_MEMORY),
        float(DRIVER_CORES),
        float(EXECUTOR_MEMORY),
        float(EXECUTOR_CORES),
        ARTIFACTID,
        PACKAGE,
        REPOSITORIES,
        DEPLOYMODE,
        WAITAPPCOMPLETION,
        DYNAMIC_MEMORY_ALLOCATION,
        DYNAMIC_MAXEXECUTOR,
        DYNAMIC_MINEXECUTOR,
        DYNAMIC_IDLETIMEOUT,
        DYNAMIC_SCHEDULERBACKLOG_TIMEOUT,
    )
    submitStatus = os.system(submitString)
    writeToFile(submitString + "\n")
    # remove local keytab
    os.system("rm " + KEYTAB)
    return submitStatus >> 8


if __name__ == "__main__":
    exit(main())
