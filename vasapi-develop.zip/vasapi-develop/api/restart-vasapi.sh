function getAppCount {
   APPLN_NAME=$1
   APPCOUNT=`yarn application -list -appStates NEW,NEW_SAVING,SUBMITTED,ACCEPTED,RUNNING | grep -c $APPLN_NAME`
   echo $APPCOUNT
}
if [ $(getAppCount $APP_NAME) -le 0 ]
then
sh start_vasapi.sh
echo "Restarted at $(date) " >> restart.log 2>&1 &
else
echo "Already running"
fi