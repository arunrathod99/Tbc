source /opt/cloudera/parcels/bdps_anaconda-2023.03-1-075232/etc/profile.d/conda.sh
conda activate base
python start_script.py <application_name> <cluster_realm> --datasize 2 --executorcore 2 --numexecutor 2 --memoryOverheadDriver 3072 --memoryOverheadExecutor 1024  <vasapi_version> --additionalfiles <space separated required application files>
