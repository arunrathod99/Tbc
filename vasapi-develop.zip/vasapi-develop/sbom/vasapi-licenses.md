# vasapi-licenses

Category | License | Dependency | Notes
--- | --- | --- | ---
Apache | [Apache 2](http://www.apache.org/licenses/LICENSE-2.0.txt) | com.chuusai # shapeless_2.12 # 2.3.3 | <notextile></notextile>
Apache | [Apache 2](http://www.apache.org/licenses/LICENSE-2.0) | com.sksamuel.scapegoat # scalac-scapegoat-plugin_2.12 # 1.3.0 | <notextile></notextile>
Apache | [Apache 2](http://www.apache.org/licenses/LICENSE-2.0.txt) | com.twitter # chill-java # 0.10.0 | <notextile></notextile>
Apache | [Apache 2](http://www.apache.org/licenses/LICENSE-2.0.txt) | com.twitter # chill_2.12 # 0.10.0 | <notextile></notextile>
Apache | [Apache 2](http://www.apache.org/licenses/LICENSE-2.0.txt) | com.univocity # univocity-parsers # 2.9.1 | <notextile></notextile>
Apache | [Apache 2](http://www.apache.org/licenses/LICENSE-2.0.txt) | javax.jdo # jdo-api # 3.0.1 | <notextile></notextile>
Apache | [Apache 2](http://www.apache.org/licenses/LICENSE-2.0.txt) | net.sf.opencsv # opencsv # 2.3 | <notextile></notextile>
Apache | [Apache 2](http://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.derby # derby # 10.14.2.0 | <notextile></notextile>
Apache | [Apache 2](http://www.apache.org/licenses/LICENSE-2.0.txt) | org.objenesis # objenesis # 2.6 | <notextile></notextile>
Apache | [Apache 2](http://www.apache.org/licenses/LICENSE-2.0.txt) | org.roaringbitmap # RoaringBitmap # 0.9.0 | <notextile></notextile>
Apache | [Apache 2](http://www.apache.org/licenses/LICENSE-2.0.txt) | org.roaringbitmap # shims # 0.9.0 | <notextile></notextile>
Apache | [Apache 2](http://www.apache.org/licenses/LICENSE-2.0.txt) | org.typelevel # macro-compat_2.12 # 1.1.1 | <notextile></notextile>
Apache | [Apache 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | com.google.code.gson # gson # 2.8.6 | <notextile></notextile>
Apache | [Apache 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | com.google.errorprone # error_prone_annotations # 2.2.0 | <notextile></notextile>
Apache | [Apache 2.0 License](http://www.apache.org/licenses/LICENSE-2.0.html) | org.apache.spark # spark-catalyst_2.12 # 3.2.1 | <notextile></notextile>
Apache | [Apache 2.0 License](http://www.apache.org/licenses/LICENSE-2.0.html) | org.apache.spark # spark-core_2.12 # 3.2.1 | <notextile></notextile>
Apache | [Apache 2.0 License](http://www.apache.org/licenses/LICENSE-2.0.html) | org.apache.spark # spark-graphx_2.12 # 3.2.1 | <notextile></notextile>
Apache | [Apache 2.0 License](http://www.apache.org/licenses/LICENSE-2.0.html) | org.apache.spark # spark-hive_2.12 # 3.2.1 | <notextile></notextile>
Apache | [Apache 2.0 License](http://www.apache.org/licenses/LICENSE-2.0.html) | org.apache.spark # spark-kvstore_2.12 # 3.2.1 | <notextile></notextile>
Apache | [Apache 2.0 License](http://www.apache.org/licenses/LICENSE-2.0.html) | org.apache.spark # spark-launcher_2.12 # 3.2.1 | <notextile></notextile>
Apache | [Apache 2.0 License](http://www.apache.org/licenses/LICENSE-2.0.html) | org.apache.spark # spark-mllib-local_2.12 # 3.2.1 | <notextile></notextile>
Apache | [Apache 2.0 License](http://www.apache.org/licenses/LICENSE-2.0.html) | org.apache.spark # spark-mllib_2.12 # 3.2.1 | <notextile></notextile>
Apache | [Apache 2.0 License](http://www.apache.org/licenses/LICENSE-2.0.html) | org.apache.spark # spark-network-common_2.12 # 3.2.1 | <notextile></notextile>
Apache | [Apache 2.0 License](http://www.apache.org/licenses/LICENSE-2.0.html) | org.apache.spark # spark-network-shuffle_2.12 # 3.2.1 | <notextile></notextile>
Apache | [Apache 2.0 License](http://www.apache.org/licenses/LICENSE-2.0.html) | org.apache.spark # spark-sketch_2.12 # 3.2.1 | <notextile></notextile>
Apache | [Apache 2.0 License](http://www.apache.org/licenses/LICENSE-2.0.html) | org.apache.spark # spark-sql_2.12 # 3.2.1 | <notextile></notextile>
Apache | [Apache 2.0 License](http://www.apache.org/licenses/LICENSE-2.0.html) | org.apache.spark # spark-streaming_2.12 # 3.2.1 | <notextile></notextile>
Apache | [Apache 2.0 License](http://www.apache.org/licenses/LICENSE-2.0.html) | org.apache.spark # spark-tags_2.12 # 3.2.1 | <notextile></notextile>
Apache | [Apache 2.0 License](http://www.apache.org/licenses/LICENSE-2.0.html) | org.apache.spark # spark-unsafe_2.12 # 3.2.1 | <notextile></notextile>
Apache | [Apache 2.0 License](http://www.apache.org/licenses/LICENSE-2.0.html) | org.apache.spark # spark-yarn_2.12 # 3.2.1 | <notextile></notextile>
Apache | [Apache License 2.0](http://www.apache.org/licenses/LICENSE-2.0.html) | com.holdenkarau # spark-testing-base_2.12 # 3.2.1_1.3.0 | <notextile></notextile>
Apache | [Apache License 2.0](http://www.apache.org/licenses/LICENSE-2.0.html) | com.ning # compress-lzf # 1.0.3 | <notextile></notextile>
Apache | [Apache License 2.0](http://www.apache.org/licenses/LICENSE-2.0.html) | io.airlift # aircompressor # 0.21 | <notextile></notextile>
Apache | [Apache License 2.0](https://www.apache.org/licenses/LICENSE-2.0.html) | io.dropwizard.metrics # metrics-core # 4.2.0 | <notextile></notextile>
Apache | [Apache License 2.0](https://www.apache.org/licenses/LICENSE-2.0.html) | io.dropwizard.metrics # metrics-graphite # 4.2.0 | <notextile></notextile>
Apache | [Apache License 2.0](https://www.apache.org/licenses/LICENSE-2.0.html) | io.dropwizard.metrics # metrics-jmx # 4.2.0 | <notextile></notextile>
Apache | [Apache License 2.0](https://www.apache.org/licenses/LICENSE-2.0.html) | io.dropwizard.metrics # metrics-json # 4.2.0 | <notextile></notextile>
Apache | [Apache License 2.0](https://www.apache.org/licenses/LICENSE-2.0.html) | io.dropwizard.metrics # metrics-jvm # 4.2.0 | <notextile></notextile>
Apache | [Apache License 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | jakarta.validation # jakarta.validation-api # 2.0.2 | <notextile></notextile>
Apache | [Apache License 2.0](http://www.apache.org/licenses/LICENSE-2.0.html) | org.rocksdb # rocksdbjni # 6.20.3 | <notextile></notextile>
Apache | [Apache License V2.0](https://raw.githubusercontent.com/google/flatbuffers/master/LICENSE.txt) | com.google.flatbuffers # flatbuffers-java # 1.9.0 | <notextile></notextile>
Apache | [Apache License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | com.clearspring.analytics # stream # 2.9.6 | <notextile></notextile>
Apache | [Apache License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | com.github.joshelser # dropwizard-metrics-hadoop-metrics2-reporter # 0.1.2 | <notextile></notextile>
Apache | [Apache License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | com.github.stephenc.jcip # jcip-annotations # 1.0-1 | <notextile></notextile>
Apache | [Apache License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | com.google.crypto.tink # tink # 1.6.0 | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0.txt) | commons-beanutils # commons-beanutils # 1.9.4 | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0.txt) | commons-codec # commons-codec # 1.15 | <notextile></notextile>
Apache | [Apache License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | commons-collections # commons-collections # 3.2.2 | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0.txt) | commons-io # commons-io # 2.8.0 | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0.txt) | commons-net # commons-net # 3.6 | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0) | io.netty # netty-all # 4.1.77.Final | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0) | io.netty # netty-buffer # 4.1.77.Final | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0) | io.netty # netty-codec # 4.1.77.Final | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0) | io.netty # netty-codec-dns # 4.1.77.Final | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0) | io.netty # netty-codec-haproxy # 4.1.77.Final | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0) | io.netty # netty-codec-http # 4.1.77.Final | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0) | io.netty # netty-codec-http2 # 4.1.77.Final | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0) | io.netty # netty-codec-memcache # 4.1.77.Final | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0) | io.netty # netty-codec-mqtt # 4.1.77.Final | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0) | io.netty # netty-codec-redis # 4.1.77.Final | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0) | io.netty # netty-codec-smtp # 4.1.77.Final | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0) | io.netty # netty-codec-socks # 4.1.77.Final | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0) | io.netty # netty-codec-stomp # 4.1.77.Final | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0) | io.netty # netty-codec-xml # 4.1.77.Final | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0) | io.netty # netty-common # 4.1.77.Final | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0) | io.netty # netty-handler # 4.1.77.Final | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0) | io.netty # netty-handler-proxy # 4.1.77.Final | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0) | io.netty # netty-resolver # 4.1.77.Final | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0) | io.netty # netty-resolver-dns # 4.1.77.Final | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0) | io.netty # netty-resolver-dns-classes-macos # 4.1.77.Final | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0) | io.netty # netty-resolver-dns-native-macos # 4.1.77.Final | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0) | io.netty # netty-transport # 4.1.77.Final | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0) | io.netty # netty-transport-classes-epoll # 4.1.77.Final | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0) | io.netty # netty-transport-classes-kqueue # 4.1.77.Final | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0) | io.netty # netty-transport-native-epoll # 4.1.77.Final | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0) | io.netty # netty-transport-native-kqueue # 4.1.77.Final | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0) | io.netty # netty-transport-native-unix-common # 4.1.77.Final | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0) | io.netty # netty-transport-rxtx # 4.1.77.Final | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0) | io.netty # netty-transport-sctp # 4.1.77.Final | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0) | io.netty # netty-transport-udt # 4.1.77.Final | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0.txt) | joda-time # joda-time # 2.10.10 | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.arrow # arrow-format # 2.0.0 | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.arrow # arrow-memory-core # 2.0.0 | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.arrow # arrow-memory-netty # 2.0.0 | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.arrow # arrow-vector # 2.0.0 | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.avro # avro # 1.10.2 | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.avro # avro-ipc # 1.10.2 | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.avro # avro-mapred # 1.10.2 | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.commons # commons-compress # 1.20 | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.commons # commons-configuration2 # 2.1.1 | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.commons # commons-crypto # 1.1.0 | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.commons # commons-lang3 # 3.12.0 | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.commons # commons-text # 1.6 | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.hadoop # hadoop-annotations # 3.3.1 | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.hadoop # hadoop-auth # 3.3.1 | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.hadoop # hadoop-client-api # 3.3.1 | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.hadoop # hadoop-client-runtime # 3.3.1 | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.hadoop # hadoop-common # 3.3.1 | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.hadoop.thirdparty # hadoop-shaded-guava # 1.1.1 | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.hadoop.thirdparty # hadoop-shaded-protobuf_3_7 # 1.1.1 | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.hive # hive-storage-api # 2.7.2 | <notextile></notextile>
Apache | [Apache License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.httpcomponents # httpclient # 4.5.13 | <notextile></notextile>
Apache | [Apache License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.httpcomponents # httpcore # 4.4.13 | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.kerby # kerb-admin # 1.0.1 | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.kerby # kerb-client # 1.0.1 | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.kerby # kerb-common # 1.0.1 | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.kerby # kerb-core # 1.0.1 | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.kerby # kerb-crypto # 1.0.1 | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.kerby # kerb-identity # 1.0.1 | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.kerby # kerb-server # 1.0.1 | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.kerby # kerb-simplekdc # 1.0.1 | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.kerby # kerb-util # 1.0.1 | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.kerby # kerby-asn1 # 1.0.1 | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.kerby # kerby-config # 1.0.1 | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.kerby # kerby-pkix # 1.0.1 | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.kerby # kerby-util # 1.0.1 | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.kerby # kerby-xdr # 1.0.1 | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.kerby # token-provider # 1.0.1 | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.logging.log4j # log4j-api # 2.20.0 | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.orc # orc-core # 1.6.12 | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.orc # orc-mapreduce # 1.6.12 | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.orc # orc-shims # 1.6.12 | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.yetus # audience-annotations # 0.12.0 | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.zookeeper # zookeeper # 3.6.2 | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.zookeeper # zookeeper-jute # 3.6.2 | <notextile></notextile>
Apache | [Apache License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0) | org.osgi # org.osgi.annotation # 6.0.0 | <notextile></notextile>
Apache | [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0.txt) | org.slf4j # jcl-over-slf4j # 1.7.30 | <notextile></notextile>
Apache | [Apache Publich License 2.0](http://www.apache.org/licenses/LICENSE-2.0.html) | org.scalanlp # breeze-macros_2.12 # 1.2 | <notextile></notextile>
Apache | [Apache Publich License 2.0](http://www.apache.org/licenses/LICENSE-2.0.html) | org.scalanlp # breeze_2.12 # 1.2 | <notextile></notextile>
Apache | [Apache Software License - Version 2.0](http://www.apache.org/licenses/LICENSE-2.0) | org.eclipse.jetty # jetty-http # 9.4.40.v20210413 | <notextile></notextile>
Apache | [Apache Software License - Version 2.0](http://www.apache.org/licenses/LICENSE-2.0) | org.eclipse.jetty # jetty-io # 9.4.40.v20210413 | <notextile></notextile>
Apache | [Apache Software License - Version 2.0](http://www.apache.org/licenses/LICENSE-2.0) | org.eclipse.jetty # jetty-security # 9.4.40.v20210413 | <notextile></notextile>
Apache | [Apache Software License - Version 2.0](http://www.apache.org/licenses/LICENSE-2.0) | org.eclipse.jetty # jetty-server # 9.4.40.v20210413 | <notextile></notextile>
Apache | [Apache Software License - Version 2.0](http://www.apache.org/licenses/LICENSE-2.0) | org.eclipse.jetty # jetty-servlet # 9.4.40.v20210413 | <notextile></notextile>
Apache | [Apache Software License - Version 2.0](http://www.apache.org/licenses/LICENSE-2.0) | org.eclipse.jetty # jetty-util # 9.4.49.v20220914 | <notextile></notextile>
Apache | [Apache Software License - Version 2.0](http://www.apache.org/licenses/LICENSE-2.0) | org.eclipse.jetty # jetty-util-ajax # 9.4.40.v20210413 | <notextile></notextile>
Apache | [Apache Software License - Version 2.0](http://www.apache.org/licenses/LICENSE-2.0) | org.eclipse.jetty # jetty-webapp # 9.4.40.v20210413 | <notextile></notextile>
Apache | [Apache Software License - Version 2.0](http://www.apache.org/licenses/LICENSE-2.0) | org.eclipse.jetty # jetty-xml # 9.4.40.v20210413 | <notextile></notextile>
Apache | [Apache v2](http://www.apache.org/licenses/LICENSE-2.0.html) | com.jolbox # bonecp # 0.8.0.RELEASE | <notextile></notextile>
Apache | [Apache-2.0](https://www.apache.org/licenses/LICENSE-2.0) | com.typesafe # config # 1.3.4 | <notextile></notextile>
Apache | [Apache-2.0](https://www.apache.org/licenses/LICENSE-2.0.html) | com.typesafe.play # play-functional_2.12 # 2.9.1 | <notextile></notextile>
Apache | [Apache-2.0](https://www.apache.org/licenses/LICENSE-2.0.html) | com.typesafe.play # play-json_2.12 # 2.9.1 | <notextile></notextile>
Apache | [Apache-2.0](http://www.apache.org/licenses/LICENSE-2.0) | org.json4s # json4s-ast_2.12 # 3.6.0-M4 | <notextile></notextile>
Apache | [Apache-2.0](http://www.apache.org/licenses/LICENSE-2.0) | org.json4s # json4s-ast_2.12 # 3.7.0-M11 | <notextile></notextile>
Apache | [Apache-2.0](http://www.apache.org/licenses/LICENSE-2.0) | org.json4s # json4s-core_2.12 # 3.6.0-M4 | <notextile></notextile>
Apache | [Apache-2.0](http://www.apache.org/licenses/LICENSE-2.0) | org.json4s # json4s-core_2.12 # 3.7.0-M11 | <notextile></notextile>
Apache | [Apache-2.0](http://www.apache.org/licenses/LICENSE-2.0) | org.json4s # json4s-jackson_2.12 # 3.7.0-M11 | <notextile></notextile>
Apache | [Apache-2.0](http://www.apache.org/licenses/LICENSE-2.0) | org.json4s # json4s-scalap_2.12 # 3.6.0-M4 | <notextile></notextile>
Apache | [Apache-2.0](http://www.apache.org/licenses/LICENSE-2.0) | org.json4s # json4s-scalap_2.12 # 3.7.0-M11 | <notextile></notextile>
Apache | [Apache-2.0](http://www.apache.org/licenses/LICENSE-2.0) | org.json4s # json4s-xml_2.12 # 3.6.0-M4 | <notextile></notextile>
Apache | [Apache-2.0](https://www.apache.org/licenses/LICENSE-2.0) | org.scala-lang # scala-compiler # 2.12.10 | <notextile></notextile>
Apache | [Apache-2.0](https://www.apache.org/licenses/LICENSE-2.0) | org.scala-lang # scala-library # 2.12.10 | <notextile></notextile>
Apache | [Apache-2.0](https://www.apache.org/licenses/LICENSE-2.0) | org.scala-lang # scala-reflect # 2.12.10 | <notextile></notextile>
Apache | [Apache-2.0](https://www.apache.org/licenses/LICENSE-2.0) | org.scala-lang.modules # scala-collection-compat_2.12 # 2.1.1 | <notextile></notextile>
Apache | [Apache-2.0](https://www.apache.org/licenses/LICENSE-2.0) | org.scala-lang.modules # scala-parser-combinators_2.12 # 1.1.2 | <notextile></notextile>
Apache | [Apache-2.0](https://www.apache.org/licenses/LICENSE-2.0) | org.scala-lang.modules # scala-xml_2.12 # 2.1.0 | <notextile></notextile>
Apache | [Apache-2.0](http://www.apache.org/licenses/LICENSE-2.0) | org.scalatestplus # junit-4-12_2.12 # 3.2.2.0 | <notextile></notextile>
Apache | [Apache-2.0](http://www.apache.org/licenses/LICENSE-2.0) | org.scalatestplus # scalacheck-1-15_2.12 # 3.2.3.0 | <notextile></notextile>
Apache | [Apache-2.0](https://www.apache.org/licenses/LICENSE-2.0.html) | org.xerial.snappy # snappy-java # 1.1.8.4 | <notextile></notextile>
Apache | [The Apache License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | com.fasterxml.woodstox # woodstox-core # 5.3.0 | <notextile></notextile>
Apache | [The Apache License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | org.spark-project.spark # unused # 1.0.0 | <notextile></notextile>
Apache | [The Apache Software License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | com.fasterxml.jackson.core # jackson-annotations # 2.10.5 | <notextile></notextile>
Apache | [The Apache Software License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | com.fasterxml.jackson.core # jackson-annotations # 2.12.3 | <notextile></notextile>
Apache | [The Apache Software License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0.txt) | com.fasterxml.jackson.core # jackson-core # 2.14.2 | <notextile></notextile>
Apache | [The Apache Software License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0.txt) | com.fasterxml.jackson.core # jackson-databind # 2.14.2 | <notextile></notextile>
Apache | [The Apache Software License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | com.fasterxml.jackson.datatype # jackson-datatype-jdk8 # 2.10.5 | <notextile></notextile>
Apache | [The Apache Software License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | com.fasterxml.jackson.datatype # jackson-datatype-jsr310 # 2.10.5 | <notextile></notextile>
Apache | [The Apache Software License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0.txt) | com.fasterxml.jackson.module # jackson-module-scala_2.12 # 2.14.2 | <notextile></notextile>
Apache | [The Apache Software License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | com.google.code.findbugs # jsr305 # 3.0.0 | <notextile></notextile>
Apache | [The Apache Software License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | com.google.guava # failureaccess # 1.0 | <notextile></notextile>
Apache | [The Apache Software License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | com.google.guava # guava # 27.0-jre | <notextile></notextile>
Apache | [The Apache Software License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | com.google.guava # listenablefuture # 9999.0-empty-to-avoid-conflict-with-guava | <notextile></notextile>
Apache | [The Apache Software License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | com.google.j2objc # j2objc-annotations # 1.1 | <notextile></notextile>
Apache | [The Apache Software License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0.txt) | com.nimbusds # nimbus-jose-jwt # 9.8.1 | <notextile></notextile>
Apache | [The Apache Software License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | com.tdunning # json # 1.8 | <notextile></notextile>
Apache | [The Apache Software License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | com.zaxxer # HikariCP # 2.5.1 | <notextile></notextile>
Apache | [The Apache Software License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | commons-cli # commons-cli # 1.2 | <notextile></notextile>
Apache | [The Apache Software License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | commons-dbcp # commons-dbcp # 1.4 | <notextile></notextile>
Apache | [The Apache Software License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | commons-lang # commons-lang # 2.6 | <notextile></notextile>
Apache | [The Apache Software License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | commons-logging # commons-logging # 1.2 | <notextile></notextile>
Apache | [The Apache Software License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | commons-pool # commons-pool # 1.5.4 | <notextile></notextile>
Apache | [The Apache Software License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | io.netty # netty-tcnative-classes # 2.0.52.Final | <notextile></notextile>
Apache | [The Apache Software License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | log4j # log4j # 1.2.17 | <notextile></notextile>
Apache | [The Apache Software License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | net.bytebuddy # byte-buddy # 1.9.10 | <notextile></notextile>
Apache | [The Apache Software License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | net.bytebuddy # byte-buddy-agent # 1.9.10 | <notextile></notextile>
Apache | [The Apache Software License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | net.minidev # accessors-smart # 2.4.2 | <notextile></notextile>
Apache | [The Apache Software License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | net.minidev # json-smart # 2.4.2 | <notextile></notextile>
Apache | [The Apache Software License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.commons # commons-math3 # 3.4.1 | <notextile></notextile>
Apache | [The Apache Software License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.curator # curator-client # 4.2.0 | <notextile></notextile>
Apache | [The Apache Software License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.curator # curator-framework # 4.2.0 | <notextile></notextile>
Apache | [The Apache Software License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.curator # curator-recipes # 4.2.0 | <notextile></notextile>
Apache | [The Apache Software License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.geronimo.specs # geronimo-jms_1.1_spec # 1.1.1 | <notextile></notextile>
Apache | [The Apache Software License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.hive # hive-common # 2.3.9 | <notextile></notextile>
Apache | [The Apache Software License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.hive # hive-exec # 2.3.9 | <notextile></notextile>
Apache | [The Apache Software License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.hive # hive-llap-client # 2.3.9 | <notextile></notextile>
Apache | [The Apache Software License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.hive # hive-llap-common # 2.3.9 | <notextile></notextile>
Apache | [The Apache Software License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.hive # hive-metastore # 2.3.9 | <notextile></notextile>
Apache | [The Apache Software License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.hive # hive-serde # 2.3.9 | <notextile></notextile>
Apache | [The Apache Software License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.hive # hive-shims # 2.3.9 | <notextile></notextile>
Apache | [The Apache Software License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.hive # hive-vector-code-gen # 2.3.9 | <notextile></notextile>
Apache | [The Apache Software License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.hive.shims # hive-shims-0.23 # 2.3.9 | <notextile></notextile>
Apache | [The Apache Software License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.hive.shims # hive-shims-common # 2.3.9 | <notextile></notextile>
Apache | [The Apache Software License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.hive.shims # hive-shims-scheduler # 2.3.9 | <notextile></notextile>
Apache | [The Apache Software License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.htrace # htrace-core4 # 4.1.0-incubating | <notextile></notextile>
Apache | [The Apache Software License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.ivy # ivy # 2.5.0 | <notextile></notextile>
Apache | [The Apache Software License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.parquet # parquet-column # 1.12.2 | <notextile></notextile>
Apache | [The Apache Software License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.parquet # parquet-common # 1.12.2 | <notextile></notextile>
Apache | [The Apache Software License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.parquet # parquet-encoding # 1.12.2 | <notextile></notextile>
Apache | [The Apache Software License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.parquet # parquet-format-structures # 1.12.2 | <notextile></notextile>
Apache | [The Apache Software License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.parquet # parquet-hadoop # 1.12.2 | <notextile></notextile>
Apache | [The Apache Software License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.parquet # parquet-jackson # 1.12.2 | <notextile></notextile>
Apache | [The Apache Software License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.servicemix.bundles # org.apache.servicemix.bundles.jzlib # 1.0.7_2 | <notextile></notextile>
Apache | [The Apache Software License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.thrift # libfb303 # 0.9.3 | <notextile></notextile>
Apache | [The Apache Software License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.thrift # libthrift # 0.12.0 | <notextile></notextile>
Apache | [The Apache Software License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | org.apache.velocity # velocity # 1.5 | <notextile></notextile>
Apache | [The Apache Software License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | org.codehaus.jackson # jackson-core-asl # 1.9.13 | <notextile></notextile>
Apache | [The Apache Software License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | org.codehaus.jackson # jackson-jaxrs # 1.9.2 | <notextile></notextile>
Apache | [The Apache Software License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | org.codehaus.jackson # jackson-mapper-asl # 1.9.13 | <notextile></notextile>
Apache | [The Apache Software License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | org.codehaus.jackson # jackson-xc # 1.9.2 | <notextile></notextile>
Apache | [The Apache Software License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | org.datanucleus # datanucleus-api-jdo # 4.2.4 | <notextile></notextile>
Apache | [The Apache Software License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | org.datanucleus # datanucleus-core # 4.1.17 | <notextile></notextile>
Apache | [The Apache Software License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | org.datanucleus # datanucleus-rdbms # 4.1.19 | <notextile></notextile>
Apache | [The Apache Software License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | org.datanucleus # javax.jdo # 3.2.0-m3 | <notextile></notextile>
Apache | [The Apache Software License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0.txt) | org.jetbrains # annotations # 17.0.0 | <notextile></notextile>
Apache | [The Apache Software License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | org.lz4 # lz4-java # 1.7.1 | <notextile></notextile>
Apache | [The Apache Software License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt) | stax # stax-api # 1.0.1 | <notextile></notextile>
Apache | [the Apache License, ASL Version 2.0](http://www.apache.org/licenses/LICENSE-2.0) | org.scalactic # scalactic_2.12 # 3.2.14 | <notextile></notextile>
Apache | [the Apache License, ASL Version 2.0](http://www.apache.org/licenses/LICENSE-2.0) | org.scalatest # scalatest-compatible # 3.2.14 | <notextile></notextile>
Apache | [the Apache License, ASL Version 2.0](http://www.apache.org/licenses/LICENSE-2.0) | org.scalatest # scalatest-core_2.12 # 3.2.14 | <notextile></notextile>
Apache | [the Apache License, ASL Version 2.0](http://www.apache.org/licenses/LICENSE-2.0) | org.scalatest # scalatest-diagrams_2.12 # 3.2.14 | <notextile></notextile>
Apache | [the Apache License, ASL Version 2.0](http://www.apache.org/licenses/LICENSE-2.0) | org.scalatest # scalatest-featurespec_2.12 # 3.2.14 | <notextile></notextile>
Apache | [the Apache License, ASL Version 2.0](http://www.apache.org/licenses/LICENSE-2.0) | org.scalatest # scalatest-flatspec_2.12 # 3.2.14 | <notextile></notextile>
Apache | [the Apache License, ASL Version 2.0](http://www.apache.org/licenses/LICENSE-2.0) | org.scalatest # scalatest-freespec_2.12 # 3.2.14 | <notextile></notextile>
Apache | [the Apache License, ASL Version 2.0](http://www.apache.org/licenses/LICENSE-2.0) | org.scalatest # scalatest-funspec_2.12 # 3.2.14 | <notextile></notextile>
Apache | [the Apache License, ASL Version 2.0](http://www.apache.org/licenses/LICENSE-2.0) | org.scalatest # scalatest-funsuite_2.12 # 3.2.14 | <notextile></notextile>
Apache | [the Apache License, ASL Version 2.0](http://www.apache.org/licenses/LICENSE-2.0) | org.scalatest # scalatest-matchers-core_2.12 # 3.2.14 | <notextile></notextile>
Apache | [the Apache License, ASL Version 2.0](http://www.apache.org/licenses/LICENSE-2.0) | org.scalatest # scalatest-mustmatchers_2.12 # 3.2.14 | <notextile></notextile>
Apache | [the Apache License, ASL Version 2.0](http://www.apache.org/licenses/LICENSE-2.0) | org.scalatest # scalatest-propspec_2.12 # 3.2.14 | <notextile></notextile>
Apache | [the Apache License, ASL Version 2.0](http://www.apache.org/licenses/LICENSE-2.0) | org.scalatest # scalatest-refspec_2.12 # 3.2.14 | <notextile></notextile>
Apache | [the Apache License, ASL Version 2.0](http://www.apache.org/licenses/LICENSE-2.0) | org.scalatest # scalatest-shouldmatchers_2.12 # 3.2.14 | <notextile></notextile>
Apache | [the Apache License, ASL Version 2.0](http://www.apache.org/licenses/LICENSE-2.0) | org.scalatest # scalatest-wordspec_2.12 # 3.2.14 | <notextile></notextile>
Apache | [the Apache License, ASL Version 2.0](http://www.apache.org/licenses/LICENSE-2.0) | org.scalatest # scalatest_2.12 # 3.2.14 | <notextile></notextile>
BSD | [3-Clause BSD License](https://opensource.org/licenses/BSD-3-Clause) | com.esotericsoftware # kryo-shaded # 4.0.2 | <notextile></notextile>
BSD | [3-Clause BSD License](https://opensource.org/licenses/BSD-3-Clause) | com.google.protobuf # protobuf-java # 3.14.0 | <notextile></notextile>
BSD | [BSD](LICENSE.txt) | com.thoughtworks.paranamer # paranamer # 2.8 | <notextile></notextile>
BSD | [BSD](https://github.com/sbt/test-interface/blob/master/LICENSE) | org.scala-sbt # test-interface # 1.0 | <notextile></notextile>
BSD | [BSD 2-Clause](http://opensource.org/licenses/BSD-2-Clause) | com.github.wendykierp # JTransforms # 3.1 | <notextile></notextile>
BSD | [BSD 2-Clause](http://opensource.org/licenses/BSD-2-Clause) | pl.edu.icm # JLargeArrays # 1.5 | <notextile></notextile>
BSD | [BSD 2-Clause License](https://opensource.org/licenses/BSD-2-Clause) | com.github.luben # zstd-jni # 1.5.0-4 | <notextile></notextile>
BSD | [BSD 2-Clause license](http://opensource.org/licenses/BSD-2-Clause) | dnsjava # dnsjava # 2.1.7 | <notextile></notextile>
BSD | [BSD 3 Clause](http://opensource.org/licenses/BSD-3-Clause) | com.github.fommil.netlib # core # 1.1.2 | <notextile></notextile>
BSD | [BSD 3-clause](http://opensource.org/licenses/BSD-3-Clause) | org.scala-lang.modules # scala-xml_2.12 # 1.1.0 | <notextile></notextile>
BSD | [BSD 3-clause](https://opensource.org/licenses/BSD-3-Clause) | org.scalacheck # scalacheck_2.12 # 1.15.2 | <notextile></notextile>
BSD | [BSD 3-clause](https://raw.githubusercontent.com/ThreeTen/threeten-extra/master/LICENSE.txt) | org.threeten # threeten-extra # 1.5.0 | <notextile></notextile>
BSD | [BSD License](http://javolution.org/LICENSE.txt) | javolution # javolution # 5.5.1 | <notextile></notextile>
BSD | [BSD licence](http://antlr.org/license.html) | org.antlr # ST4 # 4.0.4 | <notextile></notextile>
BSD | [BSD licence](http://antlr.org/license.html) | org.antlr # antlr-runtime # 3.5.2 | <notextile></notextile>
BSD | [BSD-3-Clause](https://asm.ow2.io/license.html) | org.ow2.asm # asm # 8.0.1 | <notextile></notextile>
BSD | [Modified BSD](http://asm.objectweb.org/license.html) | org.glassfish.jersey.core # jersey-server # 2.34 | <notextile></notextile>
BSD | [New BSD License](http://www.opensource.org/licenses/bsd-license.php) | com.esotericsoftware # minlog # 1.3.0 | <notextile></notextile>
BSD | [New BSD License](https://raw.githubusercontent.com/janino-compiler/janino/master/LICENSE) | org.codehaus.janino # commons-compiler # 3.0.16 | <notextile></notextile>
BSD | [New BSD License](https://raw.githubusercontent.com/janino-compiler/janino/master/LICENSE) | org.codehaus.janino # janino # 3.0.16 | <notextile></notextile>
BSD | [New BSD License](http://www.opensource.org/licenses/bsd-license.php) | org.hamcrest # hamcrest-core # 1.3 | <notextile></notextile>
BSD | [Revised BSD](http://www.jcraft.com/jsch/LICENSE.txt) | com.jcraft # jsch # 0.1.55 | <notextile></notextile>
BSD | [The BSD 3-Clause License](http://www.opensource.org/licenses/BSD-3-Clause) | org.fusesource.leveldbjni # leveldbjni-all # 1.8 | <notextile></notextile>
BSD | [The BSD License](http://www.opensource.org/licenses/bsd-license.php) | jline # jline # 2.12 | <notextile></notextile>
BSD | [The BSD License](http://www.opensource.org/licenses/bsd-license.php) | net.sourceforge.f2j # arpack_combined_all # 0.1 | <notextile></notextile>
BSD | [The BSD License](http://www.antlr.org/license.html) | org.antlr # antlr4-runtime # 4.8 | <notextile></notextile>
BSD | [The BSD License](http://www.opensource.org/licenses/bsd-license.php) | org.codehaus.woodstox # stax2-api # 4.2.1 | <notextile></notextile>
BSD | [The New BSD License](http://www.opensource.org/licenses/bsd-license.html) | net.sf.py4j # py4j # 0.10.9.3 | <notextile></notextile>
BSD | [The New BSD License](http://jodd.org/license.html) | org.jodd # jodd-core # 3.5.2 | <notextile></notextile>
CDDL | [
                CDDL License
            ](http://www.opensource.org/licenses/cddl1.php) | javax.ws.rs # jsr311-api # 1.1.1 | <notextile></notextile>
CDDL | [COMMON DEVELOPMENT AND DISTRIBUTION LICENSE (CDDL) Version 1.0](https://glassfish.dev.java.net/public/CDDLv1.0.html) | javax.activation # activation # 1.1.1 | <notextile></notextile>
GPL | [GPL2 w/ CPE](http://glassfish.java.net/public/CDDL+GPL_1_1.html) | com.sun.jersey # jersey-core # 1.19 | <notextile></notextile>
GPL | [GPL2 w/ CPE](http://glassfish.java.net/public/CDDL+GPL_1_1.html) | com.sun.jersey # jersey-json # 1.19 | <notextile></notextile>
GPL | [GPL2 w/ CPE](http://glassfish.java.net/public/CDDL+GPL_1_1.html) | com.sun.jersey # jersey-server # 1.19 | <notextile></notextile>
GPL | [GPL2 w/ CPE](http://glassfish.java.net/public/CDDL+GPL_1_1.html) | com.sun.jersey # jersey-servlet # 1.19 | <notextile></notextile>
GPL | [GPL2 w/ CPE](https://glassfish.java.net/public/CDDL+GPL_1_1.html) | com.sun.xml.bind # jaxb-impl # 2.2.3-1 | <notextile></notextile>
GPL | [GPL2 w/ CPE](https://www.gnu.org/software/classpath/license.html) | jakarta.annotation # jakarta.annotation-api # 1.3.5 | <notextile></notextile>
GPL | [GPL2 w/ CPE](https://www.gnu.org/software/classpath/license.html) | jakarta.servlet # jakarta.servlet-api # 4.0.3 | <notextile></notextile>
GPL | [GPL2 w/ CPE](https://www.gnu.org/software/classpath/license.html) | jakarta.ws.rs # jakarta.ws.rs-api # 2.1.6 | <notextile></notextile>
GPL | [GPL2 w/ CPE](https://glassfish.java.net/public/CDDL+GPL_1_1.html) | javax.xml.bind # jaxb-api # 2.2.11 | <notextile></notextile>
GPL | [GPL2 w/ CPE](https://www.gnu.org/software/classpath/license.html) | org.glassfish.hk2 # hk2-api # 2.6.1 | <notextile></notextile>
GPL | [GPL2 w/ CPE](https://www.gnu.org/software/classpath/license.html) | org.glassfish.hk2 # hk2-locator # 2.6.1 | <notextile></notextile>
GPL | [GPL2 w/ CPE](https://www.gnu.org/software/classpath/license.html) | org.glassfish.hk2 # hk2-utils # 2.6.1 | <notextile></notextile>
GPL | [GPL2 w/ CPE](https://www.gnu.org/software/classpath/license.html) | org.glassfish.hk2 # osgi-resource-locator # 1.0.3 | <notextile></notextile>
GPL | [GPL2 w/ CPE](https://www.gnu.org/software/classpath/license.html) | org.glassfish.hk2.external # aopalliance-repackaged # 2.6.1 | <notextile></notextile>
GPL | [GPL2 w/ CPE](https://www.gnu.org/software/classpath/license.html) | org.glassfish.hk2.external # jakarta.inject # 2.6.1 | <notextile></notextile>
GPL with Classpath Extension | [CDDL + GPLv2 with classpath exception](https://github.com/javaee/javax.annotation/blob/master/LICENSE) | javax.annotation # javax.annotation-api # 1.3.2 | <notextile></notextile>
GPL with Classpath Extension | [CDDL + GPLv2 with classpath exception](https://glassfish.dev.java.net/nonav/public/CDDL+GPL.html) | javax.servlet # javax.servlet-api # 3.1.0 | <notextile></notextile>
MIT | [MIT](https://opensource.org/licenses/mit-license.php) | dev.ludovic.netlib # arpack # 2.2.1 | <notextile></notextile>
MIT | [MIT](https://opensource.org/licenses/mit-license.php) | dev.ludovic.netlib # blas # 2.2.1 | <notextile></notextile>
MIT | [MIT](https://opensource.org/licenses/mit-license.php) | dev.ludovic.netlib # lapack # 2.2.1 | <notextile></notextile>
MIT | [MIT](https://opensource.org/licenses/MIT) | org.mockito # mockito-scala_2.12 # 1.7.0 | <notextile></notextile>
MIT | [MIT](https://opensource.org/licenses/MIT) | org.scalamock # scalamock_2.12 # 4.1.0 | <notextile></notextile>
MIT | [MIT](http://opensource.org/licenses/MIT) | org.typelevel # algebra_2.12 # 2.0.1 | <notextile></notextile>
MIT | [MIT](http://opensource.org/licenses/MIT) | org.typelevel # cats-kernel_2.12 # 2.1.1 | <notextile></notextile>
MIT | [MIT](http://opensource.org/licenses/MIT) | org.typelevel # spire-macros_2.12 # 0.17.0 | <notextile></notextile>
MIT | [MIT](http://opensource.org/licenses/MIT) | org.typelevel # spire-platform_2.12 # 0.17.0 | <notextile></notextile>
MIT | [MIT](http://opensource.org/licenses/MIT) | org.typelevel # spire-util_2.12 # 0.17.0 | <notextile></notextile>
MIT | [MIT](http://opensource.org/licenses/MIT) | org.typelevel # spire_2.12 # 0.17.0 | <notextile></notextile>
MIT | [MIT License](https://raw.githubusercontent.com/irmen/Pyrolite/master/LICENSE) | net.razorvine # pyrolite # 4.30 | <notextile></notextile>
MIT | [MIT License](http://www.opensource.org/licenses/mit-license.php) | org.slf4j # jul-to-slf4j # 1.7.30 | <notextile></notextile>
MIT | [MIT License](http://www.opensource.org/licenses/mit-license.php) | org.slf4j # slf4j-api # 1.7.30 | <notextile></notextile>
MIT | [MIT license](http://www.opensource.org/licenses/mit-license.php) | org.codehaus.mojo # animal-sniffer-annotations # 1.17 | <notextile></notextile>
MIT | [The MIT License](http://opensource.org/licenses/MIT) | org.checkerframework # checker-qual # 2.5.2 | <notextile></notextile>
MIT | [The MIT License](https://github.com/mockito/mockito/blob/master/LICENSE) | org.mockito # mockito-core # 3.1.0 | <notextile></notextile>
MIT | [The MIT License](https://raw.githubusercontent.com/xvik/generics-resolver/master/LICENSE) | ru.vyarus # generics-resolver # 3.0.1 | <notextile></notextile>
Mozilla | [MPL 1.1](http://www.mozilla.org/MPL/MPL-1.1.html) | org.javassist # javassist # 3.25.0-GA | <notextile></notextile>
Mozilla | [Mozilla Public License, version 2.0](https://www.mozilla.org/MPL/2.0/) | com.github.pureconfig # pureconfig-core_2.12 # 0.12.1 | <notextile></notextile>
Mozilla | [Mozilla Public License, version 2.0](https://www.mozilla.org/MPL/2.0/) | com.github.pureconfig # pureconfig-generic_2.12 # 0.12.1 | <notextile></notextile>
Mozilla | [Mozilla Public License, version 2.0](https://www.mozilla.org/MPL/2.0/) | com.github.pureconfig # pureconfig-macros_2.12 # 0.12.1 | <notextile></notextile>
Mozilla | [Mozilla Public License, version 2.0](https://www.mozilla.org/MPL/2.0/) | com.github.pureconfig # pureconfig_2.12 # 0.12.1 | <notextile></notextile>
Public Domain | [Public Domain](https://creativecommons.org/publicdomain/zero/1.0/) | org.glassfish.jersey.containers # jersey-container-servlet # 2.34 | <notextile></notextile>
Public Domain | [Public Domain](https://creativecommons.org/publicdomain/zero/1.0/) | org.glassfish.jersey.containers # jersey-container-servlet-core # 2.34 | <notextile></notextile>
Public Domain | [Public Domain](https://creativecommons.org/publicdomain/zero/1.0/) | org.glassfish.jersey.core # jersey-client # 2.34 | <notextile></notextile>
Public Domain | [Public Domain](https://creativecommons.org/publicdomain/zero/1.0/) | org.glassfish.jersey.core # jersey-common # 2.34 | <notextile></notextile>
Public Domain | [Public Domain](https://creativecommons.org/publicdomain/zero/1.0/) | org.glassfish.jersey.inject # jersey-hk2 # 2.34 | <notextile></notextile>
Public Domain | [Public Domain](null) | org.tukaani # xz # 1.8 | <notextile></notextile>
unrecognized | [Bosch Internal Open Source License v4](http://bios.intranet.bosch.com/bioslv4.txt) | com.bosch.bidos # solace-source-sink_2.12 # 2.0.0 | <notextile></notextile>
unrecognized | [EDL 1.0](http://www.eclipse.org/org/documents/edl-v10.php) | jakarta.activation # jakarta.activation-api # 1.2.1 | <notextile></notextile>
unrecognized | [Eclipse Distribution License - v 1.0](http://www.eclipse.org/org/documents/edl-v10.php) | com.sun.istack # istack-commons-runtime # 3.0.8 | <notextile></notextile>
unrecognized | [Eclipse Distribution License - v 1.0](http://www.eclipse.org/org/documents/edl-v10.php) | jakarta.xml.bind # jakarta.xml.bind-api # 2.3.2 | <notextile></notextile>
unrecognized | [Eclipse Distribution License - v 1.0](http://www.eclipse.org/org/documents/edl-v10.php) | org.glassfish.jaxb # jaxb-runtime # 2.3.2 | <notextile></notextile>
unrecognized | [Eclipse Public License 1.0](http://www.eclipse.org/legal/epl-v10.html) | junit # junit # 4.12 | <notextile></notextile>
unrecognized | [SOLACE CORPORATION LICENSE AGREEMENT](https://solace.com/license-software) | com.solacesystems # sol-jms # 10.15.0 | <notextile></notextile>
unrecognized | [The Go license](https://golang.org/LICENSE) | com.google.re2j # re2j # 1.1 | <notextile></notextile>
unrecognized | [Unknown License](http://asm.ow2.org/license.html) | org.apache.xbean # xbean-asm9-shaded # 4.20 | <notextile></notextile>
unrecognized | [none specified](none specified) | javax.servlet.jsp # jsp-api # 2.1 | <notextile></notextile>
unrecognized | [none specified](none specified) | javax.transaction # jta # 1.1 | <notextile></notextile>
unrecognized | [none specified](none specified) | javax.transaction # transaction-api # 1.1 | <notextile></notextile>
unrecognized | [none specified](none specified) | org.codehaus.jettison # jettison # 1.1 | <notextile></notextile>
unrecognized | [none specified](none specified) | oro # oro # 2.0.8 | <notextile></notextile>
