#!/bin/bash

if [[ -z $1 || -z $2 || -z $3 || -z $4 || -z $5 ]]; then
    echo '%s\n' "Error:Five necessary arguments need to be supplied: [PRINCIPAL] [KEYTAB] [VERSION] [QUEUE] [CONF]"  >&2 &&
    exit
fi
# Example usage
# principal: the principal used to submit the pipeline, e.g. srv-ae-si01@RB-AE-SI01.BDPS.BOSCH-ORG.COM
# keytab: the keytab containing the credentials, e.g. srv-ae-si01.keytab
# sparkutilities  version: the version of vasapi to be used, e.g. 1.0.14
# queue: the YARN queue on a Hadoop cluster to which the job must be submitted, e.g. root.users.srv-ae-si01
# configuration file: the configuration file to be used, e.g. application.conf

function getAppCount {
   APPLN_NAME=$1
   APPCOUNT=`yarn application -list -appStates NEW,NEW_SAVING,SUBMITTED,ACCEPTED,RUNNING | grep -c $APPLN_NAME`
   echo $APPCOUNT
}

PRINCIPAL=$1
KEYTAB=$2
VERSION=$3
QUEUE=$4
CONF=$5
APP_NAME=$USER-$CONF
if [ $(getAppCount $APP_NAME) -le 0 ]
then
# Definition of variables, used to control the spark submit
ARTIFACTID=spark-utilities_2.11
JAR="https://rb-artifactory.bosch.com/artifactory/BIDOS/com/bosch/bidos/${ARTIFACTID}/${VERSION}/${ARTIFACTID}-${VERSION}.jar"
CLASS=com.bosch.bidos.MergeMain
PACKAGES=com.bosch.bidos:$ARTIFACTID:$VERSION
REPOSITORIES=https://rb-artifactory.bosch.com/artifactory/BIDOS,https://rb-artifactory.bosch.com/artifactory/maven-central-remote,https://rb-artifactory.bosch.com/artifactory/cloudera-maven-remote
kinit -kt $KEYTAB $PRINCIPAL

# From and To-Date calculation and copied parameterzied file to application.conf
FROM_DATE=$(date -d "$(date) -2 day" +%Y-%m-%d)
TO_DATE=$(date -d "$(date) -2 day" +%Y-%m-%d)
cp $CONF application.conf
sed -i "s/from_date/$FROM_DATE/" application.conf
sed -i "s/to_date/$TO_DATE/" application.conf

## Start part

spark-submit \
 --master yarn --deploy-mode cluster \
 --principal $PRINCIPAL --keytab $KEYTAB \
 --driver-memory 8G \
 --driver-cores 4 \
 --executor-cores 4 \
 --executor-memory 8G \
 --files application.conf,merger-log4j.properties \
 --conf "spark.driver.extraJavaOptions=-Dlog4j.configuration=merger-log4j.properties -Ddm.logging.level=DEBUG -Ddm.logging.name=merger-batch -Dconfig.file=application.conf" --conf "spark.executor.extraJavaOptions=-Dlog4j.configuration=merger-log4j.properties -Ddm.logging.level=DEBUG -Ddm.logging.name=merger-batch" \
 --conf spark.dynamicAllocation.enabled=false \
 --conf spark.sql.files.ignoreCorruptFiles=true \
 --name "$APP_NAME" --packages $PACKAGES --repositories $REPOSITORIES \
 --conf spark.hadoop.dfs.client.block.write.locateFollowingBlock.retries=10 \
 --conf spark.sql.streaming.schemaInference=true \
 --conf spark.driver.memoryOverhead=4096 \
 --conf spark.executor.memoryOverhead=4096 \
 --conf "spark.sql.parquet.writeLegacyFormat=true" \
 --conf "spark.sql.files.ignoreCorruptFiles=true" \
 --conf spark.yarn.maxAppAttempts=4 \
 --conf spark.yarn.am.attemptFailuresValidityInterval=1h \
 --conf spark.yarn.max.executor.failures=32 \
 --conf spark.yarn.executor.failuresValidityInterval=1h \
 --conf spark.task.maxFailures=8 \
 --conf spark.rpc.message.maxSize=1024 \
 --conf spark.executor.heartbeat.maxFailures=120 \
 --conf spark.executor.heartbeatInterval=200s \
 --conf spark.network.timeout=1200s  \
 --conf spark.akka.frameSize=1024 \
 --conf spark.sql.shuffle.partitions=30 \
 --conf spark.default.parallelism=30 \
 --conf spark.dynamicAllocation.enabled=true \
 --conf spark.dynamicAllocation.minExecutors=3 \
 --conf spark.dynamicAllocation.maxExecutors=5 \
 --conf spark.shuffle.service.enabled=true \
 --class $CLASS "$JAR"
exit
fi

