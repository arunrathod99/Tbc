source /opt/cloudera/parcels/bdps_anaconda-2020.03.13-111534/etc/profile.d/conda.sh

conda activate base
python start_script.py proc.tightening.vcu.application RB-AE-CLJP.BDPS.BOSCH-ORG.COM --datasize 1 1024 0.0.11 --additionalfiles template.vcu.tightening.application.conf CLJP.proc.tightening.vcu.parameter.conf