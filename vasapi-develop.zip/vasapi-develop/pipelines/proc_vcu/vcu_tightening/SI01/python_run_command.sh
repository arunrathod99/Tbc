source /opt/cloudera/parcels/bdps_anaconda-2020.03.13-111534/etc/profile.d/conda.sh

conda activate base
python ../../../../api/start_script.py proc.tightening.vcu.application RB-AE-SI01.BDPS.BOSCH-ORG.COM --datasize 2 3072 0.0.5-CDH6.3.3-SNAPSHOT --additionalfiles /opt/cloudera/var/home/t_vasapi_proc/VASAPI_SI01_TIGHTENING/bidos.stream-data-ingestion/pipelines/proc_vcu/template/template.vcu.tightening.application.conf SI01.proc.tightening.vcu.parameter.conf