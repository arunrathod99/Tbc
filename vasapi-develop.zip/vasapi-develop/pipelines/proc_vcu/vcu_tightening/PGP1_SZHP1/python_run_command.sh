source /opt/cloudera/parcels/bdps_anaconda-2020.03.13-111534/etc/profile.d/conda.sh

conda activate base
python ../../../../api/start_script.py PGP1.proc.tightening.vcu.application RB-AE-SZHP1.BDPS.BOSCH-ORG.COM --datasize 2 3072 0.0.5-CDH6.3.3-SNAPSHOT --additionalfiles /opt/cloudera/var/home/t_vcu_plc_pgp1_proc/VASAPI_PGP1_TIGHTENING/bidos.stream-data-ingestion/pipelines/proc_vcu/template/template.vcu.tightening.application.conf SZHP1.PGP1.proc.tightening.vcu.parameter.conf