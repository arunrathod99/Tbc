source /opt/cloudera/parcels/bdps_anaconda-2020.03.13-111534/etc/profile.d/conda.sh

conda activate base
python ../../../../api/start_script.py proc.dispensing.vcu.application RB-AE-PGP1.BDPS.BOSCH-ORG.COM --datasize 1 3072 0.0.11-SNAPSHOT --additionalfiles template.vcu.dispensing.application.conf PGP1.proc.dispensing.vcu.parameter.conf

