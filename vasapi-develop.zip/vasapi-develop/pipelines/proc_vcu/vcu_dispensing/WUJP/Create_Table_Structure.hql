USE proc_vcu_plc_wujp;
CREATE EXTERNAL TABLE `vcu_dispensing`(
  `messagename` string,
  `version` string,
  `timestamp` string,
  `uniqueid` string,
  `source` string,
  `target` string,
  `requestid` string,
  `uniquepartid` string,
  `productpartno` string,
  `productpartvariant` string,
  `referencekey` string,
  `meslocationid` string,
  `mesplantid` string,
  `mesproductid` string,
  `mesareaid` string,
  `globalmachineidentifier` string,
  `meslineno` string,
  `messtationno` string,
  `messtationidx` string,
  `mesfunctionno` bigint,
  `mesworkpos` string,
  `mestoolpos` string,
  `mesprocessno` string,
  `adtmeteringpressurecompa` string,
  `adtmeteringpressurecompb` string,
  `adtxaxisacceleration` string,
  `adtyaxisacceleration` string,
  `adtzaxisacceleration` string,
  `adtxaxisdeceleration` string,
  `adtyaxisdeceleration` string,
  `adtzaxisdcceleration` string,
  `adtxaxisspeed` string,
  `adtyaxisspeed` string,
  `adtzaxisspeed` string,
  `wpclifecycle` string,
  `wpcfamily` string,
  `wpclifecyclelimit` string,
  `wpcid` string,
  `exchangeplatelifecycle` string,
  `exchangeplatefamily` string,
  `exchangeplatelifecyclelimit` string,
  `exchangeplateid` string,
  `adtdeliverypressurecompa` string,
  `adtdeliverypressurecompb` string,
  `adtdispensestartat` string,
  `adtdispenseendat` string,
  `adtdispensepumpainstalltimeat` string,
  `adtdispensepumpbinstalltimeat` string,
  `adtdispensepumpareplacedtimeat` string,
  `adtdispensepumpbreplacedtimeat` string,
  `machinemodeid` string,
  `machineexecstate` string,
  `machineeventlist` string,
  `adtdispensingpointxx` string)
PARTITIONED BY (
  `process_date` string)
ROW FORMAT SERDE
  'org.apache.hadoop.hive.ql.io.parquet.serde.ParquetHiveSerDe'
STORED AS INPUTFORMAT
  'org.apache.hadoop.hive.ql.io.parquet.MapredParquetInputFormat'
OUTPUTFORMAT
  'org.apache.hadoop.hive.ql.io.parquet.MapredParquetOutputFormat'
LOCATION
  'hdfs://aeszhp1prod/proc/vcu_plc_wujp/vcu/dispensing/vcuDispensingOutput'
;