source /opt/cloudera/parcels/bdps_anaconda-2020.03.13-111534/etc/profile.d/conda.sh

conda activate base
python ../../../../api/start_script.py WUJP.proc.dispensing.vcu.application RB-AE-SZHP1.BDPS.BOSCH-ORG.COM --datasize 2 3072 0.0.5-CDH6.3.3-SNAPSHOT --additionalfiles /opt/cloudera/var/home/t_vcu_plc_wujp_proc/VASAPI_WUJP_DISPENSING/bidos.stream-data-ingestion/pipelines/proc_vcu/template/template.vcu.dispensing.application.conf SZHP1.WUJP.proc.dispensing.vcu.parameter.conf