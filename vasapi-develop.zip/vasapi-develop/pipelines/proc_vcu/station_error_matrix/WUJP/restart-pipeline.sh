function getAppCount {
   APPLN_NAME=$1
   APPCOUNT=`yarn application -list -appStates NEW,NEW_SAVING,SUBMITTED,ACCEPTED,RUNNING | grep -c $APPLN_NAME`
   echo $APPCOUNT
}
APP_NAME="vasapi.SZHP1.WUJP.proc.station.error.matrix.vcu.application"
if [ $(getAppCount $APP_NAME) -le 0 ]
then
source /opt/cloudera/parcels/bdps_anaconda-2020.03.13-111534/etc/profile.d/conda.sh

conda activate base
python start_script.py WUJP.proc.station.error.matrix.vcu.application RB-AE-SZHP1.BDPS.BOSCH-ORG.COM --datasize 1 --memoryOverheadDriver 1024 --memoryOverheadExecutor 1024 0.0.11 --additionalfiles template.vcu.station.error.matrix.application.conf SZHP1.WUJP.proc.station.error.matrix.vcu.parameter.conf
echo "Restarted at $(date) " >> restart.log 2>&1 &
else
echo "Already running"
fi