#!/usr/bin/env bash
########################################################################################################
#
# This Script will restart vasapi job if it is not running.
# Ex.sh restart_vasapi.sh <PLANT> <TABLE_NAME> <VASAPI_VERSION>
# sh restart_vasapi.sh "CLJP" "station_error_matrix" "0.0.11"
#
#########################################################################################################
plant_name=${1}
table_name=${2}
vasapi_version=${3}
function getAppCount {
   APPLN_NAME=$1
   APPCOUNT=`yarn application -list -appStates NEW,NEW_SAVING,SUBMITTED,ACCEPTED,RUNNING | grep -c $APPLN_NAME`
   echo $APPCOUNT
}
APP_NAME="vasapi."${plant_name}".proc.main."${table_name}".application"
if [ $(getAppCount $APP_NAME) -le 0 ]
then
source /opt/cloudera/parcels/bdps_anaconda-2020.03.13-111534/etc/profile.d/conda.sh
conda activate base
python ../scripts/start_script.py proc.${table_name}.vcu.application RB-AE-${plant_name}.BDPS.BOSCH-ORG.COM ${vasapi_version} --datasize 1 --memoryOverheadDriver 1024 --memoryOverheadExecutor 1024 --dynamicmemoryallocation "true" --dynamicmaxexecutor 4 --dynamicidletimeout 20s --executorcore 2 --additionalfiles ${plant_name}".proc."${table_name}".vcu.parameter.conf" "template.vcu.station.error.matrix*"
echo "Restarted at $(date) " >> restart.log 2>&1 &
else
echo "Already running"
fi