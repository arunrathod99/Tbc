#!/bin/bash

mosquitto_sub -h si0vm02909.de.bosch.com -p 1883 -u vasapi -P vasapi -t user/sfy8fe
