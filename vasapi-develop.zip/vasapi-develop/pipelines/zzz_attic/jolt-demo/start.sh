#!/bin/bash
[ $# -ne 3 ] &&
    printf '%s\n' "Error! Three arguments need to be supplied: [vasapi version] [queue] [configuration file]"  >&2 &&
    exit

# Example usage
# principal: the principal used to submit the pipeline, e.g. t_sji_proc@RB-AE-SI01.BDPS.BOSCH-ORG.COM
# keytab: the keytab containing the credentials, e.g. t_sji_proc.keytab
# vasapi version: the version of vasapi to be used, e.g. 0.0.2-SNAPSHOT
# queue: the YARN queue on a Hadoop cluster to which the job must be submitted, e.g. root.proc.sji
# configuration file: the configuration file to be used, e.g. sji-failure-count-aggregation.anp-on-si01.application.conf

VERSION=$1
QUEUE=$2
CONF=$3

# Definition of variables, used to control the spark submit and the creation of the initial table
ARTIFACTID=vasapi_2.11
#JAR="https://rb-artifactory.bosch.com/artifactory/BIDOS/com/bosch/asc/${ARTIFACTID}/${VERSION}/${ARTIFACTID}-${VERSION}.jar"
JAR="/home/sfy8fe/projects/smt/bidos.stream-data-ingestion/target/scala-2.11/vasapi_2.11-0.0.2-SNAPSHOT.jar"
CLASS=com.bosch.asc.vasapi.Pipeline
#PACKAGES=com.bosch.asc:$ARTIFACTID:$VERSION,com.bazaarvoice.jolt:jolt-core:0.1.1,com.bazaarvoice.jolt:json-utils:0.1.1
PACKAGES=com.bazaarvoice.jolt:jolt-core:0.1.1,com.bazaarvoice.jolt:json-utils:0.1.1,com.github.pureconfig:pureconfig_2.11:0.10.1,com.bosch.bidos:solace-source-sink_2.11:1.1.8-SNAPSHOT
REPOSITORIES=https://rb-artifactory.bosch.com/artifactory/BIDOS,https://rb-artifactory.bosch.com/artifactory/maven-central-remote,https://rb-artifactory.bosch.com/artifactory/cloudera-maven-remote,http://central.maven.org/maven2

## Start part

spark2-submit \
    --master yarn --deploy-mode client \
    --name $CONF \
    --driver-java-options "-Dconfig.file=$CONF" \
    --class $CLASS \
    --packages $PACKAGES \
    --repositories $REPOSITORIES \
    --queue $QUEUE \
    "$JAR"

#    --driver-memory 4G \
#    --principal $PRINCIPAL --keytab $KEYTAB \
#    --conf spark.yarn.submit.waitAppCompletion=false \
#    --conf spark.sql.shuffle.partitions=5 \
#    --conf spark.hadoop.dfs.client.block.write.locateFollowingBlock.retries=10 \
#    --files $CONF#application.conf --driver-java-options "-Dconfig.file=application.conf -Dcom.bosch.asc.sparkstreamssolace.replay.block.size=100" \
exit
