source /opt/cloudera/parcels/bdps_anaconda-2020.03.13-111534/etc/profile.d/conda.sh

conda activate base
python ../../../../api/start_script.py proc.c120_header.application RB-AE-SZHP1.BDPS.BOSCH-ORG.COM --datasize 1 2048 0.0.5-CDH6.3.3-SNAPSHOT --additionalfiles /opt/cloudera/var/home/t_ib2_promaster_nanjing_proc/VASAPI_SZHP1_C120_HEADER/bidos.stream-data-ingestion/pipelines/proc_ib2_promaster_nanjing/template/template.c120_header.application.conf SZHP1.proc.c120_header.parameter.conf