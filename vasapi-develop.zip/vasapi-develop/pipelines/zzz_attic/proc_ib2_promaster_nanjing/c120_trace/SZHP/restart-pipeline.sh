function getAppCount {
   APPLN_NAME=$1
   APPCOUNT=`yarn application -list -appStates NEW,NEW_SAVING,SUBMITTED,ACCEPTED,RUNNING | grep -c $APPLN_NAME`
   echo $APPCOUNT
}
APP_NAME="vasapi.SZHP1.proc.c120_trace.application"
if [ $(getAppCount $APP_NAME) -le 0 ]
then
sh python_run_command.sh
echo "Restarted at $(date) " >> restart.log 2>&1 &
else
echo "Already running"
fi