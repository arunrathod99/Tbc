USE proc_ib2_promaster_nanjing;
CREATE EXTERNAL TABLE `c110_trace`(
  `PPpartNo` string,
  `Line` string,
  `LogicalId` string,
  `HeaderID` string,
  `Station` string,
  `ProcessingDate` string,
  `Motor_Serial_No` string
  )
PARTITIONED BY (
  `process_date` string)
ROW FORMAT SERDE
  'org.apache.hadoop.hive.ql.io.parquet.serde.ParquetHiveSerDe'
STORED AS INPUTFORMAT
  'org.apache.hadoop.hive.ql.io.parquet.MapredParquetInputFormat'
OUTPUTFORMAT
  'org.apache.hadoop.hive.ql.io.parquet.MapredParquetOutputFormat'
LOCATION
  'hdfs://aeszhp1prod/proc/ib2_promaster_nanjing/cc_c110/c110_trace/cc_c110TraceOutputPlc/'
;