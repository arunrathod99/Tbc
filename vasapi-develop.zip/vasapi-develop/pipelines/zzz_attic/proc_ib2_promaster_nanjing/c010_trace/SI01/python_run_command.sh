source /opt/cloudera/parcels/bdps_anaconda-2020.03.13-111534/etc/profile.d/conda.sh

conda activate base
python ../../../../api/start_script.py proc.c010_trace.application RB-AE-SI01.BDPS.BOSCH-ORG.COM --datasize 1 2048 0.0.5-CDH6.3.3-SNAPSHOT --additionalfiles /opt/cloudera/var/home/t_vasapi_proc/VASAPI_SI01_C010_TRACE/bidos.stream-data-ingestion/pipelines/proc_ib2_promaster_nanjing/template/template.c010_trace.application.conf SI01.proc.c010_trace.parameter.conf