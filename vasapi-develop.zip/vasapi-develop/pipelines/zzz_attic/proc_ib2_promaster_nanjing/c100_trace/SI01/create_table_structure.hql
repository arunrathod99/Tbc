CREATE EXTERNAL TABLE `c100_trace`(
  `PPpartNo` string,
  `Line` string,
  `LogicalId` string,
  `HeaderID` string,
  `Station` string,
  `ProcessingDate` string,
  `Motor_Serial_No` string
  )
PARTITIONED BY (
  `process_date` string)
ROW FORMAT SERDE
  'org.apache.hadoop.hive.ql.io.parquet.serde.ParquetHiveSerDe'
STORED AS INPUTFORMAT
  'org.apache.hadoop.hive.ql.io.parquet.MapredParquetInputFormat'
OUTPUTFORMAT
  'org.apache.hadoop.hive.ql.io.parquet.MapredParquetOutputFormat'
LOCATION
  'hdfs://aesi01dev/proc/vasapi/cc_c100/c100_trace/cc_c100TraceOutputPlc/'
;