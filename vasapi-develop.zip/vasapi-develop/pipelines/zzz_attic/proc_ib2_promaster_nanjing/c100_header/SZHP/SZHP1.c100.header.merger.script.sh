#!/bin/bash

if [[ -z $1 || -z $2 || -z $3 || -z $4 || -z $5 ]]; then
    echo '%s\n' "Error:Five necessary arguments need to be supplied: [PRINCIPAL] [KEYTAB] [VERSION] [QUEUE] [CONF]"  >&2 &&
    exit
fi
# Example usage
# principal: the principal used to submit the pipeline, e.g. srv-ae-si01@RB-AE-SI01.BDPS.BOSCH-ORG.COM
# keytab: the keytab containing the credentials, e.g. srv-ae-si01.keytab
# sparkutilities  version: the version of vasapi to be used, e.g. 1.0.2
# queue: the YARN queue on a Hadoop cluster to which the job must be submitted, e.g. root.users.srv-ae-si01
# configuration file: the configuration file to be used, e.g. application.conf

PRINCIPAL=$1
KEYTAB=$2
VERSION=$3
QUEUE=$4
CONF=$5

# Definition of variables, used to control the spark submit and the creation of the initial table
ARTIFACTID=spark-utilities_2.11
#VERSION=1.0.2
JAR="https://rb-artifactory.bosch.com/artifactory/BIDOS/com/bosch/bidos/${ARTIFACTID}/${VERSION}/${ARTIFACTID}-${VERSION}.jar"
CLASS=com.bosch.bidos.MergeMain
PACKAGES=com.bosch.bidos:$ARTIFACTID:$VERSION
REPOSITORIES=https://rb-artifactory.bosch.com/artifactory/BIDOS,https://rb-artifactory.bosch.com/artifactory/maven-central-remote,https://rb-artifactory.bosch.com/artifactory/cloudera-maven-remote

kinit -kt $KEYTAB $PRINCIPAL

## Start part

spark-submit \
 --master yarn --deploy-mode cluster \
 --num-executors 12 \
 --driver-memory 4G \
 --executor-cores 4 \
 --executor-memory 8G \
 --conf spark.dynamicAllocation.enabled=false \
 --conf spark.ui.view.acls.groups=DE/idm2bcd_aesi01dev_global_read \
 --name "$CONF" --packages $PACKAGES \
 --class $CLASS \
 --repositories $REPOSITORIES \
 --queue $QUEUE \
 --files $CONF#application.conf --driver-java-options "-Dconfig.file=$CONF" "$JAR"

## Need to change once data available for vcu tables
impala_wrapper.sh -q "use proc_ib2_promaster_nanjing; refresh c100_header;"

exit