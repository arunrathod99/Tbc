cat empty_delete_htvp_sensor.scala | spark-shell --master yarn --deploy-mode client --executor-cores 3 --num-executors 2 --executor-memory 3g
