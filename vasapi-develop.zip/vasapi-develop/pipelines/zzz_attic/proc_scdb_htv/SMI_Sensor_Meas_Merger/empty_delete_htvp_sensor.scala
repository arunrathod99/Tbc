import org.apache.hadoop.fs.{FileSystem, Path}

val invalidFilePaths = Seq("/proc/scdb_htv/sensorMeasOutput_output/prod_proc=FT",
  "/proc/scdb_htv/sensorMeasOutput_output/prod_proc=TTX",
  "/proc/scdb_htv/sensorMeasOutput_output/prod_proc=TTY",
  "/proc/scdb_htv/sensorMeasOutput_output/prod_proc=TC",
  "/proc/scdb_htv/sensorMeasOutput_output/prod_proc=TCH",
  "/proc/scdb_htv/sensorMeasOutput_output/prod_proc=TCV",
  "/proc/scdb_htv/device_meas/prod_proc=FA",
  "/proc/scdb_htv/device_meas/prod_proc=FT",
  "/proc/scdb_htv/device_meas/prod_proc=Feinabgleich",
  "/proc/scdb_htv/device_meas/prod_proc=Funktionstest",
  "/proc/scdb_htv/device_meas/prod_proc=MM3-Drehkammer",
  "/proc/scdb_htv/device_meas/prod_proc=MM3-Statische-Kammer",
  "/proc/scdb_htv/device_meas/prod_proc=TC"
)

def deleteInvalidFiles(fileSystem: FileSystem, paths : Seq[String], size : Int) = {
  for ( p <- paths ){
    println(p)
    fileSystem.listStatus(new Path(p)).flatMap(e => fileSystem.listStatus(e.getPath)).flatMap(e => fileSystem.listStatus(e.getPath)).flatMap(e => fileSystem.listStatus(e.getPath)).filter(e =>e.getPath.getName.contains("parquet") && e.getLen==size && ((System.currentTimeMillis() - e.getModificationTime) / (60 * 1000 * 60 )) >= 4).foreach( e => fileSystem.delete(e.getPath, true))
  }}

val fileSystem = FileSystem.get(spark.sparkContext.hadoopConfiguration)

deleteInvalidFiles(fileSystem, invalidFilePaths, 4)
deleteInvalidFiles(fileSystem, invalidFilePaths, 0)