
**Launching script with the Python-based launcher:**
```bash
#!/bin/bash
cd  ${HOME}/bidos.stream-data-ingestion/pipelines/proc_active_alignment

python ../../api/start_script.py test.active_alignment_beta2.video_vs.application RB-AE-HTVP.BDPS.BOSCH-ORG.COM --datasize 1 1024 "0.0.5" --additionalfiles "template/template.active_alignment.conf" "all_clusters.default.conf"

```

**Launching app with the launcher attached in the project file:**
```bash
#!/bin/bash
cd  ${HOME}/bidos.stream-data-ingestion/pipelines/proc_active_alignment

bash api/start.sh test.active_alignment_beta2.video_vs.application RB-AE-HTVP.BDPS.BOSCH-ORG.COM 1 1024 0.0.5 "template/template.active_alignment.conf,all_clusters.default.conf"
```

**Merging script example:**
```bash
#!/bin/bash
cd ${HOME}/${USER}/icam_active_alignment_adapter/main/bidos.stream-data-ingestion/pipelines/proc_active_alignment
KRB5_CONFIG=/etc/krb5-puppet.conf 
kinit -k -t ${HOME}/${USER}.keytab ${USER}
api/vasapi_merger.sh t_smt_proc@RB-AE-HTVP.BDPS.BOSCH-ORG.COM ${HOME}/${USER}.keytab 1.0.5 root.proc.video_vs HtvP.main.video_vs.active_alignment.merge.conf
```

**Crontab entry for merging script**
```bash
@reboot sleep 300 && /${HOME}/active_alignment_start.sh
0 1 * * * /${HOME}/active_alignment_merge.sh >/dev/null 2>&1
```

**Deleting data files during development:**
```bash
hdfs dfs -rm -r -f /test/htvp_sandbox/active_alignment_poc_v1/*
```

**Storing Solace password (deletion and creation):**
```bash
hadoop credential delete ${USER}.solace.vasapi.password  -provider jceks:///user/${USER}/${USER}.jceks
hadoop credential create ${USER}.solace.vasapi.password  -provider jceks:///user/${USER}/${USER}.jceks
```
See more about this command at 
https://hadoop.apache.org/docs/current/hadoop-project-dist/hadoop-common/CommandsManual.html#credential
