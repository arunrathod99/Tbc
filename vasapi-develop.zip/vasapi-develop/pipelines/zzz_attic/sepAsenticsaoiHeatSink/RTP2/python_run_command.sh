source /opt/cloudera/parcels/bdps_anaconda-2020.03.13-111534/etc/profile.d/conda.sh

conda activate base
python start_script.py proc.webscada.sepAsenticsaoiHeatSink.application RB-AE-RTP2.BDPS.BOSCH-ORG.COM 0.0.11 --datasize 1 --executorcore 2 --memoryOverheadDriver 1024 --memoryOverheadExecutor 1024 --dynamicmemoryallocation true --dynamicmaxexecutor 3 --dynamicidletimeout 20s  --additionalfiles /opt/cloudera/var/home/t_finalassembly_proc/bidos.stream-data-ingestion/pipelines/proc_webscada/template/template.webscada.sepAsenticsaoiHeatSink.application.conf RTP2.proc.webscada.sepAsenticsaoiHeatSink.parameter.conf
