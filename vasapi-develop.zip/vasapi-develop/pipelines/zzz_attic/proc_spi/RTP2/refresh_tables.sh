#!/usr/bin/env bash
########################################################################################################
#
# This Script will refresh tables in imapla and needs DB name as parameter
# Ex.sh refresh_tables.sh <db_name=<DataBase Name>> <"table_list=<table Lists in a File>"> OR <"table_name=<Table Name>">
# sh refresh_tables.sh "db_name=proc_vasapi" "table_list=table_list.txt"
# sh refresh_tables.sh "db_name=proc_vasapi" "table_name=momwsmd1"
#
#########################################################################################################

if [ $# -lt 1 ]; then
    echo "Error! DB Name should be passed.Arguments to the script are :[DB_NAME]"
    exit
fi
refresh_filelist=refresh_cmd.txt
hive_tablelist=hive_table_list.txt
rm $refresh_filelist $hive_tablelist

for ARGUMENT in "$@"
do
key=$(echo $ARGUMENT | cut -f1 -d=)
value=$(echo $ARGUMENT | cut -f2 -d=)
if [ ${key} == "db_name" ]
then
db_name=${value}
elif [ ${key} == "table_name" ]
then
echo "${value}" > ${hive_tablelist}
else
hive_tablelist=$value
fi
done

if [ -z "${hive_tablelist}" ]; then
#listing tables in db
hive -e "show tables in $db_name" | grep -v 'WARN' | grep -v 'tab_name' | grep -v '+' | sed 's/|//g' > $hive_tablelist
fi

#forming refresh cmd for all tables
while read line
do
echo "refresh $db_name.$line;" >> $refresh_filelist
done < $hive_tablelist

echo "exit;" >> $refresh_filelist

#executing refresh cmd
impala_wrapper.sh -f $refresh_filelist
echo "Script Complete"

