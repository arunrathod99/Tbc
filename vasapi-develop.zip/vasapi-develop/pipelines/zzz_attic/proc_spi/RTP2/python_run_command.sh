source /opt/cloudera/parcels/bdps_anaconda-2020.03.13-111534/etc/profile.d/conda.sh

conda activate base
python ../../../api/start_script.py proc.main.spi.application RB-AE-RTP2.BDPS.BOSCH-ORG.COM "0.0.12" --memoryOverheadDriver 1024 --memoryOverheadExecutor 1024 --dynamicmemoryallocation true --dynamicmaxexecutor 10 --dynamicidletimeout 60 --additionalfiles "../template/template.spi_pm5.base.application.conf" "RTP2.proc.main.spi.parameter.conf" "../schemas/com.bosch.ae.smt.spi.TestData-2.0.0-schema.json"