source /opt/cloudera/parcels/bdps_anaconda-2020.03.13-111534/etc/profile.d/conda.sh
conda activate base
python start_script.py proc.main.rtp2ap1.application RB-AE-SI01.BDPS.BOSCH-ORG.COM --numexecutor 4 --executorcore 2 --executormemory 4 --drivermemory 8 --drivercore 4 --memoryOverheadDriver 3072 --memoryOverheadExecutor 1024  0.0.11-SNAPSHOT --additionalfiles template.v001.mes.query.application.conf template.mes_1.query.application.conf SI01.proc.main.rtp2ap1_1.parameter.conf
