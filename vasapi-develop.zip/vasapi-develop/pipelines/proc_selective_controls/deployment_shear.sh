#!/bin/bash
[ $# -ne 3 ] &&
    printf '%s\n' "ERROR: Three arguments need to be supplied: [principal] [keytab] [role type]"  >&2 &&
    exit

# Example usage
# principal: the principal used to submit the pipeline, e.g. t_sji_proc@RB-AE-SI01.BDPS.BOSCH-ORG.COM
# keytab: the keytab containing the credentials, e.g. t_sji_proc.keytab
# role type: the role type to be used, e.g. proc, test, share

PRINCIPAL=$1
KEYTAB=$2
ROLE_TYPE=$3

if [ "$ROLE_TYPE" != "share" ]; then
   kinit -kt $KEYTAB $PRINCIPAL
fi

# Create the directory to store the parquet files
hdfs dfs -mkdir -p "/$ROLE_TYPE/selective_controls/db/shear_results"

# Create the jceks file to store the password for Solace connection
hdfs dfs -test -e /$ROLE_TYPE/selective_controls/auth/solace_pw.jceks
jceks_exists=$?

if [ $jceks_exists == 1 ]; then
   hadoop credential create solace.password -provider jceks:///$ROLE_TYPE/selective_controls/auth/solace_pw.jceks
fi

exit
