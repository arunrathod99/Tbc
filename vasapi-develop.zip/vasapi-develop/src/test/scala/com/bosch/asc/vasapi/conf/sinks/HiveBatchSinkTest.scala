/*
 * Copyright (c) 2024 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */

package com.bosch.asc.vasapi.conf.sinks

import com.bosch.asc.vasapi.conf.Sink
import com.bosch.asc.vasapi.{UnitSpec, Vasapi}
import pureconfig.{ConfigObjectSource, ConfigSource}
import pureconfig.generic.auto._
import com.holdenkarau.spark.testing.DataFrameSuiteBase
import org.scalatest.{BeforeAndAfter, BeforeAndAfterAll}
import org.scalatest.matchers.should.Matchers

class HiveBatchSinkTest
    extends UnitSpec
    with DataFrameSuiteBase
    with BeforeAndAfter
    with BeforeAndAfterAll
    with Matchers {

  before {
    dropViewsTables()
    ()
  }

  trait testDBSetup {
    val dbName: String = "testDB"
    val targetTable: String = "targetTable"
    val sourceView: String = "sourceView"

    spark.sql(s"CREATE DATABASE IF NOT EXISTS $dbName")
    spark.sql(s"use $dbName")

    val data: Seq[TestUser] = Seq(
      TestUser(1, "sanu"),
      TestUser(2, "mahi")
    )
    spark.createDataFrame(data).createOrReplaceTempView(sourceView)

    val baseHiveSink: Sink = Sink(
      sql = s"select * from $sourceView",
      format = "hive",
      coalesce = None,
      executionMode = Some("batch"),
      dataBaseName = Some(dbName),
      tableName = Some(targetTable),
      outputMode = None,
      partitionBy = None,
      trigger = None,
      sparkListener = None,
      logPath = None,
      options = Some(
        Map(
          "fileFormat" -> "parquet"
        )
      ),
      credentialOptions = None
    )
  }

  case class TestUser(id: Int, name: String)
  case class TestUserReversed(name: String, id: Int)

  case class SimpleUser(name: String, address: String)
  case class SimpleUserReversed(address: String, name: String)

  ("Sink with format hive" should "be a parseable vasapi sink") in {

    val source: ConfigObjectSource = {
      ConfigSource.string(
        """queries: [
       {
         // omitted some optional params
         type: "sink",
         sql: "select * from final",
         format: "hive",
         coalesce: "3",
         output-mode: "overwrite",
         execution-mode: "batch",
        data-base-name: "test_sample",
        table-name:"demo_hive",
        options:
        {
        fileFormat: "parquet"
        }
       }
       ]""".stripMargin
      )
    }

    val vasapiHiveBatchSinkConf: Vasapi = source.loadOrThrow[Vasapi]

    val hiveSink: Sink = vasapiHiveBatchSinkConf.queries.headOption match {
      case Some(s: Sink) => s
      case _ => throw new NoSuchElementException("sink is not defined")
    }

    assertTrue(
      hiveSink.dataBaseName.getOrElse("") == "test_sample"
        && hiveSink.tableName.getOrElse("") == "demo_hive"
    )

  }

  "HiveBatchSink with overwrite mode" should "replace data in the target table" in {
    new testDBSetup {
      // initialize the target table with some data
      spark
        .createDataFrame(Seq(TestUser(1, "meow")))
        .write
        .saveAsTable(s"$dbName.$targetTable")

      // initialize Sink object and execute (over)write
      val overwriteHiveSink: Sink =
        baseHiveSink.copy(outputMode = Some("overwrite"))
      val hiveBatchSink: HiveBatchSink = HiveBatchSink(overwriteHiveSink, spark)
      hiveBatchSink.execute()

      import spark.implicits._

      // Assert that the data was overwritten correctly
      spark
        .sql(s"SELECT name FROM $dbName.$targetTable")
        .distinct()
        .as[String]
        .collect() should contain theSameElementsAs Seq("sanu", "mahi")
    }
  }

  it should "append data in hive table if outputMode is append" in {
    new testDBSetup {
      // initialize the target table with some data
      spark
        .createDataFrame(Seq(TestUser(1, "meow")))
        .write
        .saveAsTable(s"$dbName.$targetTable")

      // initialize Sink object and execute (over)write
      val appendHiveSink: Sink = baseHiveSink.copy(outputMode = Some("append"))
      val hiveBatchSink: HiveBatchSink = HiveBatchSink(appendHiveSink, spark)
      hiveBatchSink.execute()

      import spark.implicits._

      // Assert that the data was overwritten correctly
      spark
        .sql(s"SELECT name FROM $dbName.$targetTable")
        .distinct()
        .as[String]
        .collect() should contain theSameElementsAs Seq("sanu", "mahi", "meow")
    }
  }

  it should "contain fileFormat in options " in {
    new testDBSetup {
      val hiveBatchSink: HiveBatchSink = HiveBatchSink(baseHiveSink, spark)
      assert(hiveBatchSink.hiveOptions.getOrElse("fileFormat", "") == "parquet")
    }
  }

  it should "fail when columns data types are not matching" in {

    new testDBSetup {
      // initialize the target table with some data
      spark
        .createDataFrame(Seq(TestUserReversed("meow", 1)))
        .write
        .saveAsTable(s"$dbName.$targetTable")

      // Create a HiveBatchSink instance using SinkConfig which has db test_sample1 and table demo_hive2
      val overwriteHiveSink: Sink =
        baseHiveSink.copy(outputMode = Some("overwrite"))
      val hiveBatchSink: HiveBatchSink = HiveBatchSink(overwriteHiveSink, spark)

      assertThrows[org.apache.spark.sql.AnalysisException](
        hiveBatchSink.execute()
      )
    }
  }

  it should "(dangerously) succeed if column data types are the same but names are different" in {
    new testDBSetup {
      val dataSimpleUser: Seq[SimpleUser] =
        Seq(SimpleUser("sanu", "bangalore"), SimpleUser("mahi", "coimbatore"))
      spark.createDataFrame(dataSimpleUser).createOrReplaceTempView(sourceView)

      // initialize the target table with some data
      spark
        .createDataFrame(Seq(SimpleUserReversed("delhi", "meow")))
        .write
        .saveAsTable(s"$dbName.$targetTable")

      // Create a HiveBatchSink instance using SinkConfig which has db test_sample1 and table demo_hive2
      val overwriteHiveSink: Sink =
        baseHiveSink.copy(outputMode = Some("overwrite"))
      val hiveBatchSink: HiveBatchSink = HiveBatchSink(overwriteHiveSink, spark)
      hiveBatchSink.execute()

      import spark.implicits._

      /*
       only sequence and data type of columns matter --> with overwrite mode, spark overwrite the target table's
       name column with the name column from the source table
       */
      spark
        .sql(s"SELECT name FROM $dbName.$targetTable")
        .distinct()
        .as[String]
        .collect() should contain theSameElementsAs Seq(
        "bangalore",
        "coimbatore"
      )
    }
  }
}
