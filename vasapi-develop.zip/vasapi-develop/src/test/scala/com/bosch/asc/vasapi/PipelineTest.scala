/*
 * Copyright (c) 2023 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */

package com.bosch.asc.vasapi

import com.bosch.asc.vasapi.udf.CommonUDF
import com.holdenkarau.spark.testing.DataFrameSuiteBase
import org.apache.spark.sql.DataFrame
import org.mockito.Mockito.{times, verify}
import org.mockito.MockitoSugar
import org.scalamock.scalatest.MockFactory
import org.scalatest.{BeforeAndAfter, BeforeAndAfterAll}
import pureconfig.generic.auto._
import pureconfig.{ConfigObjectSource, ConfigSource}

class PipelineTest
    extends UnitSpec
    with DataFrameSuiteBase
    with MockFactory
    with BeforeAndAfter
    with BeforeAndAfterAll {

  before {
    dropViewsTables()
    ()
  }

  trait defaultConfig {
    val configReaderObj: Vasapi = Pipeline.readVasapiConfig(None)
  }

  trait customConfig {

    val source: ConfigObjectSource = ConfigSource.string(
      """inits: [
    {
      type: "external-hive-table"
      name: default.test_table
      drop-table: false
      ddl-schema: "id STRING, value1 BIGINT, value2 STRING, date STRING"
      partition-by: ["date"]
      comment: This is a test table
      stored-as: parquet
      location: /test/path
    }
    ]
    queries: [
      {
        type: "source",
        name: "myTestSource",
        format: "rate",
        options: {
          rowsPerSecond: "1",
          rampUpTime: "0",
          numPartitions: "1"
        }
      }
    ]
    udfs: {}
    """
    )

    // val vasapConfOption = vasapiConfOption(source.load[conf.Vasapi])
    val vasapiConf: Vasapi = source.loadOrThrow[Vasapi]

    val externalTblObj: Object = vasapiConf.inits.getOrElse(
      throw new NoSuchFieldError("empty init block")
    ) match {
      case hd :: _ => hd
      case Nil     => Nil
    }
  }

  ("readVasapiConfig" should "read & parse the target file when called with a path to a file") in {
    val vasapiConf: Vasapi =
      Pipeline.readVasapiConfig(
        Option("test-vasapi-confs/reference-test.conf")
      )

    val numQueries: Int = vasapiConf.queries.size
    assert(numQueries == 2)
  }

  (it should "also read resources with non-standard names") in {
    val vasapiConf: Vasapi =
      Pipeline.readVasapiConfig(Option("subdir/non-standard.conf"))

    val numQueries: Int = vasapiConf.queries.size
    assert(numQueries == 1)
  }

  (it should "make sure that the correct method for conf loading is called") in {
    pending
  }

  (it should "read & parse the default conf if called with None") in {
    new defaultConfig {
      var numQueries: Int = 0
      configReaderObj.queries.foreach(_ => numQueries += 1)
      assert(numQueries == 4)
    }
  }

  ("calling registerQueries() on default config" should
    "read the reference.conf and build + start streaming queries") taggedAs Spark in {
    new defaultConfig {

      configReaderObj match {
        case confObj @ Vasapi(_, _, _) =>
          Pipeline.registerQueries(confObj.queries)
        case _ =>
      }

      spark.streams.active.foreach(streamingQuery =>
        streamingQuery.processAllAvailable()
      )

      val testDF: DataFrame = spark.sql("select * from rateSource")
      val testView: DataFrame = spark.sql("select * from testview")
      val memTable: DataFrame = spark.sql("select * from testTableVasapi")

      // val numRowsMemTable: Long = spark.table("testTableVasapi").count()
      assert(testDF.isStreaming && testView.isStreaming)
      assertTrue(memTable.columns.contains("value"))
    }
  }

  ("calling registerQueries() on default config" should
    "call the register() method of the respective classes exactly once") taggedAs Spark in {

    val sourceMock =
      MockitoSugar.mock[com.bosch.asc.vasapi.conf.Source]("sourceMock")
    val viewMock = MockitoSugar.mock[com.bosch.asc.vasapi.conf.View]("viewMock")
    val sinkMock = MockitoSugar.mock[com.bosch.asc.vasapi.conf.Sink]("sinkMock")

    val vasapiMock =
      Vasapi(None, None, sourceMock :: viewMock :: sinkMock :: Nil)

    Pipeline.registerQueries(vasapiMock.queries)

    verify(sourceMock, times(1)).register(spark)
    verify(viewMock, times(1)).register(spark)
    verify(sinkMock, times(1)).register(spark)
  }

  ("calling registerUDFs()" should "successfully iterate through all udfs and register them") taggedAs Spark in {
    new defaultConfig {
      Pipeline.registerUDFs(configReaderObj)
      val udfNames: List[String] = CommonUDF.udfs.keys.toList
      udfNames.foreach(udfName => assert(spark.catalog.functionExists(udfName)))
    }
  }
}
