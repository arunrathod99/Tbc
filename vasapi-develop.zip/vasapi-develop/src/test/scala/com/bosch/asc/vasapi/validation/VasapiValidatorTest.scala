/*
 *  Copyright (c) 2023 Robert Bosch GmbH and its subsidiaries.
 *  This program and the accompanying materials are made available under
 *  the terms of the Bosch Internal Open Source License v4
 *  which accompanies this distribution, and is available at
 *  http://bios.intranet.bosch.com/bioslv4.txt
 */

package com.bosch.asc.vasapi.validation

import com.bosch.asc.vasapi.conf._
import com.bosch.asc.vasapi.{Config, UnitSpec, Vasapi}
import com.holdenkarau.spark.testing.DataFrameSuiteBase
import org.apache.spark.internal.Logging
import org.apache.spark.sql.{AnalysisException, DataFrame}
import org.scalatest.{BeforeAndAfter, BeforeAndAfterAll}
import pureconfig.generic.auto._
import pureconfig.{ConfigObjectSource, ConfigSource}
import scala.util.{Failure, Success}

/** test class for [[com.bosch.asc.vasapi.validation.VasapiValidator]]
  */
class VasapiValidatorTest
    extends UnitSpec
    with BeforeAndAfter
    with BeforeAndAfterAll
    with DataFrameSuiteBase
    with Logging {

  before {
    dropViewsTables()
  }

  trait testConfigSimple {
    val source: ConfigObjectSource =
      ConfigSource.resources("test-vasapi-confs/simple-test.conf")
    val vasapiConfSimple: Vasapi = source.loadOrThrow[Vasapi]
    val validator: VasapiValidator = VasapiValidator(vasapiConfSimple)
  }

  trait testConfigMultiView {
    val source: ConfigObjectSource =
      ConfigSource.resources("test-vasapi-confs/multiView-test.conf")

    val vasapiConfSimple: Vasapi = source.loadOrThrow[Vasapi]
    val validator: VasapiValidator = VasapiValidator(vasapiConfSimple)
  }

  trait testKafkaSource {
    val source: ConfigObjectSource =
      ConfigSource.resources("test-vasapi-confs/kafka-test.conf")
    val vasapiConfSimple: Vasapi = source.loadOrThrow[Vasapi]
    val validator: VasapiValidator = VasapiValidator(vasapiConfSimple)
  }

  trait testKafkaSourceError {
    val source: ConfigObjectSource =
      ConfigSource.resources("test-vasapi-confs/kafka-test-error.conf")
    val vasapiConfSimple: Vasapi = source.loadOrThrow[Vasapi]
    val validator: VasapiValidator = VasapiValidator(vasapiConfSimple)
  }

  trait testSolaceSource {
    val source: ConfigObjectSource =
      ConfigSource.resources("test-vasapi-confs/solace-test.conf")
    val vasapiConfSimple: Vasapi = source.loadOrThrow[Vasapi]
    val validator: VasapiValidator = VasapiValidator(vasapiConfSimple)
  }

  trait testNestedConf {
    val source: ConfigObjectSource =
      ConfigSource.resources("test-vasapi-confs/nested.conf")
    val vasapiConfSimple: Vasapi = source.loadOrThrow[Vasapi]
    val validator: VasapiValidator = VasapiValidator(vasapiConfSimple)
  }

  trait testConfigErrors {

    val testSource: Source = Source(
      name = "testSource",
      format = "rate",
      serialization = Option.empty,
      ddlSchema = Option.empty,
      jsonSchemaFile = Option.empty,
      avroSchemaFile = Option.empty,
      load = Option.empty,
      options = Some(
        Map("rowsPerSecond" -> "1", "rampUpTime" -> "0", "numPartitions" -> "1")
      ),
      credentialOptions = None
    )

    val firstTestView: View = View(
      sql = "SELECT * FRO testSource",
      name = "firstTestView",
      watermark = Option.empty
    )

    val secondTestView: View = View(
      sql = "SELECT * testSource",
      name = "secondTestView",
      watermark = Option.empty
    )

    val thirdTestView: View = View(
      sql = "SELECT * FROM testSource WHERE not_exists = 1",
      name = "thirdTestView",
      watermark = Option.empty
    )

    val queries: List[Query] =
      List(testSource, firstTestView, secondTestView, thirdTestView)
    val vasapi: Vasapi = Vasapi(
      inits = Option.empty,
      udfs = Option.empty,
      queries = queries
    )

    val validator: VasapiValidator = VasapiValidator(vasapi)
  }

  ("the validateTransformations method of VasapiValidator" should "register all CommonUDFs")
    .taggedAs(Config) in {
    // validator object is created in trait
    new testConfigSimple {

      import com.bosch.asc.vasapi.udf.CommonUDF

      validator.validateTransformations() match {
        case Success(_) =>
          // throws an AnalysisException if udf does not exist, so test would fail
          CommonUDF.udfs.foreach(f => spark.catalog.getFunction(f._1))
        case Failure(ex) => throw ex
      }
    }
  }

  (it should
    """throw an AnalysisException if any of the views
      | has a logical or syntactical issue for simple configs""".stripMargin)
    .taggedAs(Config) in {
    new testConfigErrors {
      validator.validateTransformations() match {
        case Failure(_: AnalysisException) =>
          logInfo(
            "as expected, bugs in the config throw exceptions during validation"
          )
        case Failure(ex) =>
          logError(s"expected an AnalysisException but got: ${ex.toString}")
          assert(false)
        case Success(_) =>
          logError(
            "expected an exception during validation, but did not get one"
          )
          assert(false)
      }
    }
  }

  (it should "return a Unit if the configuration is correct").taggedAs(
    Config
  ) in {
    new testConfigMultiView {
      validator.validateTransformations() match {
        case Failure(_: AnalysisException) =>
          logInfo(
            "as expected, bugs in the config throw exceptions during validation"
          )
        case Failure(ex) =>
          logError(s"expected an AnalysisException but got: ${ex.toString}")
          assert(false)
        case Success(_) =>
          logError("expected case, did not found errors during validation")
          assert(true)
      }
    }
  }

  (it should "handle kafka sources correctly").taggedAs(Config) in {
    new testKafkaSource {
      validator.validateTransformations() match {
        case Success(_) =>
          logInfo("resolved all columns from kafka source")
        case Failure(ex) =>
          logError(
            s"found error during querying kafka source due to ${ex.getMessage}"
          )
          assert(false)
      }
    }
  }

  (it should "handle solace sources correctly").taggedAs(Config) in {
    new testSolaceSource {
      validator.validateTransformations() match {
        case Success(_) =>
          logInfo("resolved all columns from solace source")
        case Failure(ex) =>
          println(
            s"found error during querying solace source due to ${ex.getMessage}"
          )
          assert(false)
      }
    }
  }

  (it should "also work for more complex confs").taggedAs(Config) in {
    new testNestedConf {
      assert(validator.validateTransformations().isSuccess)
    }
  }

  ("allTransformationsValid" should "return true for a valid conf").taggedAs(
    Config
  ) in {
    new testKafkaSource {
      assert(validator.allTransformationsValid)
    }
  }

  (it should "throw an error if the conf contains errors").taggedAs(Config) in {
    new testConfigErrors {
      validator.allTransformationsValid should be(false)
    }
  }

  (it should "return true for a nested configuration of multiple files")
    .taggedAs(Config) in {
    new testNestedConf {
      assert(validator.allTransformationsValid)
    }
  }

  ("allInitsValid" should "return true because all init sqls are valid")
    .taggedAs(Config) in {
    new testConfigSimple {
      assert(validator.allInitsValid())
    }
  }

  ("replaceSource" should
    "read a vasapi config and replace the actual source with a test source")
    .taggedAs(Config) in {

    new testKafkaSource {
      val validatorSrcReplaced: VasapiValidator = VasapiValidator(
        vasapiConfig = vasapiConfSimple,
        Map("testKafkaSource" -> "test-data/test-kafka-source/")
      )

      import org.apache.spark.sql.functions._
      import org.apache.spark.sql.types._

      // Define the schema of the JSON data
      val schema: StructType = StructType(
        Array(
          StructField(
            "movies",
            ArrayType(
              StructType(
                Array(
                  StructField("title", StringType),
                  StructField("year", IntegerType),
                  StructField("director", StringType),
                  StructField("genre", StringType)
                )
              )
            )
          )
        )
      )

      validatorSrcReplaced.validateTransformations()

      val df: DataFrame = spark
        .sql("select value from selectKafkaMsgFields")

      df.show(truncate = false)

      val dfFlattened: DataFrame = df
        .select(from_json(col("value"), schema).as("parsed"))
        .select(explode(col("parsed.movies")).as("movie"))

      dfFlattened.show(truncate = false)

      // assert that view can be queried and contains data (so test source must be registered)
      df.count() should be(1)
      dfFlattened.count() should be(3)
    }
  }
}
