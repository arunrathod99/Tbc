package com.bosch.asc.vasapi.conf.sinks

import com.bosch.asc.vasapi.utils.VasapiConfUtils
import com.bosch.asc.vasapi.{UnitSpec, Vasapi}
import com.bosch.asc.vasapi.conf.Sink
import com.holdenkarau.spark.testing.DataFrameSuiteBase
import org.apache.spark.internal.Logging
import org.scalatest.{BeforeAndAfter, BeforeAndAfterAll}
import pureconfig.{ConfigObjectSource, ConfigSource}
import pureconfig.generic.auto._

class S3SinkTest
    extends UnitSpec
    with BeforeAndAfter
    with Logging
    with BeforeAndAfterAll
    with DataFrameSuiteBase {

  before {
    // delete any remaining artifacts from previous tests
    val dir = new java.io.File("spark-warehouse/test")
    if (dir.exists()) {
      val d = new java.io.File("spark-warehouse/test")
      d.delete()
    }
  }

  trait s3SinkString {

    val source: ConfigObjectSource = {
      ConfigSource.string(
        """queries: [
        {
          // omitted some optional params
          type: "sink",
          sql: "select * from final",
          format: "s3",
          coalesce: "3",
          output-mode: "append",
          execution-mode: "batch",
          options: {
            // these are optional:
            // jceksPath: "jceks:///some.jceks",
            // "endpointPasswordAlias": "endpoint.password",
            // "accessKeyPasswordAlias": "accesskey.password",
            // "secretKeyPasswordAlias": "secretkey.password"
            // "secretKeyPasswordAlias": "secretkey.password",
            // these two are mandatory:
            // bucketName: myBucket,
            filePrefix: some/prefix
          }
        }
        ]""".stripMargin
      )
    }

    val vasapiS3Conf: Vasapi = source.loadOrThrow[Vasapi]
  }

  trait s3SinkObject {

    val sink: Sink = Sink(
      sql = "select * from final",
      coalesce = None,
      format = "s3",
      outputMode = Some("append"),
      logPath = None,
      dataBaseName = None,
      tableName = None,
      partitionBy = None,
      executionMode = Some("batch"),
      trigger = None,
      sparkListener = None,
      options = Some(
        Map(
          "bucketName" -> "myBucket",
          "filePrefix" -> "some/prefix"
        )
      ),
      credentialOptions = None
    )

    val vasapiS3Conf: Vasapi = Vasapi(None, None, List(sink))
  }

  ("Sink with format s3" should "be a parseable vasapi sink") in {
    new s3SinkString {
      assertTrue(vasapiS3Conf.queries.length == 1)
    }
  }

  (it should "allow the instantiation of an S3 sink object") in {
    val source: ConfigObjectSource = {
      ConfigSource.string(
        """queries: [
        {
          type: "sink",
          sql: "select * from final",
          format: "s3",
          output-mode: "append",
          execution-mode: "batch",
          options: {
            bucketName: myBucket,
            filePrefix: some/prefix
          }
        }
        ]""".stripMargin
      )
    }

    val vasapiS3Conf: Vasapi = source.loadOrThrow[Vasapi]

    val s3Sink: S3Sink = vasapiS3Conf.queries.headOption match {
      case Some(s: Sink) => new S3Sink(s, spark)
      case _ => throw new NoSuchElementException("sink is not defined")
    }

    assertTrue(
      s3Sink.s3Options.contains("bucketName") &&
        s3Sink.s3Options.contains("filePrefix")
    )
  }

  (it should "throw an error if required options keys are not present") in {
    new s3SinkString {
      assertThrows[IllegalArgumentException](
        vasapiS3Conf.queries.headOption match {
          case Some(s: Sink) => new S3Sink(s, spark).s3Options
          case _ =>
            throw new IllegalArgumentException(
              "empty queries block in vasapi conf"
            )
        }
      )
    }
  }

  (it should "not work for non-camel case variations of the s3 options keys") in {
    val source: ConfigObjectSource = {
      ConfigSource.string(
        """queries: [
        {
          type: "sink",
          sql: "select * from final",
          format: "s3",
          coalesce: "3",
          output-mode: "append",
          execution-mode: "batch",
          options: {
            bucket-Name: myBucket,
            filePrefix: some/prefix
          }
        }
        ]""".stripMargin
      )
    }

    val vasapiS3Conf: Vasapi = source.loadOrThrow[Vasapi]

    assertThrows[IllegalArgumentException](
      vasapiS3Conf.queries.headOption match {
        case Some(s: Sink) => new S3Sink(s, spark).s3Options
        case _ =>
          throw new IllegalArgumentException(
            "empty queries block in vasapi conf"
          )
      }
    )
  }

  (it should "require bucketName and prefix in options") in {
    new s3SinkObject {
      // this should not throw an error --> test passes
      VasapiConfUtils.getValidOptionsByFormat(sink)
    }
  }

  (it should "build a proper file prefix to write files to S3") in {
    new s3SinkObject {
      val filePrefix: String = vasapiS3Conf.queries.headOption match {
        case Some(s: Sink) => new S3Sink(s, spark).s3Coordinates
        case _ => throw new NoSuchElementException("no sink set up for testing")
      }

      val expected = """s3a://myBucket/some/prefix"""

      assert(filePrefix.matches(expected))
    }
  }
}
