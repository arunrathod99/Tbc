package com.bosch.asc.vasapi.utils

class VasapiSparkUtilsTest {}
