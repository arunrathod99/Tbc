package com.bosch.asc.vasapi.utils

import com.bosch.asc.environment.HadoopEnvironment
import org.apache.spark.internal.Logging
import org.apache.spark.sql.types.StructType
import org.scalatest.BeforeAndAfterAll
import org.scalatest.flatspec.AnyFlatSpec
import org.scalatest.matchers.should.Matchers

import java.io.IOException

class VasapiSchemaUtilsTest
    extends AnyFlatSpec
    with Matchers
    with HadoopEnvironment
    with BeforeAndAfterAll
    with Logging {

  ("createStructTypeFromJsonSchema" should "convert a json schema into a StructType") in {
    val jsonKfkSchema: StructType =
      VasapiSchemaUtils.createStructTypeFromJsonSchema(
        "src/test/resources/test-schemas/lotr_test_schema.json"
      )

    jsonKfkSchema.fieldNames should contain theSameElementsAs Array(
      "title",
      "published",
      "author"
    )
  }

  it should "produce an exception for faulty spark json schema representations" in {
    assertThrows[IllegalArgumentException] {
      VasapiSchemaUtils.createStructTypeFromJsonSchema(
        "test-schemas/broken_schema.json"
      )
    }
  }

  it should "produce an exception if the schema file cannot be found" in {
    assertThrows[IOException] {
      VasapiSchemaUtils.createStructTypeFromJsonSchema(
        "test-schemas/does_not_exist.json"
      )
    }
  }
}
