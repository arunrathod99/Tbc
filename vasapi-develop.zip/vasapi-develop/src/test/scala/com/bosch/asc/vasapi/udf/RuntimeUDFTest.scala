/*
 * Copyright (c) 2009, 2018 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */
package com.bosch.asc.vasapi.udf

import com.holdenkarau.spark.testing.DataFrameSuiteBase
import org.apache.spark.sql.functions.col
import org.scalatest.flatspec.AnyFlatSpec

/** Rudimentary check of RuntimeUDF functionality
  */
case class Numbers(value: String)
class RuntimeUDFTest extends AnyFlatSpec with DataFrameSuiteBase {

  import spark.implicits._

  "java.util.UUID function" should "return the same when used in RDD map or in runtime defined UDF" in {
    val data = Seq("one", "two", "three")

    val testDS = data.toDS().as[Numbers]
    val uuidDf = testDS
      .map(d => java.util.UUID.nameUUIDFromBytes(d.value.getBytes).toString)
      .toDF()

    val udf = RuntimeUDF.createTypedUdf(
      "(s: String) => java.util.UUID.nameUUIDFromBytes(s.getBytes).toString"
    )
    val udfDf = data.toDF("value").select(udf($"value") as "value")

    assertDataFrameEquals(uuidDf, udfDf)
  }

  "A UDF function performing simple arithmetic operations" should "return the right result" in {
    val data = Seq(1, 2, 3)
    val testDF = data.toDF("values")

    val refDf = testDF.withColumn("result", (col("values") + 2) * 5)

    val udf = RuntimeUDF.createTypedUdf("(x1: Int) => (x1 + 2) * 5")
    val udfDf = testDF.withColumn("result", udf($"values"))

    assertDataFrameEquals(refDf, udfDf)
  }
}
