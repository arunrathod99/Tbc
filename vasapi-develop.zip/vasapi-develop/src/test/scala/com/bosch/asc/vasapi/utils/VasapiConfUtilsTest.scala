/*
 *  Copyright (c) 2023 Robert Bosch GmbH and its subsidiaries.
 *  This program and the accompanying materials are made available under
 *  the terms of the Bosch Internal Open Source License v4
 *  which accompanies this distribution, and is available at
 *  http://bios.intranet.bosch.com/bioslv4.txt
 */

package com.bosch.asc.vasapi.utils

import com.bosch.asc.environment.HadoopEnvironment
import com.bosch.asc.vasapi.conf.Source
import com.bosch.asc.vasapi.UnitSpec
import org.mockito.MockitoSugar._
import org.scalatest.BeforeAndAfterAll

import scala.util.{Failure, Success}

class VasapiConfUtilsTest
    extends UnitSpec
    with HadoopEnvironment
    with BeforeAndAfterAll {

  "getValidOptionsByFormat" should "return empty map for unknown format" in {
    val result =
      VasapiConfUtils.getValidOptionsByFormat(
        Source(
          name = "test",
          format = "unknown",
          serialization = None,
          ddlSchema = None,
          jsonSchemaFile = None,
          avroSchemaFile = None,
          load = None,
          options = Option.empty,
          credentialOptions = Option.empty
        )
      )
    result shouldBe Map.empty
  }

  // TODO: should it really?
  it should "return the map unchanged if secret reading / decryption fails for all secrets" in {
    val options = Map("jceksPath" -> "dummy", "passwordAlias" -> "secretAlias")
    val result =
      VasapiConfUtils.getValidOptionsByFormat(
        Source(
          name = "test",
          format = "kafka",
          serialization = None,
          ddlSchema = None,
          jsonSchemaFile = None,
          avroSchemaFile = None,
          load = None,
          options = Some(options),
          credentialOptions = Option.empty
        )
      )

    result shouldBe options
  }

  it should "decrypt JCEKS credentials and add to options map" in {

    val credentialMock = mock[JCEKSSecret]
    when(credentialMock.decryptSecret).thenReturn(Success("decryptedPW"))
    val credentialOptions = Map("my-option" -> credentialMock)

    val opts = VasapiConfUtils.getValidOptionsByFormat(
      Source(
        name = "test",
        format = "Kafka",
        serialization = None,
        ddlSchema = None,
        jsonSchemaFile = None,
        avroSchemaFile = None,
        load = None,
        options = None,
        credentialOptions = Option(credentialOptions)
      )
    )

    opts.getOrElse("my-option", "") should be("decryptedPW")
  }

  it should "decrypt multiple Databricks credentials and add to options map" in {

    val firstCredentialMock = mock[DatabricksSecret]("firstMock")
    val secondCredentialMock = mock[DatabricksSecret]("secondMock")

    for {
      (value, idx) <- Seq(
        firstCredentialMock,
        secondCredentialMock
      ).zipWithIndex
    } {
      when(value.decryptSecret).thenReturn(
        Success(s"decryptedDatabricksPW$idx")
      )
    }

    val credentialOptions = Map(
      "my-first-option" -> firstCredentialMock,
      "my-second-option" -> secondCredentialMock
    )

    val opts = VasapiConfUtils.getValidOptionsByFormat(
      Source(
        name = "test",
        format = "Kafka",
        serialization = None,
        ddlSchema = None,
        jsonSchemaFile = None,
        avroSchemaFile = None,
        load = None,
        options = None,
        credentialOptions = Option(credentialOptions)
      )
    )

    opts should contain allOf (
      "my-first-option" -> "decryptedDatabricksPW0",
      "my-second-option" -> "decryptedDatabricksPW1"
    )
  }

  it should "decrypt attempt to decrypt multiple credentials and only add successful cases to options" in {

    val firstCredentialMock = mock[JCEKSSecret]("firstMock")
    when(firstCredentialMock.decryptSecret).thenReturn(Success("decryptedPW"))

    val secondCredentialMock = mock[DatabricksSecret]("secondMock")
    when(secondCredentialMock.decryptSecret).thenReturn(
      Failure(new NoSuchElementException("fail test"))
    )

    val credentialOptions = Map(
      "my-first-option" -> firstCredentialMock,
      "my-second-option" -> secondCredentialMock
    )

    val opts = VasapiConfUtils.getValidOptionsByFormat(
      Source(
        name = "test",
        format = "Kafka",
        serialization = None,
        ddlSchema = None,
        jsonSchemaFile = None,
        avroSchemaFile = None,
        load = None,
        options = None,
        credentialOptions = Option(credentialOptions)
      )
    )

    opts should contain(
      "my-first-option" -> "decryptedPW"
    )
  }

  ("getValidOptionsByFormat for plaintext sasl kafka sources" should "convert the auth options correctly") in {

    val firstCredentialMock = mock[DatabricksSecret]("firstMock")
    when(firstCredentialMock.decryptSecret).thenReturn(
      Success("decryptedUsername")
    )

    val secondCredentialMock = mock[DatabricksSecret]("secondMock")
    when(secondCredentialMock.decryptSecret).thenReturn(
      Success("decryptedPassword")
    )

    val credentialOptions = Map(
      "kafka.sasl.username" -> firstCredentialMock,
      "kafka.sasl.password" -> secondCredentialMock
    )

    val options = Map(
      "kafka.sasl.mechanism" -> "PLAIN",
      "kafka.security.protocol" -> "SASL_SSL"
    )

    val result =
      VasapiConfUtils.getValidOptionsByFormat(
        Source(
          name = "test",
          format = "kafka",
          serialization = None,
          ddlSchema = None,
          jsonSchemaFile = None,
          avroSchemaFile = None,
          load = None,
          options = Some(options),
          credentialOptions = Some(credentialOptions)
        )
      )

    verify(firstCredentialMock, atLeastOnce).decryptSecret
    verify(secondCredentialMock, atLeastOnce).decryptSecret

    result.contains("kafka.sasl.jaas.config") shouldBe true
  }

  ("containsS3PathParams" should "return true if the map contains the required s3 path parameters") in {
    val options: Map[String, String] =
      Map("bucketName" -> "myBucket", "filePrefix" -> "myPrefix")
    VasapiConfUtils.containsS3PathParams(options) shouldBe true
  }

  (it should "return false if both keys are contained but one of them is empty") in {
    val options: Map[String, String] =
      Map("bucketName" -> "", "filePrefix" -> "myPrefix")
    VasapiConfUtils.containsS3PathParams(options) shouldBe false
  }

  ("readConfFromLocator" should "delegate to the first conf loading mechanism that works") in {
    val vasapiConf =
      VasapiConfUtils.readConfFromLocator("subdir/non-standard.conf")
    assert(vasapiConf.isRight)
  }

  (it should "throw an exception if the conf source cannot be read") in {
    assertThrows[NoSuchElementException] {
      val wrongSource = "this/surely/does/not/exist"
      VasapiConfUtils.readConfFromLocator(wrongSource)
    }
  }
}
