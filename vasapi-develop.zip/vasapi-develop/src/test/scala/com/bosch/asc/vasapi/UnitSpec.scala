/*
 * Copyright (c) 2009, 2018 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */
package com.bosch.asc.vasapi

import com.holdenkarau.spark.testing.DataFrameSuiteBase
import org.apache.spark.SparkConf
import org.apache.spark.internal.Logging
import org.apache.spark.sql.SparkSession
import org.scalatest._
import org.scalatest.flatspec.AnyFlatSpec
import org.scalatest.matchers.should.Matchers
import java.io.File
import scala.reflect.io.Directory
import scala.util.Try

/** Provides classes and objects defining our unit test configuration.
  *
  * ==Overview==
  * The abstract class [[UnitSpec]] can be extended to create unit tests, e.g.
  * {{{class myTests extends UnitSpec {..}}}}
  *
  * Additionally, there are filter tags defined as Tag objects that allows to
  * filter on certain categories of tests. E.g. including [[RegExp]] enables the
  * tagging of regular expressions tests like so
  * {{{"Method myFunction" should "return correct values" taggedAs(RegExp) in {}..}}}.
  * They can be directly called within the sbt shell by `testOnly -- -n`
  * com.bosch.asc.tags.RegExp` or excluded with `testOnly -- -l
  * com.bosch.asc.tags.RegExp
  */

/** Abstract class that facilitates unit test using FlatSpec and Matchers */
abstract class UnitSpec
    extends AnyFlatSpec
    with Matchers
    with DataFrameSuiteBase
    with Logging {

  /*
   reuse the created Spark context in all tests.
   https://github.com/holdenk/spark-testing-base/wiki/SharedSparkContext

   we do not re-use the spark session from DAtaFrameSuiteBase, since it is not restarted after being stopped
   override def reuseContextIfPossible: Boolean = true

  replaced by implicit SparkSessions
   */

  // regular spark session to re-use across tests
  lazy val sparkConf: SparkConf = new SparkConf()
  conf.set("hive.hmshandler.retry.attempts", "5")
  conf.set("hive.hmshandler.retry.interval", "5000")

  override implicit lazy val spark: SparkSession = SparkSession
    .builder()
    .master("local[*]")
    .config(sparkConf)
    .enableHiveSupport()
    .getOrCreate()

  val warehouseDir: String = "spark-warehouse/test"

  // iceberg spark session to re-use across iceberg tests only
  lazy val icebergSparkConf: SparkConf = sparkConf
    .set(
      "spark.sql.extensions",
      "org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions"
    )
    .set("spark.sql.catalog.local", "org.apache.iceberg.spark.SparkCatalog")
    .set("spark.sql.catalog.local.type", "hadoop")
    .set("spark.sql.catalog.local.warehouse", warehouseDir)

  lazy val icebergSpark: SparkSession =
    SparkSession
      .builder()
      .master("local[*]")
      .config(icebergSparkConf)
      .enableHiveSupport()
      .getOrCreate()

  def dropViewsTables(): Unit = {
    dropViewsTables(spark)
  }

  def dropViewsTables(spark: SparkSession): Unit = {
    for {
      elemTry <- Try(spark.catalog.listTables().collect())
      elem <- elemTry
    } {
      if (elem.isTemporary) {
        spark.sql(s"drop view if exists ${elem.name}")
        logInfo(s"dropping view ${elem.name}")
      } else {
        spark.sql(s"drop table if exists ${elem.name}")
        logInfo(s"dropping table ${elem.name}")
      }
    }
  }

  def clearLocalMetastore(): Boolean = {
    // delete any remaining artifacts from previous tests
    val dir = new Directory(new File("spark-warehouse/"))
    dir.deleteRecursively()
  }
}

/** Definition of custom tags to be used in the {{{taggedAs}}} clause of
  * FlatSpec tests
  *
  * Tag categories are:
  *   - Collections: All tests for length and content of collections like lists
  *     and sets.
  *   - RegExp: All tests that involve regexp matchers to check format and/or
  *     content.
  *   - SchemaCheck: All tests that involve schema checks such as JSON schema
  *     checker.
  *   - Spark: All tests that work on a Spark framework, e.g. for common UDF
  *     tests.
  */
object Collection extends Tag("com.bosch.asc.tags.Collection") {}
object Config extends Tag("com.bosch.asc.tags.Config") {}
object RegExp extends Tag("com.bosch.asc.tags.RegExp") {}
object SchemaCheck extends Tag("com.bosch.asc.tags.SchemaCheck") {}
object Spark extends Tag("com.bosch.asc.tags.Spark") {}

object Iceberg extends Tag("com.bosch.asc.tags.Iceberg") {}
