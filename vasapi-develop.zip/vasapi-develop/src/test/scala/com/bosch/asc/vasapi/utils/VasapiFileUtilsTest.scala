package com.bosch.asc.vasapi.utils

import com.bosch.asc.environment.HadoopEnvironment
import org.apache.spark.internal.Logging
import org.scalatest.BeforeAndAfterAll
import org.scalatest.flatspec.AnyFlatSpec
import org.scalatest.matchers.should.Matchers

import scala.util.{Failure, Success}

class VasapiFileUtilsTest
    extends AnyFlatSpec
    with Matchers
    with HadoopEnvironment
    with BeforeAndAfterAll
    with Logging {

  ("safeResourceToString" should "read a resource file") in {
    VasapiFileUtils.safeResourceToString(
      "test-schemas/lotr_test_schema.json"
    ) match {
      case Success(content) =>
        logInfo(
          s"successfully read content from resource during test: $content"
        )
      case Failure(ex) =>
        fail(s"could not read content from resource due to ${ex.getMessage}")
    }
  }

  ("safeFileToString" should "read a json schema from resources") in {
    VasapiFileUtils.safeFileToString(
      "src/test/resources/test-schemas/lotr_test_schema.json"
    ) match {
      case Success(_)         =>
      case Failure(exception) => fail(exception.getMessage)
    }
  }
}
