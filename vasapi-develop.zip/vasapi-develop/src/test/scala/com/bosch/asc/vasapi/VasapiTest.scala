/*
 * Copyright (c) 2018 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */

package com.bosch.asc.vasapi

import com.holdenkarau.spark.testing.DataFrameSuiteBase
import org.scalatest.{BeforeAndAfter, BeforeAndAfterAll}
import pureconfig.generic.auto._
import pureconfig.{ConfigObjectSource, ConfigSource}

class VasapiTest
    extends UnitSpec
    with BeforeAndAfter
    with BeforeAndAfterAll
    with DataFrameSuiteBase {

  before {
    dropViewsTables()
    ()
  }

  trait testConfigSimple {
    val source: ConfigObjectSource =
      ConfigSource.resources("test-vasapi-confs/simple-test.conf")
    val vasapiConfSimple: Vasapi = source.loadOrThrow[Vasapi]
  }

  trait testConfigMultiView {
    val source: ConfigObjectSource =
      ConfigSource.resources("test-vasapi-confs/multiView-test.conf")
    val vasapiConfMultiView: Vasapi = source.loadOrThrow[Vasapi]
  }

  ("Vasapi.views" should "return one view for a simple vasapi conf with one view")
    .taggedAs(Config) in {
    new testConfigSimple {
      assert(vasapiConfSimple.views.length == 1)
    }
  }

  (it should "return a list with two elements for a vasapi conf with two views")
    .taggedAs(Config) in {
    new testConfigMultiView {
      val expectedViews: Seq[String] = Seq("anotherTestView", "secondTestView")
      val parsedViews: Seq[String] = vasapiConfMultiView.views.map(_.name)

      assert(
        expectedViews.forall(v => parsedViews.contains(v))
          && parsedViews.length == 2
      )
    }
  }

  ("Vasapi.queries" should "find all queries").taggedAs(Config) in {
    new testConfigMultiView {
      assert(vasapiConfMultiView.queries.length == 3)
    }
  }

  ("Vasapi.sources" should "recognize all sources").taggedAs(Config) in {
    new testConfigMultiView {
      assert(vasapiConfMultiView.sources.length == 1)
    }
  }

  ("Vasapi.udfs" should "return an empty list for a conf without udfs")
    .taggedAs(Config) in {
    new testConfigMultiView {
      val udfCount: Int =
        vasapiConfMultiView.udfs.getOrElse(Map.empty).count(_ => true)

      assert(udfCount == 0)
    }
  }

}
