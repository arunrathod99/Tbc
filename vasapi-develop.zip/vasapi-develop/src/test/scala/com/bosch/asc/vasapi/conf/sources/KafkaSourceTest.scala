/*
 * Copyright (c) 2022, 2023 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */

package com.bosch.asc.vasapi.conf.sources

import com.bosch.asc.vasapi.validation.KafkaFixture
import com.bosch.asc.vasapi.conf.{Query, Source, View}
import com.bosch.asc.vasapi.{Config, UnitSpec, Vasapi}
import com.holdenkarau.spark.testing.DataFrameSuiteBase
import io.github.embeddedkafka.EmbeddedKafka
import org.apache.kafka.common.serialization.{
  Deserializer,
  Serializer,
  StringDeserializer,
  StringSerializer
}
import org.apache.spark.internal.Logging
import org.apache.spark.sql.functions.{col, explode, from_json}
import org.apache.spark.sql.types.{
  ArrayType,
  BinaryType,
  IntegerType,
  StringType,
  StructField,
  StructType
}
import org.apache.spark.sql.DataFrame
import org.scalatest.{BeforeAndAfter, BeforeAndAfterAll}
import pureconfig.{ConfigObjectSource, ConfigSource}
import pureconfig.generic.auto._

import scala.language.postfixOps
import scala.xml.Elem

class KafkaSourceTest
    extends UnitSpec
    with BeforeAndAfter
    with Logging
    with BeforeAndAfterAll
    with DataFrameSuiteBase {

  // Try to reuse the created Spark context in all tests.
  override implicit def reuseContextIfPossible: Boolean = true

  // serializers needed for producing to / consuming from embedded kafka topics
  implicit val serializer: Serializer[String] = new StringSerializer()
  implicit val deserializer: Deserializer[String] = new StringDeserializer()

  val embeddedBrokerPort: Int = math.random() * 10000 toInt
  val embeddedZkPort: Int = math.random() * 10000 toInt
  val kfk: KafkaFixture = KafkaFixture(embeddedBrokerPort, embeddedZkPort)

  override def afterAll(): Unit = {
    EmbeddedKafka.stop()
    ()
  }

  before {
    dropViewsTables()
  }

  trait GenericKafkaInit {

    // attributes for test setup
    val embeddedTopic = "source.test.generic.topic"
  }

  trait JsonKafkaInit {

    // attributes for test setup
    val embeddedTopic = "source.test.json.topic"

    val jsonStrings: Map[String, String] = Map(
      "0" -> "{'title': 'The Fellowship of the Ring', 'published': 1954, 'author': 'J.R.R Tolkien'}",
      "1" -> "{'title': 'The Two Towers', 'published': 1954, 'author': 'J.R.R Tolkien'}",
      "2" -> "{'title': 'The Return of the King', 'published': 1954, 'author': 'J.R.R Tolkien'}"
    )

    kfk.initTopic(embeddedTopic, Some(jsonStrings))
  }

  trait AvroKafkaInit {
    import spark.implicits._

    // attributes for test setup
    val embeddedTopic = "source.test.avro.topic"

    // Define the schema for the JSON data
    val schema: StructType = new StructType()
      .add("title", StringType)
      .add("published", IntegerType)
      .add("author", StringType)

    val lotrDF: DataFrame = Seq(
      "{'title': 'The Fellowship of the Ring', 'published': 1954, 'author': 'J.R.R Tolkien'}",
      "{'title': 'The Two Towers', 'published': 1954, 'author': 'J.R.R Tolkien'}",
      "{'title': 'The Return of the King', 'published': 1954, 'author': 'J.R.R Tolkien'}"
    )
      .toDF()
      .withColumn("parsed", from_json(col("value"), schema))
      .select("parsed.*")

    kfk.initAvroTopic(embeddedTopic, lotrDF)
  }

  trait ByteArrayKafkaInit {

    // attributes for test setup
    val embeddedTopic = "source.test.byte.topic"

    var xmlMessage: Elem = <bookstore>
      <book category="COOKING">
        <title lang="en">Everyday Italian</title>
        <author>Giada De Laurentiis</author>
        <year>2005</year>
        <price>30.00</price>
      </book>
    </bookstore>

    val xmlByteArray: Array[Byte] = xmlMessage.toString().getBytes("UTF-8")

    kfk.initTopic(embeddedTopic, Some(Map("0" -> xmlByteArray)))
  }

  ("createDataframeFromKafkaBatch" should
    "create a dataframe with one row per msg and default schema for json source")
    .taggedAs(Config) in {
    new JsonKafkaInit {

      // create a kafka source and register it into a dataframe
      val batchSource: Source = com.bosch.asc.vasapi.conf.Source(
        name = "kafkaBatchTest",
        format = "kafkaBatch",
        serialization = Some("json"),
        ddlSchema = None,
        jsonSchemaFile = None,
        avroSchemaFile = None,
        load = None,
        options = Some(
          Map(
            "kafka.bootstrap.servers" -> s"localhost:${kfk.kafka.config.kafkaPort}",
            "subscribe" -> s"$embeddedTopic",
            "includeHeaders" -> "true"
          )
        ),
        credentialOptions = None
      )

      val kfkSrc: KafkaSource = KafkaSource(batchSource)
      val batchDF: DataFrame = kfkSrc.loadKafkaBatch(spark)

      batchDF.count() shouldBe 3

      // if no schema passed, df should only contain default columns
      batchDF.columns should contain theSameElementsAs KafkaStringMessage.msgSchema.fieldNames
    }
  }

  (it should
    "consider a ddl schema when explicitly passed for a json source").taggedAs(
    Config
  ) in {
    new JsonKafkaInit {

      val batchSource: Source = Source(
        name = "kafkaBatchTest2",
        format = "kafkaBatch",
        serialization = Some("json"),
        ddlSchema = Some("title STRING, published STRING, author STRING"),
        jsonSchemaFile = None,
        avroSchemaFile = None,
        load = None,
        options = Some(
          Map(
            "kafka.bootstrap.servers" -> s"localhost:${kfk.kafka.config.kafkaPort}",
            "subscribe" -> s"$embeddedTopic",
            "includeHeaders" -> "true"
          )
        ),
        credentialOptions = None
      )

      val kfkSrc: KafkaSource = KafkaSource(batchSource)
      val batchDF: DataFrame = kfkSrc.loadKafkaBatch(spark)

      // 7 (default) + 3 (from schema) + 1 (corrupt values)
      batchDF.schema.length shouldBe 11
      batchDF.schema.fieldNames should contain allOf ("author", "title", "published")
    }
  }

  (it should
    "use a json schema file to parse json messages").taggedAs(Config) in {
    new JsonKafkaInit {

      val batchSource: Source = Source(
        name = "kafkaBatchTest3",
        format = "kafkaBatch",
        serialization = Some("json"),
        ddlSchema = None,
        jsonSchemaFile =
          Some("src/test/resources/test-schemas/lotr_test_schema.json"),
        avroSchemaFile = None,
        load = None,
        options = Some(
          Map(
            "kafka.bootstrap.servers" -> s"localhost:${kfk.kafka.config.kafkaPort}",
            "subscribe" -> s"$embeddedTopic",
            "includeHeaders" -> "true"
          )
        ),
        credentialOptions = None
      )

      val kfkSrc: KafkaSource = KafkaSource(batchSource)
      val batchDF: DataFrame = kfkSrc.loadKafkaBatch(spark)

      // 7 (default) + 3 (from schema) + 1 (schema replaces value col)
      batchDF.schema.length shouldBe 11
      batchDF.schema.fieldNames should contain allOf ("author", "title", "published")
    }
  }

  (it should
    "add a column for corrupt values for invalid json string records").taggedAs(
    Config
  ) in {
    new GenericKafkaInit {

      // test setup
      val corruptJsonData: Map[String, String] = Map(
        "someKey" -> "{'title': , 'published': 1954, 'author': 'J.R.R Tolkien'}"
      )
      kfk.initTopic(embeddedTopic, Some(corruptJsonData))

      // test execution
      val batchSource: Source = Source(
        name = "kafkaBatchTest4",
        format = "kafkaBatch",
        serialization = Some("json"),
        ddlSchema = None,
        jsonSchemaFile =
          Some("src/test/resources/test-schemas/lotr_test_schema.json"),
        avroSchemaFile = None,
        load = None,
        options = Some(
          Map(
            "kafka.bootstrap.servers" -> s"localhost:${kfk.kafka.config.kafkaPort}",
            "subscribe" -> s"$embeddedTopic",
            "includeHeaders" -> "true"
          )
        ),
        credentialOptions = None
      )

      val kfkSrc: KafkaSource = KafkaSource(batchSource)
      val batchDF: DataFrame = kfkSrc.loadKafkaBatch(spark)

      batchDF.schema.fieldNames should contain("corrupt_records")
    }
  }

  (it should
    "add a column for parsing errors due to data type mismatch").taggedAs(
    Config
  ) in {
    // TODO: implement
  }

  (it should "create the source from a vasapi config string").taggedAs(
    Config
  ) in {
    new GenericKafkaInit {
      val confString: ConfigObjectSource = ConfigSource.string(
        s"""
          queries: [
            {
              type: "source",
              format: "kafkaBatch",
              name: "myKafkaBatchTest",
              options:
                  {
                    "kafka.bootstrap.servers": "localhost:${kfk.kafka.config.kafkaPort}",
                    "subscribe": "$embeddedTopic"
                  }
            }
          ]
          """
      )

      val vasapiConf: Vasapi = confString.loadOrThrow[Vasapi]

      vasapiConf.queries match {
        case (kafkaBatch: Query) :: _ => kafkaBatch.register(spark)
        case _ =>
          Source("", "", None, None, None, None, None, None, None)

          val result = spark
            .sql("select count(*) as cnt from myKafkaBatchTest")
            .take(1)(0)(0)
          assertTrue(result == 3)
      }
    }
  }

  (it should "parse avro messages") in {
    new AvroKafkaInit {
      val batchSource: Source = Source(
        name = "kafkaBatchTest4",
        format = "kafkaBatch",
        serialization = Some("avro"),
        ddlSchema = None,
        jsonSchemaFile = None,
        avroSchemaFile = Some("src/test/resources/test-schemas/lotr_test.avsc"),
        load = None,
        options = Some(
          Map(
            "kafka.bootstrap.servers" -> s"localhost:${kfk.kafka.config.kafkaPort}",
            "subscribe" -> s"$embeddedTopic"
          )
        ),
        credentialOptions = None
      )
      val kfkSrc: KafkaSource = KafkaSource(batchSource)
      val batchDF: DataFrame = kfkSrc.loadKafkaBatch(spark)

      batchDF.show()

      batchDF.select("title").distinct().count() shouldBe 3
    }
    ()
  }

  ("a kafka streaming source" should "parse messages using a ddl schema")
    .taggedAs(Config) in {
    new JsonKafkaInit {

      val streamSource: Source = Source(
        name = "kafkaStream",
        format = "kafka",
        serialization = Some("json"),
        ddlSchema = Some("title STRING, published STRING, author STRING"),
        jsonSchemaFile = None,
        avroSchemaFile = None,
        load = None,
        options = Some(
          Map(
            "kafka.bootstrap.servers" -> s"localhost:${kfk.kafka.config.kafkaPort}",
            "subscribe" -> s"$embeddedTopic"
          )
        ),
        credentialOptions = None
      )

      val kfkSrc: KafkaSource = KafkaSource(streamSource)
      val streamDf: DataFrame = kfkSrc.loadKafkaStream(spark)

      // 7 (default) + 3 (from schema) + 1 (corrupt values)
      streamDf.schema.length shouldBe 11
      streamDf.schema.fieldNames should contain allOf ("author", "title", "published")
    }
  }

  (it should "allow view registration").taggedAs(Config) in {
    // TODO: figure out why inMem table does not contain data --> final df should contain 3 rows
    new JsonKafkaInit {
      val s: Source = Source(
        name = "kafkaStream2",
        format = "kafka",
        serialization = Some("json"),
        ddlSchema = Some("title STRING, published STRING, author STRING"),
        jsonSchemaFile = None,
        avroSchemaFile = None,
        load = None,
        options = Some(
          Map(
            "kafka.bootstrap.servers" -> s"localhost:${kfk.kafka.config.kafkaPort}",
            "subscribe" -> s"$embeddedTopic"
          )
        ),
        credentialOptions = None
      )

      val kfkSource: KafkaSource = KafkaSource(s)

      kfkSource
        .loadKafkaStream(spark)
        .writeStream
        .trigger(org.apache.spark.sql.streaming.Trigger.Once())
        .outputMode("append")
        .format("memory")
        .queryName("inMemKafkaTable")
        .start()
        .processAllAvailable()

      val testDF: DataFrame =
        spark.sql("SELECT title, published, author FROM inMemKafkaTable")

      // this shows that the df is created properly and querying it works
      testDF.schema.fieldNames should contain allOf ("title", "published", "author")
    }
    ()
  }

  (it should "keep the value as an array of bytes if not otherwise specified") in {
    new ByteArrayKafkaInit {
      val streamSource: Source = Source(
        name = "kafkaStream",
        format = "kafka",
        serialization = None,
        ddlSchema = None,
        jsonSchemaFile = None,
        avroSchemaFile = None,
        load = None,
        options = Some(
          Map(
            "kafka.bootstrap.servers" -> s"localhost:${kfk.kafka.config.kafkaPort}",
            "subscribe" -> s"$embeddedTopic"
          )
        ),
        credentialOptions = None
      )

      val kfkSrc: KafkaSource = KafkaSource(streamSource)
      val streamDf: DataFrame = kfkSrc.loadKafkaStream(spark)

      Seq("key", "value").forall(f =>
        streamDf.schema.contains(StructField(f, BinaryType))
      ) shouldBe true
    }
  }

  (it should "parse the schema json schema file").taggedAs(Config) in {
    new JsonKafkaInit {

      val streamSource: Source = Source(
        name = "kafkaStream2",
        format = "kafka",
        serialization = Some("json"),
        ddlSchema = None,
        jsonSchemaFile =
          Some("src/test/resources/test-schemas/lotr_test_schema.json"),
        avroSchemaFile = None,
        load = None,
        options = Some(
          Map(
            "kafka.bootstrap.servers" -> s"localhost:${kfk.kafka.config.kafkaPort}",
            "subscribe" -> s"$embeddedTopic"
          )
        ),
        credentialOptions = None
      )

      val kfkSrc: KafkaSource = KafkaSource(streamSource)
      val streamDf: DataFrame = kfkSrc.loadKafkaStream(spark)

      // 7 (default) + 3 (from schema) + 1 (corrupt columns)
      streamDf.schema.length shouldBe 11
      streamDf.schema.fieldNames should contain allOf ("author", "title", "published")
      Seq("key", "value").forall(f =>
        streamDf.schema.contains(StructField(f, StringType))
      ) shouldBe true
    }
  }

  ("the union of dfs from batch and streaming sources"
    should "create a streaming df").taggedAs(Config) in {

    new GenericKafkaInit {

      val rateTopic: String = "rateTopic"
      val rateJsonStrings: Map[String, String] = Map(
        "0" -> "{'timestampStr': '2023-04-12', 'value': 'some val'}",
        "1" -> "{'timestampStr': '2023-04-12', 'value': 'another val'}"
      )

      kfk.initTopic(rateTopic, Some(rateJsonStrings))

      Source(
        name = "kafkaBatchTest2",
        format = "kafkaBatch",
        serialization = Some("json"),
        ddlSchema = Some("timestampStr STRING, rateValue STRING"),
        jsonSchemaFile = None,
        avroSchemaFile = None,
        load = None,
        options = Some(
          Map(
            "kafka.bootstrap.servers" -> s"localhost:${kfk.kafka.config.kafkaPort}",
            "subscribe" -> s"$embeddedTopic"
          )
        ),
        credentialOptions = None
      ).register(spark)

      val batchKafkaSource: DataFrame =
        spark.sql("""select timestampStr as timestamp,
          | rateValue from kafkaBatchTest2 as value""".stripMargin)

      Source(
        name = "rateTest",
        format = "rate",
        serialization = None,
        ddlSchema = None,
        jsonSchemaFile = None,
        avroSchemaFile = None,
        load = None,
        options = Some(
          Map(
            "rowsPerSecond" -> "5",
            "rampUpTime" -> "4",
            "numPartitions" -> "3"
          )
        ),
        credentialOptions = None
      ).register(spark)

      val rateStreamingSource: DataFrame = spark.sql("select * from rateTest")

      View(
        """select * from rateTest UNION ALL select timestampStr as timestamp,
          | rateValue as value from kafkaBatchTest2""".stripMargin,
        "unionView",
        None
      ).register(spark)

      val unionView: DataFrame = spark.sql("select * from unionView")

      assert(
        !batchKafkaSource.isStreaming &&
          rateStreamingSource.isStreaming && unionView.isStreaming
      )

    }
  }

  ("reading json arrays as strings" should "parse every json into a separate row") in {

    import spark.implicits._

    val data: DataFrame = Seq(
      """[{"id": 1, "name": "Alice", "age": 30, "city": "New York"},
        |{"id": 2, "name": "Bob", "age": 25, "city": "San Francisco"}]""".stripMargin
    ).toDF()

    val schema = ArrayType(
      StructType(
        Seq(
          StructField("id", IntegerType, nullable = true),
          StructField("name", StringType, nullable = true),
          StructField("age", IntegerType, nullable = true),
          StructField("city", StringType, nullable = true)
        )
      )
    )

    // equivalent to:
    // ArrayType(
    //   StructType.fromDDL(
    //     "id INT, name STRING, age INT, city STRING"
    //   )
    // )

    // read from kafka
    val parsedDF: DataFrame = data
      .withColumn("parsed", explode(from_json(col("value"), schema)))
      .select("parsed.*", "value")
      .select("id", "name", "age", "city", "value")

    println(parsedDF.schema.json)

    parsedDF.show(truncate = false)
    parsedDF.printSchema()

    // we should get two lines --> fails
    parsedDF.count() shouldBe 2
  }

  (it should "also work for a vasapi kafka source") in {

    val topic: String = "test.json-lines.payload"

    val payload: String =
      """[{"id": 1, "name": "Alice", "age": 30, "city": "New York"},
        |{"id": 2, "name": "Bob", "age": 25, "city": "San Francisco"}]""".stripMargin

    // generate topic and produce test data as k,v pairs
    kfk.initTopic(topic, Some(Map("0" -> payload)))

    Source(
      name = "kafkaJsonTest",
      format = "kafkaBatch",
      serialization = Some("json"),
      ddlSchema = None,
      // TODO: passing a json schema for Arrays does not work yet, see PJASC-12109
      // jsonSchemaFile = Some("test-schemas/spark_kafka_test_schema.json"),
      jsonSchemaFile = None,
      avroSchemaFile = None,
      load = None,
      options = Some(
        Map(
          "kafka.bootstrap.servers" -> s"localhost:${kfk.kafka.config.kafkaPort}",
          "subscribe" -> s"$topic"
        )
      ),
      credentialOptions = None
    ).register(spark)

    val parsedDF: DataFrame = spark.sql(
      """
        | SELECT
        |   explode(from_json(value, 'ARRAY<STRUCT<id: INT, name: STRING, age: INT, city: STRING>>')) as parsed
        | FROM
        |   kafkaJsonTest
        |""".stripMargin
    )

    parsedDF.printSchema()
    parsedDF.show(truncate = false)

    parsedDF.count() shouldBe 2
  }
}
