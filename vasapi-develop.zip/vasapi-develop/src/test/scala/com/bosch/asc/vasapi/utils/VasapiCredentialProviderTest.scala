/*
 *  Copyright (c) 2023 Robert Bosch GmbH and its subsidiaries.
 *  This program and the accompanying materials are made available under
 *  the terms of the Bosch Internal Open Source License v4
 *  which accompanies this distribution, and is available at
 *  http://bios.intranet.bosch.com/bioslv4.txt
 */

package com.bosch.asc.vasapi.utils

import com.bosch.asc.vasapi.UnitSpec
import org.mockito.MockitoSugar

class VasapiCredentialProviderTest extends UnitSpec with MockitoSugar {}
