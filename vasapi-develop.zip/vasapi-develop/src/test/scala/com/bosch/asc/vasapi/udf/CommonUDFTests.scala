/*
 * Copyright (c) 2009, 2018 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */
package com.bosch.asc.vasapi.udf

import scala.util.{Failure, Success}
import java.io.ByteArrayOutputStream
import java.util.zip.GZIPOutputStream
import org.apache.spark.sql.types.DataType
import com.bosch.asc.vasapi.udf.CommonUDF._
import org.apache.spark.sql.types.StructType
import com.bosch.asc.vasapi.{Spark, UnitSpec}
import com.bosch.asc.vasapi.utils.VasapiFileUtils
import com.holdenkarau.spark.testing.DataFrameSuiteBase
import org.apache.spark.sql.{DataFrame, Dataset, SparkSession}
import org.apache.spark.sql.functions.{column, hex, lit, typedLit}

/** Specification for unit test of common UDF's
  *
  * All common defined UDF's need to be tested
  */
class CommonUDFTests extends UnitSpec with DataFrameSuiteBase {
  // Get path for the test file and parse the associated schema.
  // [Note: getResource reads from <project>/src/test/resources where the leading slash must not be
  //        omitted. Best practice for resource files is to symlink from top level directory]
  val testFilePath: String =
    getClass.getResource("/test-vasapi-confs/sji_tests.json.merged").getPath
  val schemaResourcePath = "test-schemas/ae.smt.sji.test.schema.json"
  val schemaString: String =
    VasapiFileUtils.safeFileOrResourceToString(schemaResourcePath) match {
      case Success(schema) => schema
      case Failure(ex) =>
        throw new Exception(s"Failed to read schema file: $ex")
    }

  val testSMTJsonSchema: StructType = DataType
    .fromJson(
      schemaString
    )
    .asInstanceOf[StructType]

  // represented as strings only, udf handles file reading
  val testJsonSchemaString: String =
    "src/test/resources/test-schemas/json_test_schema.json"
  val testXmlSchemaString: String =
    "src/test/resources/test-schemas/mws_test_xsd.xsd"

  trait testXMLFixture {
    var xmlMessage: String = """<bookstore>
                                   <book category="COOKING">
                                      <title lang="en">Everyday Italian</title>
                                      <author>Giada De Laurentiis</author>
                                      <year>2005</year>
                                      <price>30.00</price>
                                  </book>
                              </bookstore>"""

    var xmlMessageBytes: Array[Byte] =
      xmlMessage.getBytes("UTF-8") // string to byte array conversion

    def gzipMessage(): Array[Byte] = {
      val byteArrayOutputStream = new ByteArrayOutputStream()
      val gzipOutputStream = new GZIPOutputStream(byteArrayOutputStream)
      gzipOutputStream.write(xmlMessage.getBytes("UTF-8"))
      gzipOutputStream.close()
      byteArrayOutputStream.toByteArray
    }
  }

  ("UDF uuidFromString" should "return a dataframe with transformed UUID values")
    .taggedAs(Spark) in {
    // Import implicit Spark SQL functions from the existing SQLContext
    import spark.sqlContext.implicits._

    // Create test dataframe from resource file and apply UDF
    val testDF = sc
      .parallelize(List[String]("0123abc_.!", "098?-xyz"))
      .toDF("stringValue")
      .withColumn(
        "uuidFromString",
        udfs("uuidFromString")(column("stringValue"))
      )
      .select("uuidFromString")
    // Create result dataframe
    val resultDF = sc
      .parallelize(
        List[String](
          "072716d6-6ceb-3db9-b9c9-70e9c7ee37e2",
          "fafa80aa-3177-3119-9ba1-f8217e7db974"
        )
      )
      .toDF("uuidFromString")

    assertDataFrameEquals(testDF, resultDF)
  }

  ("UDF sumStructArrayEntry" should
    "match to a dataframe with an aggregated column from a structured array field")
    .taggedAs(Spark) in {
    // Import implicit Spark SQL functions from the existing SQLContext
    import spark.sqlContext.implicits._

    // Create test dataframe from resource file and apply UDF
    val testDF = spark.read
      .schema(testSMTJsonSchema)
      .json(testFilePath)
      .withColumn(
        "sumStructArrayEntry",
        udfs("sumStructArrayEntry")(
          column("sjiProcessedBoards"),
          lit("sjiSumInspecBoardTerminations")
        )
      )
      .select("sumStructArrayEntry")
    // Create result dataframe
    val resultDF =
      sc.parallelize(List[Long](3300, 3225)).toDF("sumStructArrayEntry")

    assertDataFrameEquals(testDF, resultDF)
  }

  ("UDF getUTCTimestamp" should
    "return correct UTC timestamp value for a passed string timestamp value")
    .taggedAs(Spark) in {

    val sampleData = List(
      (
        "2023-09-11T12:25:04.7960993-06:00",
        "2023-09-11T12:25:04.7960993-06:00",
        "1"
      ),
      ("2023-09-11T12:25:04.796+06:00", "2023-09-11T12:25:04.796+06:00", "2"),
      ("2023-09-11T12:25:04.7", "2023-09-11T12:25:04.7-06:00", "3"),
      ("2023-09-11T23:25:04", "2023-09-11T23:25:04-06:00", "4"),
      ("2023-09-11T23:25:04-06:00", "2023-09-11T23:25:04-03:00", "5")
    )

    val sampleDf = spark
      .createDataFrame(sampleData)
      .toDF("dateValue", "dateValueForOffset", "recordNo")
    val finalDf = sampleDf
      .withColumn(
        "utcTimestamp",
        udfs("getUTCTimestamp")(
          column("dateValue"),
          column("dateValueForOffset")
        )
      )
      .select("recordNo", "utcTimestamp")

    val expectedData: List[(String, String)] = List(
      ("1", "2023-09-11 18:25:04.7960993"),
      ("2", "2023-09-11 06:25:04.796"),
      ("3", "2023-09-11 18:25:04.7"),
      ("4", "2023-09-12 05:25:04.0"),
      ("5", "2023-09-12 05:25:04.0")
    )

    val expectedUtcDF = spark
      .createDataFrame(expectedData)
      .toDF("recordNo", "utcTimestamp")
    assertDataFrameEquals(expectedUtcDF, finalDf)
  }

  (it should
    "return null in case of incorrect input timestamp format")
    .taggedAs(Spark) in {

    val sampleData2 = List(
      ("2023/09/11T12:25:04.7960993", "2023-09-11T12:25:04.7960993-06:00", "1"),
      ("2023. 10. 09. 12:48:00", "2023-10-09T23:25:04-03:00", "2"),
      ("10/09/2023 13:41:12", "2023-09-11T23:25:04-03:00", "3")
    )

    val sampleDf2 = spark
      .createDataFrame(sampleData2)
      .toDF("dateValue", "dateValueForOffset", "recordNo")
    val finalDf2 = sampleDf2
      .withColumn(
        "utcTimestamp",
        udfs("getUTCTimestamp")(
          column("dateValue"),
          column("dateValueForOffset")
        )
      )
      .select("recordNo", "utcTimestamp")

    val expectedData2: List[(String, String)] = List(
      ("1", null),
      ("2", null),
      ("3", null)
    )

    val expectedUtcDF2 = spark
      .createDataFrame(expectedData2)
      .toDF("recordNo", "utcTimestamp")
    assertDataFrameEquals(expectedUtcDF2, finalDf2)
  }

  (it should
    "fail in case of incorrect input timestamp format for reference value")
    .taggedAs(Spark) in {

    val inputRecord = List(
      ("2023-09-11T12:25:04.7960993", "2023/09/11T12:25:04.7960993-06:00")
    )

    val inputDataframe = spark
      .createDataFrame(inputRecord)
      .toDF("dateValue", "dateValueForOffset")
    val outputDataframe = inputDataframe
      .withColumn(
        "utcTimestamp",
        udfs("getUTCTimestamp")(
          column("dateValue"),
          column("dateValueForOffset")
        )
      )
      .select("utcTimestamp")

    assertThrows[org.apache.spark.SparkException](outputDataframe.show(false))
  }

  (it should
    "return null in case of input timestamp value is null")
    .taggedAs(Spark) in {

    val inputDataWithNull = List(
      (null, "2023-09-11T12:25:04.7960993-06:00", "1")
    )

    val inputDfWithNull = spark
      .createDataFrame(inputDataWithNull)
      .toDF("dateValue", "dateValueForOffset", "recordNo")
    val outputDfToCheck = inputDfWithNull
      .withColumn(
        "utcTimestamp",
        udfs("getUTCTimestamp")(
          column("dateValue"),
          column("dateValueForOffset")
        )
      )
      .select("recordNo", "utcTimestamp")

    val expectedData3: List[(String, String)] = List(("1", null))
    val expectedUtcDF3 = spark
      .createDataFrame(expectedData3)
      .toDF("recordNo", "utcTimestamp")
    assertDataFrameEquals(expectedUtcDF3, outputDfToCheck)
  }

  ("UDF validateJson" should
    "validate the JSON message against a given schema")
    .taggedAs(Spark) in {
    // Create test dataframe from resource file and apply UDF
    // Test case 1 : schema validation against a given schema
    val jsonString = List(
      (
        """{"Zipcode":704,"TimestampType":"2023-09-11T12:25:04.796540993-06:00","City":"PARC PARQUE","State":"PR"}""",
        "1"
      ),
      (
        """{"Zipcode":"704","TimestampType":"2023-09-11T","City":"PARC PARQUE"}""",
        "2"
      ),
      (
        """{"Zipcode":704,"TimestampType":"2023-09-11T12:25:04-06:00","City":"PARC PARQUE","State":"PR","Landmark":"S M MALL"}""",
        "3"
      ),
      (
        """{"Zipcode":704,"TimestampType":"2023-09-11T12:25:04.796540993-06:00","City":"PARC PARQUE","State":"PR","Landmark":"S M MALL"""",
        "4"
      )
    )
    val testDF = spark
      .createDataFrame(jsonString)
      .toDF("value", "recordNo")
      .withColumn(
        "validateJson",
        udfs("validateJson")(column("value"), lit(testJsonSchemaString))
      )
      .select("recordNo", "validateJson")

    val expectedDF = List(
      ("1", true),
      ("2", false),
      ("3", true),
      ("4", false)
    )
    /* create DF should return correct validateJson value for each records */
    val expectedResultDF =
      spark.createDataFrame(expectedDF).toDF("recordNo", "validateJson")
    assertDataFrameEquals(expectedResultDF, testDF)
  }

  (it should
    "validate schema based on input timestamp format defined")
    .taggedAs(Spark) in {
    // Create test dataframe and apply UDF
    // Test case 2: validate schema based on input timestamp format
    val jsonInput = List(
      (
        """{"Zipcode":704,"TimestampType":"2023-09-11T12:25:04.796099389+06:00","City":"PARC PARQUE","State":"PR"}""",
        "1"
      ),
      (
        """{"Zipcode":704,"TimestampType":"2023-09-11T12:25:04.796099-06:00","City":"PARC PARQUE","State":"PR"}""",
        "2"
      ),
      (
        """{"Zipcode":704,"TimestampType":"2023-09-11T12:25:04.7","City":"PARC PARQUE","State":"PR"}""",
        "3"
      ),
      (
        """{"Zipcode":704,"TimestampType":"2023-09-11T12:25:04","City":"PARC PARQUE","State":"PR"}""",
        "4"
      ),
      (
        """{"Zipcode":704,"TimestampType":"10/09/2023T12:25:04.796540993+06:00","City":"PARC PARQUE","State":"PR"}""",
        "5"
      ),
      (
        """{"Zipcode":704,"TimestampType":"10/09/2023T12:25:04.796540993-06:00","City":"PARC PARQUE","State":"PR"}""",
        "6"
      ),
      (
        """{"Zipcode":704,"TimestampType":"2023.09.11T12:25:04.796099389+06:00","City":"PARC PARQUE","State":"PR"}""",
        "7"
      )
    )
    val outputDF = spark
      .createDataFrame(jsonInput)
      .toDF("value", "recordNo")
      .withColumn(
        "validateJson",
        udfs("validateJson")(column("value"), lit(testJsonSchemaString))
      )
      .select("recordNo", "validateJson")

    val expectedDF = List(
      ("1", true),
      ("2", true),
      ("3", true),
      ("4", true),
      ("5", false),
      ("6", false),
      ("7", false)
    )

    /* create DF should return correct validateJson value for each records */
    val expectedResultDF =
      spark.createDataFrame(expectedDF).toDF("recordNo", "validateJson")
    assertDataFrameEquals(expectedResultDF, outputDF)
  }

  ("UDF validateJsonToString" should
    "validate the JSON message against a given schema and return result success or failure error as a String")
    .taggedAs(Spark) in {
    /* Create test dataframe from resource file and apply UDF
      Test case 1 : schema validation against a given schema and return result success and failure error as a String
     */
    val jsonString = List(
      (
        """{"Zipcode":704,"TimestampType":"2023-09-11T12:25:04.796540993-06:00","City":"PARC PARQUE","State":"PR"}""",
        "1"
      ),
      (
        """{"Zipcode":"704","TimestampType":"2023-09-11T","City":"PARC PARQUE"}""",
        "2"
      ),
      (
        """{"Zipcode":704,"TimestampType":"2023-09-11T12:25:04-06:00","City":"PARC PARQUE","State":"PR","Landmark":"S M MALL"}""",
        "3"
      ),
      (
        """{"Zipcode":704,"TimestampType":"2023-09-11T12:25:04.796540993-06:00","City":"PARC PARQUE","State":"PR","Landmark":"S M MALL"""",
        "4"
      )
    )
    val testErrorDF = spark
      .createDataFrame(jsonString)
      .toDF("value", "recordNo")
      .withColumn(
        "validateJsonToString",
        udfs("validateJsonToString")(column("value"), lit(testJsonSchemaString))
      )
      .select("recordNo", "validateJsonToString")

    /* Create DF to check the final result after schema validation done */
    val expectedDF = List(
      ("1", "success"),
      (
        "2",
        "{\"pointerToViolation\":\"#\",\"causingExceptions\":[{\"pointerToViolation\":\"#/Zipcode\",\"causingExceptions\":[],\"keyword\":\"type\",\"message\":\"expected type: Number, found: String\"},{\"pointerToViolation\":\"#/TimestampType\",\"causingExceptions\":[],\"keyword\":\"pattern\",\"message\":\"string [2023-09-11T] does not match pattern ^\\\\d{4}-\\\\d{2}-\\\\d{2}T\\\\d{2}:\\\\d{2}:\\\\d{2}(\\\\.\\\\d{1,9})?([+-]\\\\d{2}:\\\\d{2})?$\"},{\"pointerToViolation\":\"#\",\"causingExceptions\":[],\"keyword\":\"required\",\"message\":\"required key [State] not found\"}],\"message\":\"3 schema violations found\"}"
      ),
      ("3", "success"),
      (
        "4",
        "org.json.JSONException: Expected a ',' or '}' at 125 [character 126 line 1]"
      )
    )
    /* create DF should return correct validateJson value for each records */
    val expectedResultDF =
      spark.createDataFrame(expectedDF).toDF("recordNo", "validateJsonToString")
    assertDataFrameEquals(expectedResultDF, testErrorDF)
  }

  ("UDF filteredStructArrayCount" should
    "match to a dataframe with a filtered column count from a structured array field")
    .taggedAs(Spark) in {
    // Import implicit Spark SQL functions from the existing SQLContext
    import spark.sqlContext.implicits._

    // Create test dataframe from resource file and apply UDF
    val testDF = spark.read
      .schema(testSMTJsonSchema)
      .json(testFilePath)
      .withColumn(
        "filteredStructArrayCount",
        udfs("filteredStructArrayCount")(
          column("sjiProcessedBoards"),
          lit("sjiSumInspecBoardTerminations"),
          lit(550)
        )
      )
      .select("filteredStructArrayCount")

    // Create result dataframe
    val resultDF =
      sc.parallelize(List[Int](6, 1)).toDF("filteredStructArrayCount")

    assertDataFrameEquals(testDF, resultDF)
  }

  // Unit test case for XML Schema validation

  ("UDF xmlSchemaValidation" should
    "validate the xml message against a given schema and return true")
    .taggedAs(Spark) in {
    // Import implicit Spark SQL functions from the existing SQLContext
    import spark.implicits._

    // Create test dataframe from resource file and apply UDF
    // Test case 1 : For Schema match case
    val xml = <bookstore>
      <book category="COOKING">
        <title lang="en">Everyday Italian</title>
        <author>Giada De Laurentiis</author>
        <year>2005</year>
        <price>30.00</price>
      </book>
    </bookstore>
    val xml_message = Seq((1, xml.toString()))
    val data = xml_message.toDF("id", "value")
    val testDF = data
      .withColumn(
        "xmlSchemavalidation",
        udfs("xmlSchemavalidation")(column("value"), lit(testXmlSchemaString))
      )
      .select("xmlSchemavalidation")
    // Create result dataframe
    val resultDF =
      sc.parallelize(List[Boolean](true)).toDF("xmlSchemavalidation")

    assertDataFrameEquals(testDF, resultDF)
  }

  (it should
    "validate the xml message against a given schema and return false due mismatch in data type of year field")
    .taggedAs(Spark) in {
    // Import implicit Spark SQL functions from the existing SQLContext
    import spark.implicits._

    // Create test dataframe from resource file and apply UDF
    // Test case 2 : For data type mismatch [Invalid Schema]
    val xml = <bookstore>
      <book category="COOKING">
        <title lang="en">Everyday Italian</title>
        <author>Giada De Laurentiis</author>
        <year>2005.05</year>
        <price>30.00</price>
      </book>
    </bookstore>
    val xml_message = Seq((1, xml.toString()))
    val data = xml_message.toDF("id", "value")
    val testDF = data
      .withColumn(
        "xmlSchemavalidation",
        udfs("xmlSchemavalidation")(column("value"), lit(testXmlSchemaString))
      )
      .select("xmlSchemavalidation")
    // Create result dataframe
    val resultDF =
      sc.parallelize(List[Boolean](false)).toDF("xmlSchemavalidation")

    assertDataFrameEquals(testDF, resultDF)
  }

  (it should
    "validate the xml message against a given schema and return false due to missing required field ")
    .taggedAs(Spark) in {
    // Import implicit Spark SQL functions from the existing SQLContext
    import spark.implicits._

    // Create test dataframe from resource file and apply UDF
    // Test case 3 : For Invalid xml source data  [Invalid Schema]
    val xml = <bookstore>
      <book category="COOKING">
        <title lang="en">Everyday Italian</title>
        <author1>Giada De Laurentiis</author1>
        <year>2005</year>
        <price>30.00</price>
      </book>
    </bookstore>
    val xml_message = Seq((1, xml.toString()))
    val data = xml_message.toDF("id", "value")
    val testDF = data
      .withColumn(
        "xmlSchemavalidation",
        udfs("xmlSchemavalidation")(column("value"), lit(testXmlSchemaString))
      )
      .select("xmlSchemavalidation")
    // Create result dataframe
    val resultDF =
      sc.parallelize(List[Boolean](false)).toDF("xmlSchemavalidation")

    assertDataFrameEquals(testDF, resultDF)

  }
  // Unit test case for xml validation
  ("UDF isValidXml" should
    "validate the xml message is and return true ")
    .taggedAs(Spark) in {
    // Import implicit Spark SQL functions from the existing SQLContext
    import spark.implicits._

    // Create test dataframe from resource file and apply UDF
    // Test case 1 : For valid XMl match case
    val xml =
      """<ROW>
      <TTNR>0273010574</TTNR>
      <STATIONNR>9999</STATIONNR>
      <SYMB_ADR>-</SYMB_ADR>
      <TESTSTEPS>
        <TESTSTEPS_ROW>
          <POSNR>0</POSNR>
          <D8>N</D8>
          <PAAREL>0</PAAREL>
        </TESTSTEPS_ROW>
      </TESTSTEPS>
    </ROW>"""
    val xml_message = Seq(xml)
    val data = xml_message.toDF("value")
    val testDF = data
      .withColumn("isValidXml", udfs("isValidXml")(column("value")))
      .select("isValidXml")
    // Create result dataframe
    val resultDF = sc.parallelize(List[Boolean](true)).toDF("isValidXml")

    assertDataFrameEquals(testDF, resultDF)
  }

  (it should
    "validate the xml message is valid return false due to missing tag ")
    .taggedAs(Spark) in {
    // Import implicit Spark SQL functions from the existing SQLContext
    import spark.implicits._

    // Create test dataframe from resource file and apply UDF
    // Test case 2 : For Invalid XMl match case(Invalid XML)
    val xml =
      """<ROW>
      <TTNR>0273010574</TTNR>
      <STATIONNR>9999</STATIONNR>
      <SYMB_ADR>-</SYMB_ADR>
      <TESTSTEPS>
        <TESTSTEPS_ROW>
          <POSNR>0</POSNR>
          <D8>N</D8>
          <PAAREL>0</PAAREL>
      </TESTSTEPS>
    </ROW>"""
    val xml_message = Seq(xml)
    val data = xml_message.toDF("value")
    val testDF = data
      .withColumn("isValidXml", udfs("isValidXml")(column("value")))
      .select("isValidXml")
    // Create result dataframe
    val resultDF = sc.parallelize(List[Boolean](false)).toDF("isValidXml")

    assertDataFrameEquals(testDF, resultDF)
  }

  // Unit test case for Json creation
  ("UDF parseXml" should
    "return a dataframe with transformed Json format")
    .taggedAs(Spark) in {
    // Import implicit Spark SQL functions from the existing SQLContext
    import spark.implicits._

    // Create test dataframe from resource file and apply UDF
    val xml =
      """<ROW>
        <TTNR>0273010574</TTNR>
        <STATIONNR>9999</STATIONNR>
        <SYMB_ADR>-</SYMB_ADR>
        <TESTSTEPS>
          <TESTSTEPS_ROW>
            <POSNR>0</POSNR>
            <D8>N</D8>
            <PAAREL>0</PAAREL>
          </TESTSTEPS_ROW>
        </TESTSTEPS>
      </ROW>"""
    val xml_message = Seq((xml, "ROW"))
    val data = xml_message.toDF("value", "xmlPattern")
    val testDF = data
      .withColumn(
        "parseXml",
        udfs("parseXml")(column("value"), column("xmlPattern"))
      )
      .select("parseXml")
    // Create result dataframe
    val json =
      """{"ROW":{"TTNR":"0273010574","STATIONNR":"9999","SYMB_ADR":"-","TESTSTEPS":{"TESTSTEPS_ROW":{"POSNR":"0","D8":"N","PAAREL":"0"}}}}"""
    val json_message = Seq(json)
    val resultDF = json_message.toDF("parseXml")
    assertDataFrameEquals(testDF, resultDF)
  }
  // Unit test case selectFromTable
  ("UDF selectFromTable" should
    "return the columns which are matching with given table name")
    .taggedAs(Spark) in {
    // Get or create available Spark session
    val spark: SparkSession = SparkSession.builder().getOrCreate()
    // Import implicit Spark SQL functions from the existing SQLContext
    import spark.sqlContext.implicits._
    val message: String =
      """{"table":"QUALITYDB.LOCATION_RESULTS","op_type":"U","op_ts":"2023-01-30 11:37:18.003071","current_ts":"2023-01-30T11:37:22.526000","pos":"00000035360314135130","before":{"LOCATION_RESULT_UID":"no5f2LIv60KCYB5602X2pA==","ARCHIVE_FLAG":1,"TIME_STAMP":"2013-11-16 06:46:41.892820000 +01:00"},"after":{"LOCATION_RESULT_UID":"no5f2LIv60KCYB5602X2pA==","UNIQUEPART_ID":"0711000002529280","LOCATION_ID":"0000000001100733000110002","RESULT_DATE":"2013-10-21 21:34:06.401557000 +00:00","PROCESS_NUMBER":1045,"PSTATINTERVAL":null,"WORKCYCLE_COUNTER":0,"RESULT_STATE":1,"PART_ATTRIBUTE":null,"TYPE_NUMBER":"1277022470","TYPE_VARIANT":"1039R02486","TYPE_VERSION":null,"MACHINE_ID":null,"SHIFT_CODE":2,"ARCHIVE_FLAG":-1,"BATCH":"210233","DELETE_DATE":"2014-01-19 21:34:06.000000000 +00:00","TEST_TYPE":null,"TIME_STAMP":"2023-01-30 10:37:18.646144000 +00:00"}}"""
    val data = Seq(message).toDF("content")
    // Create test dataframe from resource file and apply UDF
    val testDF = data
      .withColumn(
        "selectFromTable",
        udfs("selectFromTable")(column("content"), lit(".LOCATION_RESULTS"))
      )
      .select("selectFromTable")
    // Create result dataframe
    val message1: Array[String] = Array(
      """{"table":"QUALITYDB.LOCATION_RESULTS","op_type":"U","op_ts":"2023-01-30 11:37:18.003071","current_ts":"2023-01-30T11:37:22.526000","pos":"00000035360314135130","before":{"LOCATION_RESULT_UID":"no5f2LIv60KCYB5602X2pA==","ARCHIVE_FLAG":1,"TIME_STAMP":"2013-11-16 06:46:41.892820000 +01:00"},"after":{"LOCATION_RESULT_UID":"no5f2LIv60KCYB5602X2pA==","UNIQUEPART_ID":"0711000002529280","LOCATION_ID":"0000000001100733000110002","RESULT_DATE":"2013-10-21 21:34:06.401557000 +00:00","PROCESS_NUMBER":1045,"PSTATINTERVAL":null,"WORKCYCLE_COUNTER":0,"RESULT_STATE":1,"PART_ATTRIBUTE":null,"TYPE_NUMBER":"1277022470","TYPE_VARIANT":"1039R02486","TYPE_VERSION":null,"MACHINE_ID":null,"SHIFT_CODE":2,"ARCHIVE_FLAG":-1,"BATCH":"210233","DELETE_DATE":"2014-01-19 21:34:06.000000000 +00:00","TEST_TYPE":null,"TIME_STAMP":"2023-01-30 10:37:18.646144000 +00:00"}}"""
    )
    val resultDF = Seq(message1).toDF("selectFromTable")
    assertDataFrameEquals(testDF, resultDF)
  }

  // Unit test case for getResultColumn
  ("UDF getResultColumn" should
    "match to a dataframe with an aggregated column from a structured array field")
    .taggedAs(Spark) in {
    // Get or create available Spark session
    val spark: SparkSession = SparkSession.builder().getOrCreate()
    // Import implicit Spark SQL functions from the existing SQLContext
    import spark.sqlContext.implicits._
    val sample_df = Seq(
      (8.0, "0", null),
      (18.0, "PAM", null),
      (3.0, null, "1"),
      (8.0, "113138", null)
    ).toDF("data_type", "result_string", "result_value")
    // Create test dataframe from resource file and apply UDF
    val testDF = sample_df
      .withColumn(
        "getResultColumn",
        udfs("getResultColumn")(
          column("data_type"),
          column("result_string"),
          column("result_value")
        )
      )
      .select("getResultColumn")
    // Create result dataframe
    val resultDF = sc
      .parallelize(List[String]("0", null, "1", "113138"))
      .toDF("getResultColumn")
    assertDataFrameEquals(testDF, resultDF)
  }

  // Unit test case for convertKeysToLower

  ("UDF convertKeysToLower" should
    "return a dataframe with transformed Json keys into lower case")
    .taggedAs(Spark) in {
    // Import implicit Spark SQL functions from the existing SQLContext
    import spark.implicits._
    // Create test input dataframe
    val original_str =
      """{"$type":"urn:bosch:nexeed:eventtype:entity:v1","correlationId":"bdc8cdfb","msgTopic":"aertp2prod.push","PAYload":{"$type":"urn:bosch::v1","eventId":"5bddcdfb","document":{"basicInfo":{"identifier":"07120000","locationID":"12013300","resultdate":"2023-05-23T21:20:03.0155485+02:00"},"partDetails":{"parameters":[{"testKey1":"testVal1"},{"testKey2":"testVal2"}]}}}}"""
    val message = Seq(original_str)
    val dataDF = message.toDF("value")
    val testDF = dataDF
      .withColumn(
        "convertKeysToLower",
        udfs("convertKeysToLower")(column("value"))
      )
      .select("convertKeysToLower")
    // Create result dataframe
    val result_str =
      """{"$type":"urn:bosch:nexeed:eventtype:entity:v1","correlationid":"bdc8cdfb","msgtopic":"aertp2prod.push","payload":{"$type":"urn:bosch::v1","eventid":"5bddcdfb","document":{"basicinfo":{"identifier":"07120000","locationid":"12013300","resultdate":"2023-05-23T21:20:03.0155485+02:00"},"partdetails":{"parameters":[{"testkey1":"testVal1"},{"testkey2":"testVal2"}]}}}}"""
    val result_message = Seq(result_str)
    val resultDF = result_message.toDF("convertKeysToLower")
    assertSmallDataFrameDataEquals(testDF, resultDF)
  }

  (it should
    "return a dataframe with transformed Json keys into lower case for the sample input json")
    .taggedAs(Spark) in {
    // Import implicit Spark SQL functions from the existing SQLContext
    import spark.implicits._
    // Create test input dataframe
    val inputStr = """{"KeyExample":"KeyValue","KeyExample2":"KeyValue2"}"""
    val actualDf = Seq(inputStr)
      .toDF("value")
      .withColumn(
        "convertKeysToLower",
        udfs("convertKeysToLower")(column("value"))
      )
      .select("convertKeysToLower")

    // Create result dataframe
    val expectedStr =
      """{"keyexample":"KeyValue","keyexample2":"KeyValue2"}"""
    val expectedDF = Seq(expectedStr).toDF("convertKeysToLower")
    assertSmallDataFrameDataEquals(actualDf, expectedDF)
  }

  (it should
    "return a dataframe with transformed Json keys into lower case for the nested input json")
    .taggedAs(Spark) in {
    // Import implicit Spark SQL functions from the existing SQLContext
    import spark.implicits._
    // Create test input dataframe
    val inputStr2 =
      """{"KeyExample":"KeyValue","KeyExampleNest": {"NestedKey1":"NestedKeyValue1","NestedKey2":"NestedKeyValue2"}}"""
    val actualDf2 = Seq(inputStr2)
      .toDF("value")
      .withColumn(
        "convertKeysToLower",
        udfs("convertKeysToLower")(column("value"))
      )
      .select("convertKeysToLower")

    // Create result dataframe
    val expectedStr2 =
      """{"keyexample":"KeyValue","keyexamplenest":{"nestedkey1":"NestedKeyValue1","nestedkey2":"NestedKeyValue2"}}"""
    val expectedDF2 = Seq(expectedStr2).toDF("convertKeysToLower")
    assertSmallDataFrameDataEquals(actualDf2, expectedDF2)
  }

  (it should
    "return a dataframe with transformed Json keys into lower case for the input json containing array")
    .taggedAs(Spark) in {
    // Import implicit Spark SQL functions from the existing SQLContext
    import spark.implicits._
    // Create test input dataframe
    val inputStr3 =
      """{"KeyExample":"KeyValue","KeyExampleNest": {"NestedKey1":["arrayval1","ArrayVal1","ARRAYVAL"]}}"""
    val actualDf3 = Seq(inputStr3)
      .toDF("value")
      .withColumn(
        "convertKeysToLower",
        udfs("convertKeysToLower")(column("value"))
      )
      .select("convertKeysToLower")

    // Create result dataframe
    val expectedStr3 =
      """{"keyexample":"KeyValue","keyexamplenest":{"nestedkey1":["arrayval1","ArrayVal1","ARRAYVAL"]}}"""
    val expectedDF3 = Seq(expectedStr3).toDF("convertKeysToLower")
    assertSmallDataFrameDataEquals(actualDf3, expectedDF3)
  }

  (it should
    "return a dataframe with transformed Json keys into lower case for the input json containing array of struct ")
    .taggedAs(Spark) in {
    // Import implicit Spark SQL functions from the existing SQLContext
    import spark.implicits._
    // Create test input dataframe
    val inputStr4 =
      """{"KeyExample":"KeyValue","SubKey":[{"KeyExample2":"KeyValue2","KeyExample3": "KeyValue3"},{"KeyExample4": "KeyValue4", "KeyExample5": "KeyValue5"}]}"""
    val actualDf4 = Seq(inputStr4)
      .toDF("value")
      .withColumn(
        "convertKeysToLower",
        udfs("convertKeysToLower")(column("value"))
      )
      .select("convertKeysToLower")

    // Create result dataframe
    val expectedStr4 =
      """{"keyexample":"KeyValue","subkey":[{"keyexample2":"KeyValue2","keyexample3":"KeyValue3"},{"keyexample4":"KeyValue4","keyexample5":"KeyValue5"}]}"""
    val expectedDF4 = Seq(expectedStr4).toDF("convertKeysToLower")
    assertSmallDataFrameDataEquals(actualDf4, expectedDF4)
  }

  // Unit test case for rotate_value
  ("UDF rotate_value" should
    "match to a dataframe with an aggregated column from a structured array field")
    .taggedAs(Spark) in {
    // Get or create available Spark session
    val spark: SparkSession = SparkSession.builder().getOrCreate()
    // Import implicit Spark SQL functions from the existing SQLContext
    import spark.sqlContext.implicits._
    // Test case 1 : sorting/ordering value_array based on index_array
    val df = Seq("1,2,3").toDF("id")
    val index_array = Array(1, 2, 3, 4)
    val value_array = Array(
      0.00516003284701762,
      0.00637004210675609,
      0.00732835634959461,
      0.00807857630238591
    )
    val sample_df = df
      .withColumn("index1", typedLit(index_array))
      .withColumn("value1", typedLit(value_array))
    // Create test dataframe from resource file and apply UDF
    val testDF = sample_df
      .withColumn(
        "rotate_value",
        udfs("rotate_value")(column("index1"), column("value1"))
      )
      .select("rotate_value")
    // Create result dataframe

    val resultDF = Seq(
      "0.00516003284701762,0.00637004210675609,0.00732835634959461,0.00807857630238591"
    ).toDF("rotate_value")
    assertDataFrameEquals(testDF, resultDF)
  }

  (it should
    "match to a dataframe with an aggregated column from a structured array field by sorting/ordering value_array based on index_array")
    .taggedAs(Spark) in {
    // Get or create available Spark session
    val spark: SparkSession = SparkSession.builder().getOrCreate()
    // Import implicit Spark SQL functions from the existing SQLContext
    import spark.sqlContext.implicits._
    // Test case 2 : sorting/ordering value_array based on index_array
    val df = Seq("1,2,3").toDF("id")
    val index_array = Array(3, 4, 1, 2)
    val value_array = Array(
      0.00516003284701762,
      0.00637004210675609,
      0.00732835634959461,
      0.00807857630238591
    )
    val sample_df = df
      .withColumn("index1", typedLit(index_array))
      .withColumn("value1", typedLit(value_array))
    // Create test dataframe from resource file and apply UDF
    val testDF = sample_df
      .withColumn(
        "rotate_value",
        udfs("rotate_value")(column("index1"), column("value1"))
      )
      .select("rotate_value")
    // Create result dataframe

    val resultDF = Seq(
      "0.00732835634959461,0.00807857630238591,0.00516003284701762,0.00637004210675609"
    ).toDF("rotate_value")
    assertDataFrameEquals(testDF, resultDF)
  }

  // Unit test case for formatHexString
  ("UDF formatHexString" should
    "return a dataframe with transformed string into formatted hexa format")
    .taggedAs(Spark) in {
    // Import implicit Spark SQL functions from the existing SQLContext
    import spark.implicits._

    // Create test dataframe from resource file and apply UDF
    val binaryData = Seq(
      Array[Byte](
        0xf3.toByte,
        0xeb.toByte,
        0x06.toByte,
        0x64.toByte,
        0xde.toByte,
        0x1f.toByte,
        0x30.toByte,
        0x44.toByte,
        0x93.toByte,
        0x0b.toByte,
        0x50.toByte,
        0x35.toByte,
        0x30.toByte,
        0x2e.toByte,
        0xb7.toByte,
        0xaa.toByte
      )
    )
    val sample_df = spark
      .createDataFrame(binaryData.map(Tuple1.apply))
      .toDF("binary_data")
      .select(hex($"binary_data").as("hex_data"))
    val testDF = sample_df
      .withColumn(
        "formatHexString",
        udfs("formatHexString")(column("hex_data"))
      )
      .select("formatHexString")
    // Create result dataframe
    val result_str = "[F3 EB 06 64 DE 1F 30 44 93 0B 50 35 30 2E B7 AA]"
    val result_message = Seq(result_str)
    val resultDF = result_message.toDF("formatHexString")
    assertDataFrameEquals(testDF, resultDF)
  }

  ("UDF processStructAndReverseHexToAscii" should
    "coverts decimal to hexa decimal than to ascii code and then reverse it")
    .taggedAs(Spark) in {
    // Create test dataframe from resource file and apply UDF
    // Test case 1 : schema validation against a given schema
    import spark.implicits._

    val jsonString = List(
      (
        """{"hobLamUniqueLcdPartID": {
          |              "LcdUID01Lam": 12593,
          |              "LcdUID02Lam": 14648,
          |              "LcdUID03Lam": 12345,
          |              "LcdUID04Lam": 51  }}""".stripMargin,
        "1"
      )
    )
    spark
      .createDataFrame(jsonString)
      .toDF("value", "recordNo")
      .createOrReplaceTempView("testing_df")

    val testDF2 = spark.sql(
      """SELECT parsed.* FROM (SELECT from_json(CAST(value AS STRING),'STRUCT<
      `hobLamUniqueLcdPartID`: STRUCT<
    LcdUID01Lam: LONG,
    LcdUID02Lam: LONG,
    LcdUID03Lam: LONG,
    LcdUID04Lam: LONG
    >>') AS parsed FROM testing_df)""".stripMargin
    )
    val outputDF = testDF2
      .withColumn(
        "processStructAndReverseHexToAscii",
        udfs("processStructAndReverseHexToAscii")(
          column("hobLamUniqueLcdPartID")
        )
      )

    val testDF = outputDF.select("processStructAndReverseHexToAscii")
    val resultDF = Seq("1189903").toDF("processStructAndReverseHexToAscii")

    assertDataFrameEquals(testDF, resultDF)
  }

  (it should
    "coverts decimal to hexa decimal than to ascii code and then reverse it but skip null values")
    .taggedAs(Spark) in {
    // Create test dataframe from resource file and apply UDF
    // Test case 1 : schema validation against a given schema
    import spark.implicits._

    val jsonString1 = List(
      (
        """{"hobLamUniqueLcdPartID": {
          |              "LcdUID01Lam": 12593,
          |              "LcdUID02Lam": 14648,
          |              "LcdUID03Lam": 0,
          |              "LcdUID04Lam": 0  }}""".stripMargin,
        "1"
      )
    )
    spark
      .createDataFrame(jsonString1)
      .toDF("value", "recordNo")
      .createOrReplaceTempView("testing_df")

    val testDF2a = spark.sql(
      """SELECT parsed.* FROM (SELECT from_json(CAST(value AS STRING),'STRUCT<
      `hobLamUniqueLcdPartID`: STRUCT<
    LcdUID01Lam: LONG,
    LcdUID02Lam: LONG,
    LcdUID03Lam: LONG,
    LcdUID04Lam: LONG
    >>') AS parsed FROM testing_df)""".stripMargin
    )
    val outputDF1 = testDF2a
      .withColumn(
        "processStructAndReverseHexToAscii",
        udfs("processStructAndReverseHexToAscii")(
          column("hobLamUniqueLcdPartID")
        )
      )

    val testDF1 = outputDF1.select("processStructAndReverseHexToAscii")
    val resultDF1 = Seq("1189").toDF("processStructAndReverseHexToAscii")
    assertDataFrameEquals(testDF1, resultDF1)
  }

  ("UDF decodeBase64" should "correctly decode a Base64 encoded string to its original byte array") in {
    import spark.implicits._

    // Base64 encoded string
    val base64EncodedString = Seq("QUUvTVNELUlO").toDF("encodedString")

    val decodedDF = base64EncodedString
      .withColumn("decodedBytes", udfs("decodeBase64")($"encodedString"))
      .select("decodedBytes")

    val expectedBytes = "AE/MSD-IN".getBytes("UTF-8")
    val expectedDF = Seq(expectedBytes).toDF("decodedBytes")

    assertDataFrameEquals(decodedDF, expectedDF)
  }

  ("UDF encodedString2ArrayOfDoubles" should "correctly decode Base64 string and convert to array of doubles") in {
    import spark.implicits._
    val encodedString = "AAA6mAAANrAAADLIAAAu4AAAKvg="
    val scalefactor = 10000
    val encodedDF = Seq(encodedString).toDF("encodedString")
    val decodedDF = encodedDF
      .withColumn(
        "doubleArray",
        udfs("encodedString2ArrayOfDoubles")($"encodedString", lit(scalefactor))
      )
      .select("doubleArray")

    val expectedArray = Array(
      1.5d, 1.4d, 1.3d, 1.2d, 1.1d
    )
    val expectedDF = Seq(expectedArray).toDF("doubleArray")
    assertDataFrameEquals(decodedDF, expectedDF)

    // testing with all 0's
    val encodedStringZeros = "AAAAAAAAAAAAAAAAAAAAAAAAAAA="
    val encodedDFZeros = Seq(encodedStringZeros).toDF("encodedString")
    val decodedDFZeros = encodedDFZeros
      .withColumn(
        "doubleArray",
        udfs("encodedString2ArrayOfDoubles")($"encodedString", lit(scalefactor))
      )
      .select("doubleArray")

    val expectedArrayZeros = Array(
      0.0d, 0.0d, 0.0d, 0.0d, 0.0d
    )
    val expectedDFZeros = Seq(expectedArrayZeros).toDF("doubleArray")
    assertDataFrameEquals(decodedDFZeros, expectedDFZeros)
    // Test with null values
    val nullEncodedString: String = null
    val nullEncodedDF = Seq(Option(nullEncodedString)).toDF("encodedString")
    val decodedNullDF = nullEncodedDF
      .withColumn(
        "doubleArray",
        udfs("encodedString2ArrayOfDoubles")($"encodedString", lit(scalefactor))
      )
      .select("doubleArray")

    val expectedNullArray =
      Array[Double]() // UDF handles null by returning an empty array
    val expectedNullDF = Seq(expectedNullArray).toDF("doubleArray")
    assertDataFrameEquals(decodedNullDF, expectedNullDF)
  }

  (it should "correctly decode Base64 string and convert to array of doubles for negative values") in {
    import spark.implicits._
    val encodedString = "AAAq+P//zTgAAC7g///JUP//xWg="
    val scalefactor = 10000
    val encodedDF = Seq(encodedString).toDF("encodedString")
    val decodedDF = encodedDF
      .withColumn(
        "doubleArray",
        udfs("encodedString2ArrayOfDoubles")($"encodedString", lit(scalefactor))
      )
      .select("doubleArray")

    val expectedArray = Array(
      1.1d, -1.3d, 1.2d, -1.4d, -1.5d
    )

    val expectedDF = Seq(expectedArray).toDF("doubleArray")
    assertDataFrameEquals(decodedDF, expectedDF)

  }

  (it should "throw an error when input has insufficient bytes") in {
    import spark.implicits._

    // Input with insufficient bytes (3 bytes instead of 4 for an integer)
    val encodedStringInsufficientBytes = "AAAAAA=="
    val scalefactor = 10000
    val encodedDF = Seq(encodedStringInsufficientBytes).toDF("encodedString")

    // try catch block
    def runUDF(): DataFrame = {
      try {
        encodedDF
          .withColumn(
            "doubleArray",
            udfs("encodedString2ArrayOfDoubles")(
              $"encodedString",
              lit(scalefactor)
            )
          )
          .select("doubleArray")
          .collect()
        throw new Exception("Expected exception was not thrown")
      } catch {
        case e: Exception => throw e
      }
    }

    // validating the exception
    assertThrows[Exception] {
      runUDF()
    }
  }

  // Unit test case for decompress Gzip message
  ("UDF decompressGzippedMessage" should
    "handle decompressing and return a string").taggedAs(Spark) in {

    import spark.sqlContext.implicits._

    new testXMLFixture {

      // first, compress the XML message and decompress it using the UDF
      val gzippedXML: Array[Byte] = gzipMessage()
      val byteDataset: Dataset[Array[Byte]] =
        spark.createDataset(Seq(gzippedXML))
      val testMessageDF: DataFrame = byteDataset.toDF("value")

      val testDF: DataFrame = testMessageDF
        .withColumn(
          "content",
          udfs("decompressGzippedMessage")(column("value"))
        )
        .select("content")

      testDF.show()

      // compare directly against the original XML message --> results should be the same
      val resultDF: DataFrame = Seq(xmlMessage).toDF("content")

      // validate results
      assertDataFrameEquals(testDF, resultDF)
    }

  }

  (it should
    "handle string messages transparently").taggedAs(Spark) in {
    import spark.sqlContext.implicits._

    new testXMLFixture {
      val byteArrayXML: Array[Byte] = xmlMessageBytes

      val byteDataset: Dataset[Array[Byte]] =
        spark.createDataset(Seq(byteArrayXML))
      val testMessageDF: DataFrame = byteDataset.toDF("value")

      val testDF: DataFrame = testMessageDF
        .withColumn(
          "content",
          udfs("decompressGzippedMessage")(column("value"))
        )
        .select("content")

      val resultDF: DataFrame =
        sc.parallelize(Seq(xmlMessage)).toDF("content")

      // validate the results
      assertDataFrameEquals(testDF, resultDF)
    }
  }

  (it should "handle null messages").taggedAs(Spark) in {
    import spark.sqlContext.implicits._

    val EmptyDF: DataFrame =
      sc.parallelize(Seq(null.asInstanceOf[String])).toDF("value")

    val testDF: DataFrame = EmptyDF
      .withColumn(
        "content",
        udfs("decompressGzippedMessage")(column("value"))
      )
      .select("content")

    val resultDF: DataFrame =
      sc.parallelize(Seq(null.asInstanceOf[String])).toDF("content")

    // validate results
    assertDataFrameEquals(testDF, resultDF)
  }

}
