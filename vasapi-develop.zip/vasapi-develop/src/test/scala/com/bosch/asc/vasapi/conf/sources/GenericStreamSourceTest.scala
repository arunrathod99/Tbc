/*
 * Copyright (c) 2024 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */

package com.bosch.asc.vasapi.conf.sources

import org.mockito.MockitoSugar
import org.scalatest.BeforeAndAfter
import com.bosch.asc.vasapi.UnitSpec
import com.bosch.asc.vasapi.conf.Source
import org.apache.spark.sql.{DataFrame, Row}
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.streaming.Trigger
import org.mockito.ArgumentMatchers.anyString
import com.holdenkarau.spark.testing.DataFrameSuiteBase

trait GenericStreamSourceTest
    extends UnitSpec
    with BeforeAndAfter
    with DataFrameSuiteBase
    with MockitoSugar {
  var source: Source = _

  // Common method to create the source instance
  def createSource(
      format: String,
      load: Option[String],
      schema: Option[String],
      options: Option[Map[String, String]]
  ): GenericStreamSource = {
    source = Source(
      "testSource",
      format,
      None,
      None,
      schema,
      None,
      load,
      options,
      None
    )
    new GenericStreamSource(source)
  }
}

// Trait to initialize and manage Spark queries
trait StreamQueryTestHelper {
  this: GenericStreamSourceTest =>

  // Runs a stream query with the provided parameters
  def runStreamQuery(
      queryName: String,
      format: String,
      dataPath: Option[String],
      schemaPath: Option[String]
  ): Unit = {
    val streamSource =
      createSource(format, dataPath, schemaPath, Some(Map("" -> "")))
    val query = streamSource
      .registerSource(spark)
      .writeStream
      .format("memory")
      .queryName(queryName)
      .trigger(Trigger.Once())
      .start()

    query.awaitTermination()
  }

  // Runs a batch query with the provided parameters
  def runBatchQuery(
      format: String,
      dataPath: Option[String],
      schemaPath: Option[String]
  ): DataFrame = {
    val streamSource =
      createSource(format, dataPath, schemaPath, Some(Map("" -> "")))
    if (dataPath.isDefined) {
      streamSource.registerSource(spark)
    } else {
      val schema = schemaPath.flatMap(path =>
        Some(spark.read.format("json").load(path).schema)
      )
      spark.createDataFrame(
        spark.sparkContext.emptyRDD[Row],
        schema.getOrElse(new StructType())
      )
    }
  }
}

/** Test suite for the GenericStreamSource implementation. Verifies the behavior
  * of the GenericStreamSource in different scenarios:
  *
  *   1. Loading data with a provided path and schema. 2. Loading data with a
  *      provided path and no schema. 3. Returning empty DataFrame for schema
  *      without a data path. 4. Error handling for unsupported data formats. 5.
  *      Schema validation failure with mismatched schema and data.
  */

class LoadWithPathAndSchemaSpec
    extends GenericStreamSourceTest
    with StreamQueryTestHelper {

  "GenericStreamSource with path and schema" should "correctly load data using the provided schema and path" in {

    runStreamQuery(
      "testWithSchema",
      "json",
      Some("src/test/resources/json_data_files"),
      Some("src/test/resources/student_details_schema.json")
    )

    val expectedData = Seq(
      Row("gvDOrNCmdO", 89, "College_73"),
      Row("mRddiDnwDE", 60, "College_41"),
      Row("VCNeFyICrv", 83, "College_35"),
      Row("hNgtBZzmVc", 91, "College_14"),
      Row("GBHLWxRtGH", 93, "College_85")
    )

    val loadedData = spark.table("testWithSchema").collect()
    loadedData should contain theSameElementsAs expectedData
  }

  "GenericStreamSource with path and no schema" should "load the data with inferred schema" in {
    // Setting the Spark configuration to enable schema inference
    spark.conf.set("spark.sql.streaming.schemaInference", "true")

    val queryName = "testDataWithInferredSchema"
    val format = "json"
    val dataPath =
      Some("src/test/resources/json_data_files")

    runStreamQuery(queryName, format, dataPath, None)
    // Asserts
    val loadedData = spark.table(queryName).collect()
    assert(loadedData.nonEmpty, "Data should be loaded and not be empty")
    assert(
      spark.table(queryName).schema.fields.nonEmpty,
      "Schema should be inferred and not be empty"
    )
  }

  "GenericStreamSource with schema and without path" should "return an empty DataFrame with the correct schema" in {
    val schemaPath = "src/test/resources/student_details_schema.json"
    val df = runBatchQuery("json", None, Some(schemaPath))

    assert(df.count() == 0, "The DataFrame should be empty")

    val expectedSchema = spark.read.format("json").load(schemaPath).schema
    assert(
      df.schema == expectedSchema,
      "The DataFrame schema should match the expected schema"
    )
  }

  // Edge cases from here ->
  "GenericStreamSource with incorrect data format" should "log an error when an unsupported format is used" in {
    val mockSource = mock[Source]
    when(mockSource.format).thenReturn("random_format")
    when(mockSource.load).thenReturn(
      Some("src/test/resources/GenericStreamSourceFiles/parquet_files")
    )
    when(mockSource.createSourceSchema(Some(anyString), Some(anyString)))
      .thenReturn(None)

    val streamSource = new GenericStreamSource(mockSource)

    assertThrows[Exception] {
      streamSource.registerSource(spark)
    }
  }

  "GenericStreamSource with mismatched schema and data" should "trigger a schema validation failure" in {

    spark.conf.set("spark.sql.streaming.schemaInference", "false")
    assertThrows[Exception] {
      runStreamQuery(
        "testSchemaMismatch",
        "json",
        Some("src/test/resources/json_data_files"),
        Some("src/test/resources/student_details_schema_mismatch.json")
      )
    }
  }
}
