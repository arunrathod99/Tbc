/*
 * Copyright (c) 2018, 2024 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */

package com.bosch.asc.vasapi.conf

import scala.reflect.ClassTag
import pureconfig.generic.auto._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.catalog.Table
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.types.StructType
import pureconfig.{ConfigObjectSource, ConfigSource}
import com.bosch.asc.vasapi.{Spark, UnitSpec, Vasapi}
import org.scalatest.{BeforeAndAfter, BeforeAndAfterAll}

/** Test class for the initialization of tables
  *
  * Hints:
  *   - we are not using SparkSessionCatalog because this would rely on a Hive
  *     Catalog which is not supported in local testing
  *   - spark.catalog.getTable(...) does not work for Iceberg tables in local
  *     tests, since we are not using SparkSessionCatalog (which would make
  *     iceberg tables accessible via the regular SparkSession's catalog)
  */
class InitializationTest
    extends UnitSpec
    with BeforeAndAfterAll
    with BeforeAndAfter {

  val testDBs: Seq[String] = Seq("hive", "iceberg")

  override def beforeAll(): Unit = {
    testDBs.foreach(db =>
      icebergSpark.sql(s"CREATE DATABASE IF NOT EXISTS $db").show()
    )
  }

  // TODO: this does not drop iceberg tables (since they are not registered in the SparkSession's catalog)
  after {
    for {
      db <- testDBs
      tbl <- icebergSpark.catalog.listTables(db).collect()
    } yield {
      spark.sql(s"DROP TABLE IF EXISTS ${tbl.database}.${tbl.name}")
    }
  }

  /** helper method to get tbl object from pureconfig string and table name
    */
  def getTable[A <: BaseTable: ClassTag](
      tblName: String,
      createTblString: String
  ): A = {
    val source: ConfigObjectSource = ConfigSource.string(createTblString)
    val vasapiConf: Vasapi = source.loadOrThrow[Vasapi]

    vasapiConf.allTables.find(_.name == tblName) match {
      case Some(tbl: A) => tbl
      case _            => fail("Table not found")
    }
  }

  trait HiveSinglePartition {
    val tblName: String = "hive.test_table_single"
    val tblString: String =
      s"""
        inits: [
          {
            type: "external-hive-table"
            name: $tblName
            drop-table: true
            ddl-schema: "id STRING, name BIGINT, place STRING, date STRING"
            partition-by: ["date"]
            comment: "test table with drop true and single partition"
            stored-as: "parquet"
            location: "test_table_drop_true_single_partition"
          }
        ],
        queries: []
      """

    val tbl: BaseTable = getTable[ExternalHiveTable](
      tblName = tblName,
      createTblString = tblString
    )
  }

  trait HiveMultiPartition {
    val tblName: String = "hive.test_table_multi"
    val tblString: String =
      s"""
      inits: [
        {
          type: "external-hive-table"
          name: $tblName
          drop-table: false
          ddl-schema: "id STRING, name BIGINT, place STRING, date STRING, hour STRING"
          partition-by: ["date", "hour"]
          comment: "test table with drop false and multiple partitions"
          stored-as: "orc"
          location: "test_table_drop_false_multi_partition"
        }
      ],
      queries: []
    """

    val tbl: BaseTable = getTable[ExternalHiveTable](
      tblName = tblName,
      createTblString = tblString
    )
  }

  trait HiveJsonSchema {
    val source: ConfigObjectSource = ConfigSource.string(
      """
      inits: [
        {
          "type": "external-hive-table"
          "name": "hive.test_table_simple"
          "drop-table": true
          "json-schema-file": "src/test/resources/test-schemas/spark_test_schema.json"
          "comment": "test table derived from a JSON schema file"
          "stored-as": "parquet"
          "location": "test_table_with_json_schema"
        },
        {
          "type": "external-hive-table"
          "name": "hive.test_table_merged"
          "drop-table": true
          "json-schema-file": "src/test/resources/test-schemas/spark_test_schema.json"
          "ddl-schema": "eventId STRING, eventName STRING, Zipcode STRING, mesLineNo INT"
          "partition-by": ["eventId", "eventName"]
          "comment": "test table derived from a JSON schema file"
          "stored-as": "parquet"
          "location": "test_table_with_json_schema"
        },
        {
          "type": "external-hive-table"
          "name": "hive.test_table_error"
          "drop-table": true
          "json-schema-file": "src/test/resources/test-schemas/json_test_schema.json"
          "ddl-schema": "eventId STRING, eventName STRING, mesLocationId STRING, mesLineNo INT"
          "partition-by": ["eventId", "desNotExist"]
          "comment": "test table derived from a JSON schema file"
          "stored-as": "parquet"
          "location": "test_table_with_json_schema"
        }
      ],
      queries: []
    """
    )

    val vasapiConf: Vasapi = source.loadOrThrow[Vasapi]

    val tbls: Map[String, ExternalHiveTable] = vasapiConf.externalTbls.map {
      tbl => tbl.name -> tbl
    }.toMap
  }

  trait IcebergNoLocation {
    val ctlg = "local"
    val db = "iceberg"
    val tblName = "test_table"
    val fullTblIdentifier: String = "local.iceberg.test_table"

    val tblString: String =
      s"""
        inits: [
          {
            type: "iceberg-table"
            name: $fullTblIdentifier
            ddl-schema: "id INT, name STRING, place STRING, date STRING"
            partition-by: ["date"]
            comment: "This is an Iceberg table without location"
          }
        ],
        queries: []
      """

    val tbl: BaseTable = getTable[IcebergTable](
      tblName = s"$ctlg.$db.$tblName",
      createTblString = tblString
    )
  }

  trait IcebergWithLocation {

    val ctlg = "local"
    val db = "iceberg"
    val tblName = "test_table"
    val fullTblIdentifier: String = "local.iceberg.test_table"

    val tblString: String =
      s"""
        inits: [
          {
            type: "iceberg-table"
            name: $fullTblIdentifier
            ddl-schema: "id INT, name STRING, place STRING, date STRING"
            partition-by: ["date"]
            comment: "This is an Iceberg table with location"
            tbl-properties: {"write.format.default": "avro"}
            location: "iceberg_test_table"
          }
        ],
        queries: []
      """

    val tbl: BaseTable = getTable[IcebergTable](
      tblName = s"$ctlg.$db.$tblName",
      createTblString = tblString
    )
  }

  trait IcebergErrorFormat {

    val ctlg = "local"
    val db = "iceberg"
    val tblName = "test_table"
    val fullTblIdentifier: String = "local.iceberg.test_table"

    val tblString: String =
      s"""
        inits: [
          {
            type: "iceberg-table"
            name: $fullTblIdentifier
            ddl-schema: "id INT, name STRING, place STRING, date STRING"
            partition-by: ["date"]
            comment: "This is an Iceberg table with location"
            tbl-properties: {"write.format.default": "error"}
            location: "iceberg_test_table"
          }
        ],
        queries: []
      """

    val tbl: BaseTable = getTable[IcebergTable](
      tblName = s"$ctlg.$db.$tblName",
      createTblString = tblString
    )
  }

  trait IcebergJsonSchema {

    val tblName: String = "local.iceberg.test_table_json"
    val tblString: String =
      s"""
        inits: [
          {
            type: "iceberg-table"
            name: $tblName
            json-schema-file: "test-schemas/spark_test_schema.json"
            partition-by: ["State"]
            comment: "This is an Iceberg table with a schema derived from a json file"
            tbl-properties: {"format-version": "2", "hive.supports.subdirectories": "TRUE"}
          }
        ],
        queries: []
      """

    val tbl: BaseTable = getTable[IcebergTable](
      tblName = tblName,
      createTblString = tblString
    )
  }

  ("registering an external hive table with drop true and single partition" should
    "yield a drop table statement").taggedAs(Spark) in {
    new HiveSinglePartition {

      tbl.dropTblStmt.getOrElse("not found") should
        be(s"DROP TABLE IF EXISTS ${tbl.name}")
    }
  }

  (it should "create a table with the configured properties").taggedAs(
    Spark
  ) in {
    new HiveSinglePartition {
      tbl.register(spark)

      val sparkTable: Table = icebergSpark.catalog.getTable(
        dbName = tbl.name.split("\\.")(0),
        tableName = tbl.name.split("\\.")(1)
      )

      val tblSchema: StructType =
        icebergSpark.sql(s"SELECT * FROM ${tbl.name}").schema

      sparkTable.description should be(
        "test table with drop true and single partition"
      )
      sparkTable.tableType should be("EXTERNAL")
      tblSchema.fieldNames should contain allOf ("id", "name", "place", "date")
    }

  }

  ("initializing an external hive table with drop false and multiple partitions" should
    "return a valid create statement") in {
    new HiveMultiPartition {
      // if attribute is None or false, dropTblStmt is None --> see implementation in Initialization.scala
      tbl.dropTblStmt.isEmpty should be(true)
    }
  }

  (it should "be possible to register the table in Spark").taggedAs(Spark) in {
    new HiveMultiPartition {
      tbl.register(spark)

      val sparkTable: Table = icebergSpark.catalog.getTable(
        dbName = tbl.name.split("\\.")(0),
        tableName = tbl.name.split("\\.")(1)
      )

      val tblSchema: StructType =
        icebergSpark.sql(s"SELECT * FROM ${tbl.name}").schema

      sparkTable.description should be(
        "test table with drop false and multiple partitions"
      )

      sparkTable.tableType should be("EXTERNAL")
      tblSchema.fieldNames should contain allOf ("id", "name", "place", "date")
    }
  }

  (it should "register the table with the correct partition columns") in {
    new HiveMultiPartition {
      tbl.register(spark)

      val describeTableDF: DataFrame =
        icebergSpark.sql(s"DESCRIBE EXTENDED ${tbl.name}")

      // partition columns are present as part of regular schema and separately as partition cols
      describeTableDF
        .select(col("col_name"))
        .where("col_name = 'date' or col_name = 'hour'")
        .count() should be(4)
    }
  }

  ("initializing an external hive table with a JSON schema file" should "return a valid create statement") in {
    new HiveJsonSchema {
      val tbl: ExternalHiveTable = tbls
        .getOrElse(
          "hive.test_table_simple",
          throw new NoSuchElementException("table not found")
        )

      tbl.register(spark)

      val sparkTable: Table = icebergSpark.catalog.getTable(
        dbName = tbl.name.split("\\.")(0),
        tableName = tbl.name.split("\\.")(1)
      )

      val tblSchema: StructType =
        icebergSpark.sql(s"SELECT * FROM ${tbl.name}").schema

      sparkTable.description should be(
        "test table derived from a JSON schema file"
      )
      sparkTable.tableType should be("EXTERNAL")
      tblSchema.fieldNames should contain only ("Zipcode", "TimestampType", "City", "State")
    }
  }

  it should "allow to merge json and ddl schemas" in {
    new HiveJsonSchema {
      val tbl: ExternalHiveTable = tbls
        .getOrElse(
          "hive.test_table_merged",
          throw new NoSuchElementException("table not found")
        )

      tbl.register(spark)

      val tblSchema: StructType =
        icebergSpark.sql(s"SELECT * FROM ${tbl.name}").schema
      tblSchema.fieldNames should contain allOf ("Zipcode", "TimestampType", "City", "State", "eventId", "eventName", "mesLineNo")
    }
  }

  it should "throw an exception if the partition columns are not part of the schema" in {
    new HiveJsonSchema {
      val tbl: ExternalHiveTable = tbls
        .getOrElse(
          "hive.test_table_error",
          throw new NoSuchElementException("table not found")
        )

      assertThrows[IllegalArgumentException] {
        tbl.register(spark)
      }
    }
  }

  "registering an iceberg table without a location" should "make the table available in the spark session" in {
    new IcebergNoLocation {
      tbl.register(icebergSpark)

      spark.sql(s"DESCRIBE $fullTblIdentifier").show()
    }
  }

  it should "configure table partitioning properly" in {
    new IcebergNoLocation {
      tbl.register(icebergSpark)

      icebergSpark.sql(
        s"INSERT INTO $fullTblIdentifier VALUES (1, 'myName', 'place1', '2021-01-01')"
      )
      icebergSpark.sql(s"SELECT * FROM $fullTblIdentifier").show()

      // show partitions
      icebergSpark
        .sql(s"SELECT * FROM $fullTblIdentifier.partitions")
        .count() should be(1)
    }
  }

  ("registering an iceberg table with a location" should "make the table available in the spark session") in {
    new IcebergWithLocation {
      tbl.register(icebergSpark)
      icebergSpark
        .sql(s"DESCRIBE EXTENDED $fullTblIdentifier")
        .show(truncate = false)
    }
  }

  // does not seem to work due to: https://github.com/apache/iceberg/issues/370
  (it should "allow to insert data into the table") in {

    new IcebergWithLocation {
      import icebergSpark.implicits._

      tbl.register(icebergSpark)
      spark.sql(s"DESCRIBE $fullTblIdentifier").show()

      val testDF: DataFrame = Seq((1, "myName", "place1", "2021-01-01")).toDF()
      testDF.writeTo(s"${tbl.name}")

      icebergSpark.read.table(s"${tbl.name}").show()
    }
  }

  ("registering an iceberg table with an invalid format" should "throw an exception") in {
    new IcebergErrorFormat {
      assertThrows[IllegalArgumentException] {
        tbl.register(icebergSpark)
      }
    }
  }

  ("initializing an iceberg table with a JSON schema file" should "return a valid create statement") in {
    new IcebergJsonSchema {
      tbl.register(spark)

      val tblSchema: StructType = spark.sql(s"SELECT * FROM ${tbl.name}").schema
      tblSchema.fieldNames should contain only ("Zipcode", "TimestampType", "City", "State")
    }
  }
}
