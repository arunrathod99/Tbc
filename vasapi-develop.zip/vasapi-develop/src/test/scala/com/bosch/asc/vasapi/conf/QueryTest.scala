/*
 * Copyright (c) 2022, 2023 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */

package com.bosch.asc.vasapi.conf

import com.bosch.asc.vasapi.utils.VasapiFileUtils
import org.mockito.MockitoSugar
import org.scalatest.BeforeAndAfter
import org.apache.spark.internal.Logging
import com.bosch.asc.vasapi.{Config, UnitSpec, Vasapi}
import org.apache.kafka.common.serialization.{
  Deserializer,
  Serializer,
  StringDeserializer,
  StringSerializer
}
import org.apache.spark.sql.SparkSession
import org.mockito.Mockito.{doNothing, times, verify}
import com.holdenkarau.spark.testing.DataFrameSuiteBase
import pureconfig.{ConfigObjectSource, ConfigSource}
import pureconfig.generic.auto._

class QueryTest
    extends UnitSpec
    with BeforeAndAfter
    with Logging
    with DataFrameSuiteBase {

  // serializers needed for producing to / consuming from embedded kafka topics
  implicit val serializer: Serializer[String] = new StringSerializer()
  implicit val deserializer: Deserializer[String] = new StringDeserializer()

  before {
    dropViewsTables()
    ()
  }

  ("Instantiating a vasapi with a source" should "create a source object and its attributes") in {
    val conf = VasapiFileUtils
      .safeResourceToString(
        "test-vasapi-confs/credential-test.conf"
      )
      .getOrElse("")

    val source: ConfigObjectSource = ConfigSource.string(conf)
    val vasapiConf: Vasapi = source.loadOrThrow[Vasapi]

    vasapiConf.sources.find(_.name == "testKafkaSource") match {
      case Some(source) =>
        assert(source.credentialOptions.nonEmpty)
      case None => fail
    }
  }

  ("Registering a source config element" should "instantiate the specified source")
    .taggedAs(
      Config
    ) in {

    com.bosch.asc.vasapi.conf
      .Source(
        name = "sourceConfigTest",
        format = "rate",
        serialization = None,
        ddlSchema = None,
        jsonSchemaFile = None,
        avroSchemaFile = None,
        load = None,
        options = Some(
          Map(
            "rowsPerSecond" -> "5",
            "rampUpTime" -> "4",
            "numPartitions" -> "3"
          )
        ),
        credentialOptions = None
      )
      .register

    val sourceSchema = spark.sql("select * from sourceConfigTest").schema
    assert(
      sourceSchema.head.name == "timestamp" && sourceSchema(1).name == "value"
    )
  }

  it should "not throw an error even if credentials cannot be decrypted" in {
    val conf = VasapiFileUtils
      .safeResourceToString(
        "test-vasapi-confs/credential-test.conf"
      )
      .getOrElse("")

    val source: ConfigObjectSource = ConfigSource.string(conf)
    val vasapiConf: Vasapi = source.loadOrThrow[Vasapi]

    vasapiConf.sources.find(_.name == "testKafkaSource") match {
      case Some(source) =>
        source.register(spark)
      case None => fail
    }
  }

  ("View config element" should "create a temporary view").taggedAs(Config) in {

    com.bosch.asc.vasapi.conf
      .View(
        "select 42 as `answer`",
        "viewConfigTest",
        None
      )
      .register

    assert(spark.sql("select * from viewConfigTest").take(1)(0)(0) == 42)
  }

  ("Calling register on a Source object" should "start the source").taggedAs(
    Config
  ) in {

    val source = com.bosch.asc.vasapi.conf.Source(
      name = "sourceConfigTest",
      format = "rate",
      serialization = None,
      ddlSchema = None,
      jsonSchemaFile = None,
      avroSchemaFile = None,
      load = None,
      options = Some(
        Map("rowsPerSecond" -> "5", "rampUpTime" -> "4", "numPartitions" -> "3")
      ),
      credentialOptions = None
    )

    source.register(spark)

    val sourceSchema = spark.sql("select * from sourceConfigTest").schema
    assert(
      sourceSchema.head.name == "timestamp" && sourceSchema(1).name == "value"
    )
  }

  ("Calling register on a View object" should "create a temporary view")
    .taggedAs(Config) in {

    val view = com.bosch.asc.vasapi.conf.View(
      "select 42 as `answer`",
      "viewConfigTest",
      None
    )

    view.register(spark)

    assert(spark.sql("select * from viewConfigTest").take(1)(0)(0) == 42)
  }

  ("Calling register on a Sink object" should "start a streaming sink if execution mode is omitted")
    .taggedAs(Config) in {
    val sink = com.bosch.asc.vasapi.conf.Sink(
      sql = "",
      coalesce = None,
      format = "dummyFormat",
      outputMode = None,
      logPath = None,
      dataBaseName = None,
      tableName = None,
      partitionBy = None,
      executionMode = None,
      trigger = None,
      sparkListener = None,
      options = None,
      credentialOptions = None
    )
    // do not mock object under test, instead create a spy on it
    val sinkSpy = MockitoSugar.spy(sink)

    // SparkSession can be mocked
    val sparkSessionMock = MockitoSugar.mock[SparkSession]

    // make sure startBatchSinks isn't doing anything once called (we do not want to actually write)
    doNothing().when(sinkSpy).startStreamingSinks(sparkSessionMock)

    // call method under test
    sinkSpy.register(sparkSessionMock)

    // verify method calls on spy object
    verify(sinkSpy, times(0)).startBatchSinks(sparkSessionMock)
    verify(sinkSpy, times(1)).startStreamingSinks(sparkSessionMock)
  }

  (it should "do the same if executionMode is set to stream").taggedAs(
    Config
  ) in {
    val sink = com.bosch.asc.vasapi.conf.Sink(
      sql = "",
      coalesce = None,
      format = "dummyFormat",
      outputMode = None,
      logPath = None,
      dataBaseName = None,
      tableName = None,
      partitionBy = None,
      executionMode = Some("stream"),
      trigger = None,
      sparkListener = None,
      options = None,
      credentialOptions = None
    )
    // do not mock object under test, instead create a spy on it
    val sinkSpy = MockitoSugar.spy(sink)

    // SparkSession can be mocked
    val sparkSessionMock = MockitoSugar.mock[SparkSession]

    // make sure startBatchSinks isn't doing anything once called (we do not want to actually write)
    doNothing().when(sinkSpy).startStreamingSinks(sparkSessionMock)

    // call method under test
    sinkSpy.register(sparkSessionMock)

    // verify method calls on spy object
    verify(sinkSpy, times(0)).startBatchSinks(sparkSessionMock)
    verify(sinkSpy, times(1)).startStreamingSinks(sparkSessionMock)
  }

  (it should "try to start a stream sink if execution mode is None") in {
    val sink = com.bosch.asc.vasapi.conf.Sink(
      sql = "",
      coalesce = None,
      format = "s3",
      outputMode = None,
      logPath = None,
      dataBaseName = None,
      tableName = None,
      partitionBy = None,
      executionMode = Some("batch"),
      trigger = None,
      sparkListener = None,
      options = None,
      credentialOptions = None
    )
    // do not mock object under test, instead create a spy on it
    val sinkSpy = MockitoSugar.spy(sink)

    // SparkSession can be mocked
    val sparkSessionMock = MockitoSugar.mock[SparkSession]

    // make sure startBatchSinks isn't doing anything once called (we do not want to actually write)
    doNothing().when(sinkSpy).startBatchSinks(sparkSessionMock)

    // call method under test
    sinkSpy.register(sparkSessionMock)

    // verify method calls on spy object
    verify(sinkSpy, times(1)).startBatchSinks(sparkSessionMock)
    verify(sinkSpy, times(0)).startStreamingSinks(sparkSessionMock)
  }

  (it should "throw an error for execution mode other than batch / stream / None") in {
    val sink = com.bosch.asc.vasapi.conf.Sink(
      sql = "",
      coalesce = None,
      format = "s3",
      outputMode = None,
      logPath = None,
      dataBaseName = None,
      tableName = None,
      partitionBy = None,
      executionMode = Some("doesNotExist"),
      trigger = None,
      sparkListener = None,
      options = None,
      credentialOptions = None
    )
    // do not mock object under test, instead create a spy on it
    val sinkSpy = MockitoSugar.spy(sink)

    // SparkSession can be mocked
    val sparkSessionMock = MockitoSugar.mock[SparkSession]

    // make sure the error is thrown
    assertThrows[IllegalArgumentException](sinkSpy.register(sparkSessionMock))
  }
}
