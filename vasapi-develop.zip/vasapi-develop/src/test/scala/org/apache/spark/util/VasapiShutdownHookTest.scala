/*
 * Copyright (c) 2009, 2018 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */
package org.apache.spark.util

import org.scalatest.flatspec.AnyFlatSpec
import org.scalamock.scalatest.MockFactory

/** VasapiShutdownHook tests.
  */

class VasapiShutdownHookTest extends AnyFlatSpec with MockFactory {}
