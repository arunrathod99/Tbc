/*
 * Copyright (c) 2009, 2018 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */

package org.apache.spark.sql.streaming

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.internal.SQLConf

class MockableStreamingQueryManager
    extends StreamingQueryManager(
      SparkSession
        .builder()
        .appName("MockableStreamingQueryManagerSparkSession")
        .master("local")
        .getOrCreate(),
      new SQLConf
    )
