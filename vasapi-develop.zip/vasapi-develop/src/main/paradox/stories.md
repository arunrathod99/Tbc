# User Stories & Examples

This page gives an overview over common user stories for vasapi based pipelines.
Take a look at the subchapters for various examples on how to interact with sources, sinks and transform data in between.

:white_check_mark: most of the sources, transformations and sinks can be freely combined so you are not restricted
to only the flows described on this page. These merely give an idea on possible use cases

:white_check_mark: you are not restricted to one source and sink per pipeline. In fact, pipelines
often combine data from multiple sources, join it and write to one or multiple sinks.


## Rate console

Let us start with generating sample data to understand how a typical vasapi streaming application looks like.
For that, we can use the [rate source](https://spark.apache.org/docs/latest/structured-streaming-programming-guide.html#input-sources) type of Spark Structured Streaming.
A rate source generates streaming data, i.e. new records with the columns "timestamp" and "value".
A newly added record gets the timestamp when it has been generated and a series number as value.
We can specify the number of records generated per second, a ramp up time, as well as the number of partitions to which the generated data should be distributed on the cluster:

```HOCON
{
type: "source",
name: "rateSource",
format: "rate",
options: {
	rowsPerSecond: "10",
	rampUpTime: "0",
	numPartitions: "5"
	}
}
```

Now we want to add a third column to the view "rateSource", that is a hash string of the timestamp, and output everything on the console.
This should be done every 5 seconds, and only appended records should be shown. The output of every interval is limited to 20 records, and we don't truncate the content of a record.
Note how we reference the name of source (```rateSource```) in the sink's sql statement:

```HOCON
{
type: "sink",
sql: "select *, uuidFromString(cast(timestamp as string)) as timestamp_hash from rateSource"
format: "console",
output-mode: "append",
trigger: { type: "processingtime", interval: "5 seconds" },
options: {
    numRows: "20",
    truncate: "false"
    }
}
```


Because we are using a user defined function "uuidFromString" in order to determine the hashed timestamp, we have to define it:

```HOCON
uuidFromString : "(s: String) => java.util.UUID.nameUUIDFromBytes(s.getBytes).toString"
```

<br/><br/>

> **_NOTE:_**
> we will likely retire the possibility to register udfs at runtime like shown in the example above in future releases.
> The reason is that making a piece of runnable code out of such a function string is not trivial.
> Also, the resulting functions cannot be tested at compile time.


Putting everything together, we get the following (complete) configuration:

```HOCON
udfs: {
	uuidFromString : "(s: String) => java.util.UUID.nameUUIDFromBytes(s.getBytes).toString"
}

queries: [
{
type: "source",
name: "rateSource",
format: "rate",
options: {
	rowsPerSecond: "10",
	rampUpTime: "0",
	numPartitions: "5"
	}
}

{
type: "sink",
sql: "select *, uuidFromString(cast(timestamp as string)) as timestamp_hash from rateSource"
format: "console",
output-mode: "append",
trigger: { type: "processingtime", interval: "5 seconds" },
	options: {
	numRows: "20",
	truncate: "false"
	}
}
]
```

<br/><br/>

This will output something similar to the following every 5 seconds:

```
-------------------------------------------
Batch: 1
-------------------------------------------
19/03/29  11:40:58 INFO codegen.CodeGenerator: Code generated in 9.981719 ms
+-----------------------+-----+------------------------------------+
|timestamp |value|timestamp_hash |
+-----------------------+-----+------------------------------------+
|2019-03-29  11:40:53.274|0 |ce263565-eb72-3095-877b-646a4a51e3a9|
|2019-03-29  11:40:53.374|1 |e00af5be-7abc-3303-ad9b-1bfc420f451a|
|2019-03-29  11:40:53.474|2 |a5fb483d-773f-33c3-a1ac-e61c31a2c8de|
|2019-03-29  11:40:53.574|3 |52e2c22f-1359-356e-9aba-24a4486ae162|
|2019-03-29  11:40:53.674|4 |f6e81c93-5d9f-3af8-aa43-65c6f7e1937b|
|2019-03-29  11:40:53.774|5 |4b35dcd6-57a3-35ba-83d1-5f1b87133771|
|2019-03-29  11:40:53.874|6 |3c4061df-c000-3f4f-89ec-bf638ab88851|
|2019-03-29  11:40:53.974|7 |e8245c9e-f85d-3d30-bdc9-65f4e2e0a9ae|
|2019-03-29  11:40:54.074|8 |46afc100-6cbf-3dd8-b5ae-4180d2ecd110|
|2019-03-29  11:40:54.174|9 |79b334e7-7e3c-3569-9731-a622e89b83dc|
+-----------------------+-----+------------------------------------+
```

## Consume data from Solace and write parquets to HDFS

Let us assume that we want to consume data from the topic "machine/1/data" available at the Solace instance "solace123.de.bosch.com".

We would like to set up a durable subscription, i.e. the Solace instance will buffer all messages on this topic, if the connection to your application is lost, until the application reconnects to Solace. So Solace needs to know, which application is connecting.
This is defined by the client id, which we set to "vasapi_app_1". Of course, the client id needs to be unique, so no more than one application with the same client id is allowed to run at the same time.  
By default, the Solace buffer for durable connections are limited to 1.5 GB.

Furthermore, we need to define a replay directory. The Solace source buffers messages, so they can be replayed, if the Spark Streams engine wants the Solace source to. This is part of the fault tolerance mechanism of Spark Structured Streaming. We define it to be located at "/proc/machine/vasapi/machineSource/source_replay".  
Another part of the fault tolerance mechanism are the write-ahead logs, which are located within a checkpoint location. We specify this to be "/proc/machine/vasapi/machineSource/source_checkpoint".

We do not unsubscribe from the durable connection on exit of the application (option "unsubscribeOnExit"). This is useful, e.g. if we want to update the application without loosing or duplicating data.

If the JNDI entry for the topic does not exist yet, we will create it (option "createTopic").

We need to authenticate our application at the Solace instance and are using the username "vasapi_user" and the password "vasapi_pass" for this.

We define the following Solace source in our configuration for this:

```HOCON
{
  type: "source",
  name: "machineSource",
  format: "solace_source",
  options: {
    clientId: "vasapi_app_1",
    username: "vasapi_user",
    jceksPath: "jceks:///user/user_name/vasapi/jceksFile.jceks",
    passwordAlias: "Aliasname.password",
    vpn: "default",
    host: "smf://solace123.de.bosch.com:55555",
    channel: "machine/1/data",
    replayDir: "/proc/machine/vasapi/machineSource/source_replay",
    checkpointLocation: "/proc/machine/vasapi/machineSource/source_checkpoint",
    durable: "machineSource",
    unsubscribeOnExit: "false",
    createTopic: "true"
  }
}
```

The source "machineSource" will provide us a record with a timestamp and the content as a string for every message received. "jceksPath" and "passwordAlias" are to protect the password.
It is recommended to use password not directly but using Jceks Path.

We know that we are receiving JSON objects and presume a fixed schema of the type (\`eventHeader\` STRUCT&lt;\`eventId\`: STRING, \`eventTimestamp\`: STRING&gt;, \`process\` STRUCT&lt;\`stationNo\`: BIGINT, \`productId\`: BIGINT&gt;).  
So we define a view "machineSourceJson" in the configuration, which will parse the JSON objects accordingly:

```HOCON
{
  type: "view",
  name: "machineSourceJson",
  sql: """SELECT
           parsed.* 
       FROM
        (select from_json(cast(content as string),
         'eventHeader STRUCT<eventId: STRING,
          eventTimestamp: STRING>,
          process STRUCT<stationNo: BIGINT,
          productId: BIGINT>'
         ) as parsed from machineSource)"""
}
```

Now we want to write new data received onto HDFS as parquet files, every 10 minutes, into the location "/proc/machine/vasapi/machineSink/parquet_output". Data should be gathered by one executor and written into one file per partition and writing interval (option "coalesce").  
We want to partition the data with respect to the day specified within the field "eventTimestamp". For this, we will define a field "partition_key_event_date" by casting "eventTimestamp" to type "date".  
The data in the parquet files will be loaded as an external Hive/Impala table "proc_machine.machine_one" by creating the table as follows using "init":

```HOCON
{
 inits: [
         {
           type: "external-hive-table"
           name: proc_machine.machine_one
           drop-table: true
           ddl-schema: "eventHeader STRUCT<eventId: STRING, eventTimestamp: STRING>, process STRUCT<stationNo: BIGINT, productId: BIGINT>"
           json-schema: "./schema.json"
           partition-by: ["partition_key_event_date"]
           stored-as: "parquet"
           location: "/proc/machine/vasapi/machineSink/parquet_output"
         }
       ]
}
```

We want to ensure that a new partition is visible by calling the SQL command ```alter table proc_machine.machine_one recover partitions``` after parquet files got written onto HDFS.
It should be noted that type "init" must be written before type "source".
So we define the following sink in the configuration:

```HOCON
{
  type: "sink",
  sql: "select *, cast(eventHeader.eventTimestamp as date) as partition_key_event_date from machineSourceJson",
  coalesce: 1,
  format: "parquet",
  output-mode: "append",
  partition-by: ["partition_key_event_date"],
  trigger: {
    type: "processingtime",
    interval: "10 minutes"
  },
  spark-listener: [
    {
      type: "progress-sql-statement",
      sql: "alter table proc_machine.machine_one recover partitions"
    }
  ],
  options: {
    checkpointLocation: "/proc/machine/vasapi/machineSink/sink_checkpoint",
    path: "/proc/machine/vasapi/machineSink/parquet_output"
  }
}
```

### Define a schema for a source, especially a Solace source

You may also define a json schema to use on a streaming source by defining the parameter "json-schema-file".
This is especially useful specifying this parameter on a "solace_source": If you do so, any json message received by the Solace source will get parsed with the schema defined:

```HOCON
{
  type: "source",
  name: "machineSource",
  format: "solace_source",
  json-schema-file: "machineSource.schema.json",
  options: {
    clientId: "vasapi_app_1",
    username: "vasapi_user",
    jceksPath: "jceks:///user/user_name/vasapi/jceksFile.jceks",
    passwordAlias: "Aliasname.password",
    vpn: "default",
    host: "smf://solace123.de.bosch.com:55555",
    channel: "machine/1/data",
    replayDir: "/proc/machine/vasapi/machineSource/source_replay",
    checkpointLocation: "/proc/machine/vasapi/machineSource/source_checkpoint",
    durable: "machineSource",
    unsubscribeOnExit: "false",
    createTopic: "true"
  }
}
```

Alternatively, you may specify a DDL schema for your source by using the "source" option.
Messages consumed from the source will be parsed into this schema. You can achieve the same by defining a subsequent view as shown above.

**Note** that when specifying both json and ddl schema, the json schema takes precedence.

### VASAPI reconnection with Solace Queue after Queue deactivation

Upon deactivation of the Queue, the consumer promptly disconnects from Solace.
However, it is noteworthy that the VASAPI job persists and continues to operate.
Subsequently, when the queue is re-enabled, the consumer's connection to Solace is automatically re-established without necessitating a restart of the VASAPI job.

### VASAPI to be able to reconnect to Solace

Occasionally, frequent disconnections between Vasapi and the Solace consumer are observed. This can be mitigated by using ```defaultConnectionFactoryVasapiWindowsSizeOne```
as the SOLACE_CONNECTION_FACTORY within the VASAPI job.

## Read data from HDFS and publish onto Solace

We want to consume files from the HDFS folder "witches/input". For consuming files we can specify "text", "csv", "json", "orc", "parquet" as a source format. Let's choose "text".  
We want to consume not more than 10 files per trigger, i.e. micro batch interval (option "maxFilesPerTrigger"). So we define the following source in our configuration:

```HOCON
{
  type: "source",
  name: "fileSource",
  format: "text",
  options: {
    maxFilesPerTrigger: 10
  },
  load: "witches/input"
}
```

Now, we want to publish the content of every new file received onto the topic "witches/output" to Solace. Along, we write a timestamp when the file was processed by vasapi.
Processing should start as soon as new data arrives in HDFS (interval "0 second"). So we define the following sink in our configuration:

```HOCON
{
  type: "sink",
  sql: "select to_json(struct(current_timestamp() as `timestamp`, value as `content`)) from fileSource",
  format: "solace_sink",
  trigger: {
    type: "processingtime",
    interval: "0 second"
  },
  options: {
    username: "vasapi_user",
    jceksPath: "jceks:///user/user_name/vasapi/jceksFile.jceks",
    passwordAlias: "Aliasname.password",
    vpn: "default",
    host: "smf://si0vm02909.de.bosch.com:55555",
    channel: "witches/output",
    checkpointLocation: "witches/checkpoint"
  }
}
```

When we put the source and sink configuration together and run it, we might listen to the topic "witches/output" and get something like the following:

```
{
  "timestamp": "2019-04-17T13:34:51.780+02:00",
  "content": "When shall we three meet again? In thunder, lightning, or in rain?"
}
{
  "timestamp": "2019-04-17T13:35:08.598+02:00",
  "content": "When the hurlyburly's done, When the battle's lost and won."
}
{
  "timestamp": "2019-04-17T13:37:57.821+02:00",
  "content": "That will be ere the set of sun."
}
```
<br>

## Consume data from Kafka

We can also consume data from Kafka broker(s). Spark has a native interface to Kafka in both, its batch and streaming APIs.
While it's usually best to use the Spark Structured Streaming API, there may be some special use cases where you may want to read some reference data from a Kafka topic
in batch mode and then use this data within your streaming application (e.g. for a batch / stream join).

### Consume a data stream from Kafka

The below code snippet shows an example for how to consume data from a defined Kafka topic via Spark's built-in Kafka interface.

Note that authentication / authorization works using SSL (certificates) in this case. User-based Kerberos authentication is also supported. You can find an example for this [here](https://inside-docupedia.bosch.com/confluence/display/AEProjectHouseDesignTest/Kerberos+Authentication).

Keystore and truststore need to provided via Spark submit in this case. Since the keystore is usually password encrypted, you can also provide the path to a jceks file (in hfds) which holds your encrypted password.

```HOCON
{
  type: "source",
  name: "vasapi_datapublisher_partdetails_source",
  format: "kafka",
  options: {
    "jceksPath": "jceks:///user/user_name/vasapi/jceksFile.jceks",
    "passwordAlias": "Aliasname.password",
    "kafka.bootstrap.servers": "si0vm05626.de.bosch.com:9093",
    "kafka.security.protocol": "SSL",
    "kafka.ssl.keystore.location": "./rtp2_datapublisher_qualitydata_partdetails.ks",
    "kafka.ssl.truststore.location": "./Bosch-CA-bundle.ts",
    "failOnDataLoss": "false",
    "subscribe": "aertp2prod.push.datapublisher-qualitydata-partdetails.joined-unpivoted",
    "includeHeaders": "true",
    "startingOffsets": "latest"
  }
}
```

### Consume a static batch from Kafka

This feature should only be used in cases where you do not want to read from Kafka via Spark Structured Streaming due to some special requirements.
In this case, simply swap the format from "kafka" to "kafkaBatch". The result will then be a static view, which you can join against any other vasapi (streaming) views.
Writing a batch df to a sink is not supported.


### Impact of shutdown on VASAPI pipeline for Kafka source

When using both "latest" and "earliest" startingOffsets options in VASAPI application without clearing checkpoint and spark metadata,
Spark's fault tolerance mechanism ensures data processing resumes from the last committed offset without generating duplicates or losing records.
Note that this only works if checkpoint and spark metadata are not cleared.

<br>

## Interacting with Hive / Impala tables

Vasapi can work with Hive / Impala tables in multiple ways. Note that Spark's Structured Streaming API cannot use
Hive / Impala tables as sources or sinks directly.
Instead, we can:
* write to HDFS and define Hive external table on top, see [here](#work-with-hive-external-tables)
* use Spark's batch API instead of structured streaming, see [here](#read-from-hive-tables) for reading & [here](#append--overwrite-data-in-hive-table-using-insertinto-functionality) for writing
* use Spark's forEachBatch API to write a stream to a Hive table, see [here](#write-streaming-data-to-hive-table)


> **_NOTE:_**
> When working with tables, consider using Iceberg tables (see [below](#read-data-from-kafka-and-write-to-apache-iceberg-tables))
> which support both stream reads and writes. They are a better alternative to classic Hive tables.

### Work with Hive external tables

#### Initialize an external Hive table

Let us assume have written parquet files to a (hdfs) file sink. Now we want to make this data accessible to users via a table.
In order to do so, we need to create an external table in the hive metastore (which can then be accessed by Hive and Impala).
You can create such a table directly from within vasapi, by using an "external-hive-table" entry in the "inits" block of your Vasapi configuration:

```HOCON
udfs: {  }
inits: [
  {
    type: "external-hive-table"
    name: "proc_my_vasapi.my_external_table"
    drop-table: true
    json-schema-file: "my_external_table_json_schema.json"
    ddl-schema: "datepartoftimestamp STRING"
    partition-by: ["plant", "datepartoftimestamp"]
    comment: My external table
    stored-as: parquet
    location: /proc/my_vasapi/my_external_table
  }
]
queries: [ ... ]
```

About the parameters:

* name: The name of the table, including any database prefix.
* drop-table: Set to true to drop any table with the same name before creating the new one. If set to false, no new table will get created.
* json-schema-file: A schema using a json schema file. Will be merged with any DDL schema given.
* ddl-schema: A schema using DDL syntax. Will be merged with any json schema given. If duplicate columns are present, json schema takes precedence.
* partition-by: The partition keys to use. Any partition key used here must be present in the schema.
* comment: A comment.
* stored-as: The file container format to store the table in.
* location: The location on HDFS to store the data.

Since version 2.0.0, vasapi uses json representations of Spark schemas for schema definitions (instead of full jsons compatible with the json schema definition).
The reason is that the latter contains many features that are not supported in Spark. A spark-compatible, admissible example looks like this:

```json
{
  "type": "struct",
  "fields": [
    {
      "name": "name",
      "type": "string",
      "nullable": false
    },
    {
      "name": "age",
      "type": "integer",
      "nullable": false
    },
    {
      "name": "college",
      "type": "string",
      "nullable": false
    }
  ]
}
```

#### Recover Hive Table Partitions

When writing data for partitioned Hive tables from outside Hive (like we do in Vasapi where we write from Spark),
it is necessary to tell the Hive warehouse / metastore when a new partition has been created.
This can be done in vasapi by adding a spark-listener that executes an ```alter table ... recover partitions``` command.

See the example below for how such a listener can be added to a sink in the configuration:

```HOCON
{
type: "sink",
sql: "select *, substring(PressInJson.header_test_datetime,0,10) as header_test_date from PressInJson",
format: "parquet",
coalesce: 1,
partition-by: ["header_test_date"],
trigger: {
    type: "processingtime",
    interval: "5 minutes"
},

spark-listener: [
{
    type: "progress-sql-statement",
    sql: "alter table proc_pressin.test_refresh recover partitions"
}
],

options: {
    checkpointLocation: "proc/pressIn/vasapi/sink_pressIn_testMerger_test",
    path: "/data/proc/pressin/test_refresh/res_testMerger_test",
    compression: "snappy",
    numRows: "2",
    truncate: "false"
    }
}
```

**Notes**:
- only required for partitioned tables. For non-partitioned tables, simply omit the spark-listener section
- the listener is executed for every micro batch (meaning after each trigger interval).


### Read from Hive tables

To read from existing Hive (external) tables, you can:
  * use a Hive table as static reference data for a stream / static join [Join with static data](#join-with-static-data)
  * you can directly use hive tables as a [hive batch source](#use-hive-table-as-source)

<br>

#### Join with static data

> **_NOTE:_**
> You can directly use any Hive / Impala / Iceberg table in your vasapi queries.

We want to classify the values generated by the Rate console example above according to their parity.
Let us assume that we already have a table available, mapping the integers 0 to 3 to their parity (odd or even).
The table is available as `proc_vasapi.modParityMap` and has two columns: `mod4 BIGINT, parity STRING`.
We can join our rate source against this static table by simply referring to its name.

```HOCON
udfs: {
  uuid: "(s: String) => java.util.UUID.nameUUIDFromBytes(s.getBytes).toString"
}
queries: [
  {
    type: "source",
    name: "rateSource",
    format: "rate",
    options: {
      rowsPerSecond: "1",
      rampUpTime: "0",
      numPartitions: "5"
    }
  },
  {
    type: "table",
    name: "modParityMap",
    rows: [
      "0,even",
      "1,odd",
      "2,even",
      "3,odd"
    ],
    schema: "mod4 BIGINT, parity STRING"
  },
  {
    type: "sink",
    sql: "select *, uuid(cast(timestamp as string)) as timestamp_hash from rateSource join proc_vasapi.modParityMap on (mod(rateSource.value,4) = modParityMap.mod4)",
    format: "console",
    output-mode: "append",
    trigger: {
      type: "processingtime",
      interval: "10 seconds"
    },
    options: {
      numRows: "20",
      truncate: "false"
    }
  }
]
```

If we run this, the output should look as follows:

```
+-----------------------+-----+----+------+------------------------------------+
|timestamp              |value|mod4|parity|timestamp_hash                      |
+-----------------------+-----+----+------+------------------------------------+
|2019-05-07 13:27:03.171|0    |0   |even  |8eff1781-3c47-30ec-afd6-70e22520652e|
|2019-05-07 13:27:07.171|4    |0   |even  |d4ec1ac6-205c-3e2d-850c-f7467a6abeea|
|2019-05-07 13:27:08.171|5    |1   |odd   |76dc7f7b-45f6-32ca-93f1-01ec90f1c31e|
|2019-05-07 13:27:04.171|1    |1   |odd   |0ca80dc6-f1db-30de-a656-6e2fd5005599|
|2019-05-07 13:27:06.171|3    |3   |odd   |758f017f-9698-3ae8-b83b-87ae326af253|
|2019-05-07 13:27:05.171|2    |2   |even  |48f183bc-3884-39e0-a361-f03e8e07ea9f|
+-----------------------+-----+----+------+------------------------------------+
```

<br>

#### Use Hive table as source

Unlike other vasapi view's, this can be used only in combination with batch sinks.
Hence, this view cannot be freely combined with any sinks (yet).

```HOCON
{
    type: "view",
    sql: """ select * from proc_mws.mws_xml"""
}
```

> **_NOTE:_**
> this works only in combination with a batch sink ([S3](#write-data-to-an-s3-sink)
> or [Hive Batch](#append--overwrite-data-in-hive-table-using-insertinto-functionality)).\
> When working with tables, consider using Iceberg tables (see [below](#read-data-from-kafka-and-write-to-apache-iceberg-tables)) 
> which support both stream reads and writes. They are a better alternative to classic Hive tables.


### Write to Hive tables

You have two options to write to Hive tables:
  * dynamic partition overwrite using [insertInto](#append--overwrite-data-in-hive-table-using-insertinto-functionality)
  * use [hive tables as streaming sinks](#write-streaming-data-to-hive-table)


#### Append / overwrite data in hive table using InsertInto functionality

Checkout the @ref:[sinks](sinks.md) section on how to write a batch dataframe into an Hive table.


#### Write streaming data to Hive table

* writes streaming data to hive table by using foreachBatch method in write logic. Ensures that each micro-batch of streaming data is processed and written into the Hive table, allowing for real-time data integration into Hive for further analysis and querying.
* It accepts optional parameters for additional options, database name, table name, and partition columns. Inside the function, if a path is specified in the options, the data is written to that path; otherwise, it defaults to writing without a path. It supports partitioning if specified. If both the database and table names are provided, the data is saved to the Hive table in append mode using the Parquet format.

```HOCON
{
    type: "sink",
    sql: """ select * from temp_view""",
    format: "hive",
    output-mode: "append",
    partition-by: "result_date",
    trigger: {
        type: "processingtime",
        interval: "1 minute"
    },
    execution-mode: "stream",
    data-base-name: "proc_mes_qdata",
    table-name: "testing_vasapi",
    options: {
        checkpointLocation: "/proc/mes_qdata/sink/chk/"
    }
}

```
## Apache Iceberg

[Apache Iceberg](https://iceberg.apache.org/) is an open source table format and offers significant advantages over plain Hive tables. Take a look at the docs for more information and features.
As with any supported data source / sink in Spark, Vasapi also supports reading from and writing to Iceberg tables. It is worth noting that unlike Hive tables, Iceberg tables support the Spark Structured Streaming API directly, so we can use such tables as streaming sources and sinks without resorting to Spark's batch API.
Before writing into an Iceberg table, you first need to initialize it.

#### Initialize an Iceberg table

Let us assume we have written parquet files to an Iceberg sink, Now this cannot be done without an Iceberg table in place.
This table can then be accessed by Impala or a Spark-session.
You can create such a table directly from within Vasapi, by using an "iceberg-table" entry in the "inits" block of your Vasapi configuration:

```HOCON
inits: [
  {
    type: "iceberg-table"
    name: "proc_my_vasapi.my_external_table"
    json-schema-file: "my_external_table_json_schema.json"
    ddl-schema: "datepartoftimestamp STRING"
    partition-by: ["plant", "datepartoftimestamp"]
    comment: My external table
    location: /proc/my_vasapi/my_external_table
  }
]
```

About the parameters:

* name: The name of the Iceberg table, including any database prefix.
* drop-table: Set to true to drop the table with same name before creating the new one. If set to false, no new table will get created.
* json-schema-file: A file containing a json representation of a spark schema. Will be merged with any DDL schema given. See @ref:[Initialize an external Hive table](#initialize-an-external-hive-table) for an example.
* ddl-schema: A schema using DDL syntax. Will be merged with any json schema given.
* partition-by: The partition keys to use. Any partition key used here must be present in the schema.
* comment: A comment.
* location(optional): The location on HDFS to store the Iceberg table data, this parameter can always be skipped as the default path would be /<ROLE_TYPE_NAME>/<ROLE_NAME>/db/<table_name>

#### Read data from Kafka and write to Apache Iceberg tables

Checkout the @ref:[sinks](sinks.md) section on how to write a streaming dataframe into an iceberg table.

## Write data to an S3 sink

Checkout the @ref:[sinks](sinks.md) section on how to write a batch dataframe into an S3 compatible object store.