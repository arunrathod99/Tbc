# Sources

Sources are the entry points of a pipeline. They are responsible for reading data from an external system and providing it to the pipeline for further processing.
Vasapi supports a variety of sources, such as file sources (e.g. Parquet), Solace, and Kafka.

## Common Properties

All sources take a common set of properties (listed below). Most of them are optional. The examples in the sections further below
show how to use them in a source configuration.

| Attribute          | Description                                                                                                                                                                                                                                              |
|:-------------------|:---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| name               | String to name the source. Use to consume data from this source later, e.g. `SELECT * FROM mySource`                                                                                                                                                     |
| format             | source format. Can be e.g. `kafka`, `kafkaBatch`, `solace_source`, `parquet`, `rate` etc.                                                                                                                                                                |
| serialization      | (optional) only relevant for kafka sources. See further down under [Kafka](#kafka-source)                                                                                                                                                                |
| ddl-schema         | (optional) schema for this source, expressed as Spark DDL string, e.g. `"eventId STRING, eventName STRING, Zipcode STRING, mesLineNo INT"`                                                                                                               |
| json-schema-file   | (optional) locator (path or classpath resource) for source schema, expressed as json representation of spark schema, see [Spark API docs](https://tinyurl.com/46h4nj3n). Note that spark json schemas do not support the full json schema specification. |
| avro-schema-file   | (optional) locator (path or classpath resource) for source schema, expressed as avro schema                                                                                                                                                              |
| load               | (optional) source path for file-based sources                                                                                                                                                                                                            |
| options            | (optional) a Map[String, String] containing further configuration options passed to the source                                                                                                                                                           |
| credential-options | (optional) a Map[String, String] containing credential-related options. See details in [Credential handling](#credential-handling).                                                                                                                      |

Since version 2.0.0, vasapi uses json representations of Spark schemas for schema definitions when passed via the `json-schema-file` parameter (instead of full jsons compatible with the json schema definition).
The reason is that the latter contains many features that are not supported in Spark. A spark-compatible, admissible example looks like this:

```json
{
  "type": "struct",
  "fields": [
    {
      "name": "name",
      "type": "string",
      "nullable": false
    },
    {
      "name": "age",
      "type": "integer",
      "nullable": false
    },
    {
      "name": "college",
      "type": "string",
      "nullable": false
    }
  ]
}
```

### Credential Handling

Some sources require authentication / authorization of some kind. In order to avoid passing plaintext credentials in configuration files,
vasapi supports multiple ways of passing credentials.

#### Environment Variables

Credentials can be passed as environment variables. Consider the following HOCON snippet:

   ```HOCON
   {
     my_secret: ${MY_SECRET},
     another_secret = ${MY_OTHER_SECRET}
   }
   ```

The HOCON specification falls back to environment variables if variables cannot be resolved through configuration file(s) directly.
You can make use of this mechanism to pass credentials to vasapi. When submitting the application, you inject the respective variables
as environment variables using the spark-submit `spark.executorEnv.[EnvironmentVariableName]` and `spark.yarn.appMasterEnv.[EnvironmentVariableName]`
under the `--conf` option.

This can e.g. be used from an external scheduler like Apache Airflow that stores secrets in its own secret backend (or uses yet another secret backend).
It can then pass the respective environment variables to the spark-submit command. Spark also has configuration options that allow you to redact
sensitive information from the logs.

When using this way of passing credentials to your Source, simply add them under the options section with the respective key-value pairs. E.g.:

```HOCON
{
  type: "source",
  name: "exampleSource",
  format: "solace_source",
  options: {
    username: "vasapi_user",
    password: "${MY_SECRET}"
  }
}
```

<br>

#### JCEKS Files

You can store encrypted credentials using the [Hadoop CredentialProvider API](https://tinyurl.com/bdz89a6t).
This API supports storing credentials in encrypted JCEKS file in different locations (e.g. HDFS, local file system, Azure ADLS etc.).
Vasapi can retrieve credentials from a JCEKS file stored in HDFS. This mechanism works when running vasapi on a Hadoop cluster with access to HDFS.
    
The JCEKS file can be passed as a configuration option to the source.
It is expected to be located in HDFS and the path should be prefixed with `jceks://`. Note that the JCEKS file has to be created upfront, using the
`hadoop credential` command line tool. For more information on how to create a JCEKS file, refer to the [Hadoop CredentialProvider API](https://tinyurl.com/bdz89a6t) documentation.

The following example shows how to make use of this mechanism:

1. Create a JCEKS file with the password `mySecret` and store it in HDFS under `/path/to/my/secret`:
2. Pass the JCEKS file path and the alias of the password to the source configuration in a `credential-options` section to your source configuration.

```HOCON
{
    type: "source",
    name: "exampleSource",
    format: "solace_source",
      options :{
        username: "vasapi_user"
      } 
      credential-options: {
        password: {
          credential-type = "jceks"
          path = "jceks:///path/to/my/secret"
          alias = "myAlias"
        }
      }
}
```

3. Vasapi takes care of decrypting the password and convert the config at runtime into:

```HOCON
   {
     type: "source",
     name: "exampleSource",
     format: "solace_source",
     options: {
       username: "vasapi_user"
       password: "secret-decrypted-password"
     }
   }
```

Note that this example just serves as an illustration. The plaintext password will not be visible or stored anywhere since this conversion happens only at runtime.
It is also worth noting that vasapi converts the pair of `jceksPath` & `passwordAlias` properties into a source specific property.
The example shown above works for a Solace source. Kafka e.g. will be handled differently (see example further below).

<br>

#### Databricks Secret Scopes

> **_NOTE:_**
> Since version 2.0.0; only available when running vasapi on Databricks platform.

When running on the Databricks platform, vasapi supports the usage of [Databricks Secret Scopes](https://learn.microsoft.com/en-us/azure/databricks/security/secrets/secret-scopes)
to store and retrieve secrets. Vasapi makes use of the [databricks-dbutils-scala](https://github.com/databricks/databricks-dbutils-scala) library to achieve this.

Similar to the previous section, add the secret to a `credential-options` section as shown in the following snippet:

```HOCON
{
    type: "source",
    name: "exampleSource",
    format: "kafka",
      options :{
        username: "vasapi_user"
      } 
      credential-options: {
        myPassword: {
          credential-type = "databricks-secret"
          secret-scope: "my-secret-scope",
          secret-key: "my-very-secret key"
        }
    }
}
```

Vasapi will attempt to retrieve the secret from the Databricks secret scope and convert the configuration at runtime into:

```HOCON
   {
     type: "source",
     name: "exampleSource",
     format: "kafka",
     options: {
       username: "vasapi_user"
       myPassword: "secret-decrypted-password"
     }
   }
```

Replace `myPassword` with the key / name of the option required for your source.

<br>

## Sources - configuration details

After taking a look at the common properties, let's dive into the specifics of each source.

### Rate Source

The [rate source](https://spark.apache.org/docs/latest/structured-streaming-programming-guide.html#input-sources) is a built-in source in Spark Structured Streaming.
It is useful for testing purposes, as it generates a stream of data at a specified rate.

Check the docs linked above for configuration options. A rate source configuration can look as follows:
```HOCON
{
    type: "source",
    name: "rateSource",
    format: "rate",
    options: {
        rowsPerSecond: "10",
        rampUpTime: "0",
        numPartitions: "5"
        }
}
```

### File Source

The [file source](https://spark.apache.org/docs/latest/structured-streaming-programming-guide.html#input-sources) is another one of Spark Structured Streaming's built-in sources.
It reads data from a file system, e.g. HDFS, S3, or the local file system. It comes with many configuration options (see the docs).
The Spark Structured Streaming engine takes care of tracking which files have been processed and which yet to be processed.
This makes it obsolete to manually track offsets, making this source a very convenient way to process files.

A simple configuration for a file source may look as follows:

```HOCON
{
    type: "source",
    name: "fileSource",
    format: "text",
    options: {
      maxFilesPerTrigger: 10
    },
    load: "witches/input"
}
```

The load parameter specifies the input path from which to load the files. The format parameter specifies the format of the files to be read.
<br>

### Solace Source

Vasapi supports reading from (and writing to) Solace topics / queues. Solace is a message broker that supports the publish-subscribe messaging pattern.
Since Spark does not support Solace out of the box, vasapi makes use of the [spark-streams-solace](https://github.boschdevcloud.com/bios-asc/spark-streams-solace)
library to connect to Solace.

A configuration for a Solace source may look as follows:

```HOCON
{
  type: "source",
  name: "machineSource",
  format: "solace_source",
  options: {
    clientId: "vasapi_app_1",
    username: "vasapi_user",
    vpn: "default",
    host: "smf://solace123.de.bosch.com:55555",
    channel: "machine/1/data",
    replayDir: "/proc/machine/vasapi/machineSource/source_replay",
    checkpointLocation: "/proc/machine/vasapi/machineSource/source_checkpoint",
    durable: "machineSource",
    unsubscribeOnExit: "false",
    createTopic: "true"
  }
  credential-options: {
    password: {
      credential-type = "jceks"
      path = "jceks:///user/user_name/vasapi/jceksFile.jceks"
      alias = "Aliasname.password"
    }
  }
}
```

This will create a Spark streaming source, reading from the Solace topic `machine/1/data`. Just like with any other source, you can use the `name` attribute to refer to this source in your queries.
You can find more information on the configuration options in the [spark-streams-solace](https://github.boschdevcloud.com/bios-asc/spark-streams-solace) documentation.

#### Solace Credential Handling

Check the example above for how to handle credentials for a Solace source (see [Credential Handling](#credential-handling)).

<br>

### Kafka Source

Kafka is one of Spark Structured Streaming's built-in sources (see [Spark API docs](https://spark.apache.org/docs/3.5.1/structured-streaming-kafka-integration.html)).
Vasapi makes use of this and adds some additional configuration options to the Kafka source.

A Kafka source may look as follows:

```HOCON
{
  type: "source",
  name: "myKafkaSource",
  format: "kafka",
  serialization: "json",
  json-schema-file: "test-schemas/json_test_schema.json"
  options: {
    kafka.bootstrap.servers: "kafka123.de.bosch.com:9092",
    subscribe: "machine.data.topic.raw",
    startingOffsets: "earliest",
    failOnDataLoss: "true"
  }
}
```

This will create a Spark streaming source, reading from the Kafka topic `machine.data.topic.raw`. In this example, the topic has no access control and is accessible to everyone.
In this example, we expect incoming data to be in json format. The schema for this data is defined in the file `test-schemas/json_test_schema.json`.

Note that the `serialization` attribute is only relevant for Kafka sources. It tells vasapi how to deserialize the data coming from Kafka.
Per default, Spark returns a `DataFrame` with 8 columns when reading data from Kafka (key, value, offset, partition, topic, timestamp, timestampType, headers).
See the documentation linked above for more details.

You can simply omit the `serialization` attribute if you want to use the default deserialization method.
This will return a `DataFrame` with the default columns and their data types as provided by Spark ([KafkaByteMessage](https://pages.github.boschdevcloud.com/bios-asc/vasapi/com/bosch/asc/vasapi/conf/sources/KafkaByteMessage.html)) in vasapi.

#### Reading JSON messages from Kafka
When using `json`, vasapi will (for added convenience) create a [KafkaStringMessage](https://pages.github.boschdevcloud.com/bios-asc/vasapi/com/bosch/asc/vasapi/conf/sources/KafkaStringMessage.html)
object vor each incoming message. This object already converts `key` & `value` into a `String` for convenience.

In addition, when specifying any of the schema options (see [Common Properties](#common-properties)), vasapi will automatically convert the incoming JSON messages into a `DataFrame` with the specified schema.
The schema will contain all basic fields (key, value, offset, ...) plus the fields specified in the schema file.
If Spark cannot parse the message usage the specified schema, it will add the entire record unparsed into a separate column called `corrupt_records`.
This way, you can still access the data and handle the corrupt records later on.

This feature uses Spark's [from_json](https://spark.apache.org/docs/latest/api/java/org/apache/spark/sql/functions.html#from_json-org.apache.spark.sql.Column-org.apache.spark.sql.Column-java.util.Map-) function under the hood.

#### Reading Avro messages from Kafka

You can also read Avro messages from Kafka. In this case, use `avro` for the serialization property and specify the `avro-schema-file` attribute in the source configuration.
Vasapi will make use of this schema to deserialize avro messages coming from kafka into a Dataframe. It will contain all fields of a [KafkaByteMessage](https://pages.github.boschdevcloud.com/bios-asc/vasapi/com/bosch/asc/vasapi/conf/sources/KafkaByteMessage.html)
plus all fields specified in the schema.
If parsing fails, the entire record will be added to a column called `corrupt_records`.


#### Kafka Credential Handling

Depending on the environment, Kafka topics can be either unrestricted, secured via SSL certificates, Kerberos (see [Credential Handling](#credential-handling)) or SASL plain (i.e. username & password).
You can use the credential handling mechanisms described in [Credential Handling](#credential-handling) to pass credentials to the Kafka source.

##### SSL Secured Kafka Topics
    
When using SSL secured Kafka topics, you need to pass the keystore and truststore locations to vasapi. Both have to be created upfront and the kafka topic
has to be configured so that clients using this certificate can connect to it.

Once this is done, configure your Kafka source like so (omitted properties except `options` for brevity):

```HOCON
{
  options: {
    kafka.bootstrap.servers: "kafka123.de.bosch.com:9092",
    subscribe: "machine.data.topic.raw",
    startingOffsets: "earliest",
    failOnDataLoss: "true",
    kafka.security.protocol: "SSL",
    kafka.ssl.keystore.location: "./my-keystore.ks",
    kafka.ssl.truststore.location: "./Bosch-CA-bundle.ts",
  }
  credential-options: {
    kafka.ssl.keystore.password: {
      credential-type = "jceks"
      path = "jceks:///user/user_name/vasapi/jceksFile.jceks"
      alias = "Aliasname.password"
    }
    kafka.ssl.key.password: {
      credential-type = "jceks"
      path = "jceks:///user/user_name/vasapi/jceksFile.jceks"
      alias = "Aliasname.password"
    }
  }
}
```

As explained above in [Credential Handling](#credential-handling), vasapi will take care of decrypting the passwords and converting the configuration at runtime into:

```HOCON
{
  options: {
    kafka.security.protocol: "SSL",
    kafka.ssl.keystore.location: "./my-keystore.ks",
    kafka.ssl.truststore.location: "./Bosch-CA-bundle.ts",
    kafka.ssl.keystore.password: "<decrypted pw from jceks file>",
    kafka.ssl.key.password: "<decrypted pw from jceks file>>"
  }
}
```

If you do not want to use the JCEKS mechanism (because you're using e.g. environment variables), you can also pass the keystore and truststore passwords directly.
Just use the configuration properties as shown above and pass the passwords as plain text or environment variables.

##### Kerberos Secured Kafka Topics

You can also connect to Kafka topics secured via Kerberos. In this case, you need to pass the following settings to vasapi:

```HOCON
{
    options: {
        kafka.security.protocol: "SASL_SSL",
        kafka.sasl.kerberos.service.name: "kafka",
        kafka.sasl.mechanism: "GSSAPI"
    }
}
```

In addition, you need a `jaas.conf` and a `krb5.conf` file. These files have to be created upfront and have to be passed to the spark-submit command.
Check our [internal documentation](https://inside-docupedia.bosch.com/confluence/display/AEProjectHouseDesignTest/Kerberos+Authentication) and
the [Spark docs](https://spark.apache.org/docs/latest/structured-streaming-kafka-integration.html) for more information on how to set up Kerberos authentication.


##### SASL Plain secured Kafka Topics

SASL/PLAIN is a simple username/password authentication mechanism. See details [here](https://docs.confluent.io/platform/current/security/authentication/sasl/plain/overview.html).
When using SASL/PLAIN, you can pass the username and password as credential options to the Kafka source. Vasapi will take care of converting the configuration at runtime.

```HOCON
queries: [
  {
    type: "source",
    name: "mwsSource",
    format: "kafka",
    options:
      {
        "kafka.bootstrap.servers": ${params.KAFKA_SOURCE_SERVER_HOST_NAME},
        "kafka.sasl.mechanism": "PLAIN"
        "kafka.security.protocol": "SASL_SSL",
        // vasapi's credential mechanism will take care of converting the credentioal options into kafka.sasl.jaas.config
        "failOnDataLoss": "false",
        "subscribe": ${params.KAFKA_MWS_TOPIC_NAME},
        "includeHeaders": "true",
        "startingOffsets": "latest"
      },
    credential-options: {
      "kafka.sasl.username": {
        type: "databricks-secret",
        secret-scope: "myScope",
        secret-key: "myKey"
      },
      "kafka.sasl.password": {
        type: "databricks-secret",
        secret-scope: "anotherScope",
        secret-key: "anotherKey"
      }
    }
  }
]
```

Vasapi will convert this into the following configuration, where `myUsername` and `myPassword` are the decrypted values
from the previous config snippet:

```HOCON
{
  options: {
    kafka.bootstrap.servers: ${params.KAFKA_SOURCE_SERVER_HOST_NAME},
    failOnDataLoss: "false",
    subscribe: ${params.KAFKA_MWS_TOPIC_NAME},
    includeHeaders: "true",
    startingOffsets: "latest"
    kafka.sasl.mechanism: "PLAIN"
    kafka.security.protocol: "SASL_SSL",
    kafka.sasl.jaas.config: "org.apache.kafka.common.security.plain.PlainLoginModule required username='myUsername' password='myPassword';"
  }
}
```




