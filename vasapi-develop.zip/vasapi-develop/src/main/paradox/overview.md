
# About

**vasapi** (value-stream-data-pipeline) is a library built on top of Apache Spark.
Its goal is to **reduce boilerplate code** and thus let Data Engineers focus on where they can **add most value**: 
ingest data from various sources, transform it according to (hopefully well-defined) data models and persist it in systems
that provide easy to use interfaces for users and applications.

To achieve this goal, vasapi:

- allows to specify end-2-end data pipelines, i.e. consumes data from sources, transforms data and pushes data into sinks
- provides a simple and easy to use API. All you need to know is SQL. Building a data pipeline becomes a piece of :cake:
- is based on [Apache Spark Structured Streaming](https://spark.apache.org/docs/2.3.0/structured-streaming-programming-guide.html). Structured Streaming is a scalable and fault-tolerant stream processing engine built on the Spark SQL engine.
- supports all sources and sinks that are available for Spark Structured Streaming as a default (including Kafka). Additionally, you can use sources and sinks that connect to a topic on a Solace instance.
- lets you specify data transformations by defining SQL statements. These SQL statements are interpreted directly by Spark Streams, so everything can be used which Spark Streams knows.
- uses [HOCON](https://github.com/lightbend/config/blob/master/HOCON.md#hocon-human-optimized-config-object-notation) as a convenient way to specify the configuration of the data pipeline.

<br/><br/>
In general, vasapi is a good choice if you want to write pipelines fast and can rely on Spark SQL to cover your use case:

| Use Vasapi                             | Use Case                                                                                                                                               |
|:---------------------------------------|:-------------------------------------------------------------------------------------------------------------------------------------------------------|
| yes                                    | I want to write pipelines fast & focus on business logic                                                                                               |
| yes                                    | Spark SQL covers everything I need                                                                                                                     |
| yes                                    | I want to build a streaming pipeline where data comes e.g. from Kafka / Solace or goes to Kafka / Solace                                               |
| yes                                    | I want to handle lots of data (Vasapi fully relies on Spark's scalability)                                                                             |
| possible                               | I do not want / need to use Spark Structured Streaming (we have built in some support for batch workloads as well, although that's not vasapi's focus) |
| possible, but advanced usage of vasapi | I have a very complex pipeline (and cannot cover my logic with Spark SQL only (e.g. I need the Dataframe or DataSet API))                              |