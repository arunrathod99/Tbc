# Testing

Testing a vasapi application can be done in multiple ways depending on the focus of the test. This is not vasapi specific,
but rather a general approach to testing Spark applications.

As described in the other sections of this documentation, a data pipeline usually consists of source(s), transformation(s) and sinks.
Often, we can formulate expectations on how the input of a data pipeline should look like (e.g. based on a schema or sample data).

Then we want to apply a sequence of transformations on this input data and write the final result to one or multiple sinks.

While the interaction with outside source & sink systems is worth being tested in integration / system tests, we often
want to start by testing the data transformations applied in the pipeline.
Essentially, we want to validate whether these transformations change the input data in the way we expect.

In order to facilitate this testing, we have added some utilities to vasapi. These are described in the next section.

## (Semi)automated testing of data transformations

Since version 1.2.0, we added some more advanced testing utilities to vasapi. The goal of these is:

- speed up development by enabling the developer to test the data transformations applied in a pipeline locally
- provide a way to test the pipeline automatically in a CI/CD environment against a given test dataset
- test the pipeline's behaviour under variations of the input data

The class ```com.bosch.asc.vasapi.VasapiValidator``` adds convenience methods to test the pipeline. Check the
API docs for more details on this class and its methods.

Examples for how to use this feature can be found in the integrationTests folder of the vasapi repository.

The steps to set up such tests are:

1. Create a vasapi object with the configuration you want to test

``` scala
val vasapiObj: Vasapi = Pipeline.readVasapiConfig(Some("mws-application.conf"))
```

In this example, we are explicitly passing a configuration file to the pipeline. This is not necessary if you have a file named `application.conf` in your classpath.
Vasapi uses Pureconfig's standard behaviour to load configuration files, see details [here](https://pureconfig.github.io/docs/loading-a-config.html).

2. Create a VasapiValidator object and execute validation

```scala
val confValidator: VasapiValidator = VasapiValidator(vasapiObj)
confValidator.validateTransformations()
```

This will register all pipeline transformations in the Spark context and returns a Scala `Try` object. If the validation fails, the Try object will contain an exception, a `Success` otherwise.
You can also call `allTransformationsValid()` to get a boolean result (but no exception details).

This will check your pipeline for syntactical and logical correctness without actually starting the pipeline. Under the hood, we use
Spark's Catalyst optimizer to check the logical plan of the pipeline.

3. (optional) Validate the pipeline against a test dataset

You can take the testing one step further by validating the pipeline against a test dataset. This is especially useful if you want to test the pipeline's behaviour under variations of the input data.
In order to do so, we need to replace the source(s) of the pipeline with a test source containing some test data.

To do this, you can pass an additional argument when creating the validator object as follows:

```scala
val confValidator: VasapiValidator = VasapiValidator(
  vasapiConfig = vasapiObj,
  replaceSources = Map("mwsSource" -> "test-data/")
)
```

In this example, we are replacing the source called "mwsSource" with a test source containing the test data.
The test data is expected to be in the directory `test-data/` in the classpath (e.g. in your test resources directory).
If your pipeline has multiple sources you want to replace, you can simply add multiple key value pairs to the Map.

We now have a test source called "mwsSource" registered in the Spark context. This source will be used instead of the original source in the pipeline.
For a full example, take a look at the `integrationTest` directory in the vasapi repository.

## End-to-end testing

End-to-end testing of a vasapi pipeline can be done in multiple ways. The most common way is to run the pipeline on a Spark cluster.

You can test a pipeline on any Spark cluster (local mode also works), by:

- place the vasapi jar of your version of choice in your target environment (could be your local machine if you use Spark in standalone mode, or a cluster)
- place the configuration file(s) in the same directory as the jar (or bundle them with the jar if possible)
- run the pipeline using spark-submit (refer to the section @ref:[Running](running.md))

In future versions, we are also planning to add support for containerized tests that can be executed in a CI/CD environment.