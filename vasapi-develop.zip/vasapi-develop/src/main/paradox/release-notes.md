
# Release Notes

## Release Notes 1.1.x

### 1.1.0

#### Repository

- the vasapi repository was moved to BDC GitHub Enterprise (see [here](https://github.boschdevcloud.com/bios-asc/vasapi))
- moved documentation from docupedia to docs-as-code approach within repository

#### Deployment

- vasapi builds are now published to the (internet-facing) BDC artifactory to facilitate future cloud deployments
- artifacts are mirrored into the Bosch internal artifactory as well to allow deployment anywhere inside the Bosch network
- see the readme for details & artifactory coordinates

#### Features

- vasapi now supports writing to S3-compatible object stores (see *"Write data to an S3 sink"* under *stories* in the docs linked below)
- improved handling of Kafka data sources for both json and avro data
    - parse messages using json and avro schemas respectively
    - better control over how to handle parsing failures (e.g. due to schema mismatches)

#### Packaging
- updated to Scala 2.12.15, Spark 3.2.3 and Pureconfig 0.15.0

### 1.1.1

> **_Attention:_**
> this version should not be used; it has a bug caused by erroneous configuration of the
> scala scoverage plugin

#### Packaging
- updated to SparkStreamsSolace 2.0.1

### 1.1.2

#### Bugfixes

- fixed scoverage bug affecting version 1.1.1

### 1.1.3

#### Features

- extended vasapi CommonUDFs with ```encodedString2ArrayOfFloats```, a function to decode a base64 encoded string into an array of floats.
  Check the API docs fo details.

## Release Notes 1.2.x

### 1.2.0

Release can be found [here](https://rb-tracker.bosch.com/tracker01/projects/PJASC/versions/114610)

#### Features

- [PJASC-8359](https://rb-tracker.bosch.com/tracker01/browse/PJASC-8359): added a feature for validating complete pipeline templates:

    - pipeline developers can make use of this feature to validate their pipeline templates before submitting them to a spark cluster, hence reducing the development time
    - this includes syntactical & logical correctness as well as writing unit tests validating the pipeline's data transformation against a given input dataset
    - check the @ref:[testing section](testing.md)

- [PJASC-9239](https://rb-tracker.bosch.com/tracker01/browse/PJASC-9239): bundle pipeline conf with jar

  - to simplify deployment, the pipeline configuration can now be bundled with the jar file
  - See standalone vs. library mode in @ref:[running](running.md)

- [PJASC-11014](https://rb-tracker.bosch.com/tracker01/browse/PJASC-11014): Modularized `Pipeline.scala` implementation
  to allow for easier usage of vasapi as a drop-in library vs. standalone library. See standalone vs. library mode in @ref:[running](running.md)

- [PJASC-10928](https://rb-tracker.bosch.com/tracker01/browse/PJASC-10928): remove deprecated features & add iceberg able inits:
  
  - added `IcebergTable` type to `Initialization` block. See the iceberg section in @ref:[Stories](stories.md) for details.
  - removed deprecated `Query` subtypes `Table` & `Init`
  - removed deprecated `Initialization` subtype `Spark` & `Sql`

- [PJASC-10439](https://rb-tracker.bosch.com/tracker01/browse/PJASC-10439): updated auxiliary scripts

  - updated the python helper script to start pipelines to spark3 (see `api` directory)
  - removed deprecated auxiliary scripts

- [PJASC-10443](https://rb-tracker.bosch.com/tracker01/browse/PJASC-10443): clean up of `pipelines` directory

  - removed deprecated pipeline definitions
  - moved active pipelines to dedicated repositories

#### Packaging

- updated to Spark 3.3.2
- updated to SparkStreamsSolace 2.1.1
- changed logging to log4j2, reflecting Spark's move to log4j2 ([PJASC-9635](https://rb-tracker.bosch.com/tracker01/browse/PJASC-9635))
- updated further dependencies to latest versions

### 1.2.1

Release can be found [here](https://rb-tracker.bosch.com/tracker01/projects/PJASC/versions/120926)

#### Features

- [PJASC-10971](https://rb-tracker.bosch.com/tracker01/browse/PJASC-10971): Downgraded the logstash dependency version forwarding logs to Logstash
- [PJASC-11623](https://rb-tracker.bosch.com/tracker01/browse/PJASC-11623): Bugfix in the 1.2.0 for creation of iceberg tables in init
- [PJASC-10976](https://rb-tracker.bosch.com/tracker01/browse/PJASC-10976): UDF improvement supporting rexroth tightening pipeline
- [PJASC-11368](https://rb-tracker.bosch.com/tracker01/browse/PJASC-11368): Removed static partition-date in S3 sink to make it more generic

