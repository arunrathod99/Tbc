# Getting started

This page contains an overview on how vasapi pipelines can be set up (i.e. configured).
You can find more examples and specific use cases on the following page: @ref:[stories](stories.md)

## overview

A vasapi pipeline's structure is mostly designed by the way Spark Structured Streaming works. So please get acquainted with [Spark Structured Streaming](https://spark.apache.org/docs/2.3.0/structured-streaming-programming-guide.html).
The configuration can be specified in a [HOCON](https://github.com/lightbend/config/blob/master/HOCON.md#hocon-human-optimized-config-object-notation) (JSON like) structured file. The high-level structure looks as follows:

```HOCON
inits: [
    {
    type: "external-hive table"
    <further properties>: "..."
    }
   ]

queries: [
    {
        type: "source"
        name: "<source name>"
        format: "<source type>"
        options: {
            <option key>: "<option value>"
        }
    }

    {
        type: "view"
        name: "<view name>"
        sql: "<SQL statement>"
    }

    {
        type: "sink"
        sql: "<SQL statement>"
        format: "<sink type>"
        coalesce: <number of partitions>
        output-mode: "<Spark Streams output mode>"
        partition-by: ["<partition key>"]
        trigger: { type: "<Spark Streams trigger type>", interval: "<trigger interval>" }
        options: {
            <option key>: "<option value>"
        }
    }

]
```

This represents the typical structure of a data pipeline:

* initialize some kind of table on start up
* then, connect to sources and consume data
* transform this data in 1...n steps
* write the transformed data to 1...n sinks

Vasapi directly builds on this pipeline concept:

You can have multiple ```sources```, ```views``` and ```sinks```.
The ```name``` attribute of a source or a view defines a SQL view/table, which can be referenced directly in an SQL statement afterwards,
e.g. if you have a source with ```name: "mySource"```, you can reference it in another view or sink in the SQL statement with ```select * from mySource```.

Some of the values in the source, view and sink objects are optional.
An "init" block allows you to specifically create an External Hive Table or an Iceberg Table. Vasapi will execute these blocks once the application starts.

Note: "init" must always be the first type in configuration file.

## inits

This section can be used to create external Hive / Impala tables as well as Iceberg tables pointing to the data written by a vasapi application. See usage example below.

```HOCON
inits: 
[
    
    {
      type: "iceberg-table"
      name: proc_iceberg.test_table
      drop-table: true
      ddl-schema: "column1 STRING, column2 BIGINT, column3 STRING, column4 STRING"
      partition-by: ["column1"]
      comment: "This is an Iceberg table"
      tbl-properties: {"format-version" : "2"}
      location: "/proc/iceberg"
    },
    
    {
    "type": "external-hive-table"
    "name": "proc_hive.test_table"
    "drop-table": true
    "json-schema-file": "./schema.json"
    "ddl-schema": "column1 STRING, column2 BIGINT, column3 STRING, column4 STRING"
    "partition-by": ["column1", "column2"]
    "comment": "It's a test table"
    "stored-as": "parquet"
    "location": "/proc/hive_smt"
    }
    
]
```

## queries

Queries are a collective term for the most typical elements of a data pipeline:
- sources
- transformations (views)
- sinks

The term query in this context leans on Spark Structured Streaming's concept of a streaming query.
There, a streaming query is a logical plan reading data from source system(s), apply transformations and write it to a sink. Such a logical plan is triggered by a Spark action (such as save, startStream etc.) and runs until stopped.

### sources

A source in Vasapi defines where data is read from and is created using the "source" type in the queries block.

The source has the following attributes: type(mandatory), name(mandatory), format(mandatory) and options consists of all the configuration settings to connect to the source.

Here's a sample source:

```HOCON
{
  type: "source",
  name: "vasapi_datapublisher_partdetails_source",
  format: "kafka",
  options: {
    "jceksPath": "jceks:///user/user_name/vasapi/jceksFile.jceks",
    "passwordAlias": "Aliasname.password",
    "kafka.bootstrap.servers": "si0vm05626.de.bosch.com:9093",
    "kafka.security.protocol": "SSL",
    "kafka.ssl.keystore.location": "./rtp2_datapublisher_qualitydata_partdetails.ks",
    "kafka.ssl.truststore.location": "./Bosch-CA-bundle.ts",
    "failOnDataLoss": "false",
    "subscribe": "aertp2prod.push.datapublisher-qualitydata-partdetails.joined-unpivoted",
    "includeHeaders": "true",
    "startingOffsets": "latest"
  }
}
```

### views

As stated above, a view is a type of query and defines a Spark SQL view on a table or dataframe. Vasapi allows to create such a view by using type "view" in the queries block.
Internally, this creates a temporary Spark view which can be queried by other views or sinks.

A view has the following attributes: name (mandatory), sql (mandatory) and [watermark](https://spark.apache.org/docs/latest/structured-streaming-programming-guide.html#handling-late-data-and-watermarking) (optional - can be omitted like shown in example above)
Here's a sample view:

```
{
    type: "view",
    name: "MpStateTextExplodeData",
    sql:"""
        SELECT
            Line,
            Station,
            PPpartNo,
            HeaderID,
            current_timestamp() as eventTime,
            MpStateText
        FROM
            ParsedHeaderSourceData
        LATERAL VIEW EXPLODE(RdData.MpStateText) apt as MpStateText
        """,
    watermark: {
    event-time: "eventTime",
    delay-threshold: "10 seconds"
    }
}
```

<br/><br/>
### sinks

A sink is a type of query and defines a Spark SQL sink. Vasapi allows to create such a sink by using type "sink" in the queries block.
Internally, this creates a streaming sink which writes data to a specified sink system.
 
Sinks have the following attributes:

- sql (mandatory)
- format (mandatory)
- coalesce (optional)
- output-mode (optional)
- partition-by (optional)
- trigger (optional)
- options (optional)

An example looks like this:
    
```
{
    type: "sink",
    sql: "SELECT * FROM MyView",
    format: "parquet",
    coalesce: 1,
    output-mode: "append",
    partition-by: ["eventTime"],
    trigger: { type: "processing-time", interval: "10 seconds" },
    options: {
        path: "/tmp/vasapi/output"
    }
}
```
<br/><br/>

## add-on: udfs

You can specify anonymous Scala functions here. Vasapi will register them as Spark UDFs (user-defined functions).
They can then be used like built in Spark SQL functions. This section is **optional** and can be omitted from your pipeline.

Vasapi offers two ways to register such functions

### Vasapi CommonUDFs
- as part of the vasapi library's [CommonUDFs](https://github.boschdevcloud.com/bios-asc/vasapi/blob/develop/src/main/scala/com/bosch/asc/vasapi/CommonUDF.scala)

### UDF registration at runtime

| This feature is likely to be deprecated in future versions   |
|-----------------------------------------|

You can register your own UDFs at runtime by specifying them in the configuration file like so:

```HOCON
udfs:
{
<udf name>: "<anonymous scala function>"
}
```

Only do this if you really need to, as such UDFs are hard to test & maintain.
See the Spark documentation to check whether what you need is already available.

