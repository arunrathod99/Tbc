@@@ index

* [Sources](sources.md)
* [Transforming data](transformation.md)
* [Sinks](sinks.md)

@@@

# Components of a vasapi pipeline

As explained in the previous sections, vasapi allows to define a pipeline as a sequence of sources, transformations and sinks.
Navigate through the respective sub-page on the left, to find more detailed information on how to set up each of these components.

For more information and examples on how to combine these sources into pipelines, refer to the @ref:[Stories](stories.md) section.
