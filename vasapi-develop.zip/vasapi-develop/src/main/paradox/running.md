# Running

This page gives an overview of how to run a Vasapi application on a Spark cluster.

## Preparing an application

In principle, you can run a Vasapi application on any Spark cluster. As explained in @ref:[Overview](overview.md) and @ref:[Stories](stories.md),
you need to prepare one or multiple HOCON configuration files to define your application's behavior.

There are multiple ways to pass these configuration files to your application:

### Use vasapi in standalone mode

When running in standalone mode, we make use of Pureconfig's / Typesafe config's [standard behaviour](https://github.com/lightbend/config?tab=readme-ov-file#standard-behavior).
To run on a spark cluster, we need:

* the vasapi package (jar)
* a copy of the main application configuration file from where you trigger your spark submit
* you can pass it to spark-submit command in the ```--files``` directive like so: ```/path/to/main/my_app.conf#application.conf```
* add `spark.driver.extraJavaOptions=-Dconfig.file=application.conf` to your spark-submit command

You can also split your configuration across multiple files and merge them at runtime (e.g. to keep things well-structured for larger applications).
In that case you can pass multiple files to the spark-submit command in the ```--files``` directive.

Take a look at the `examples` and `integrationTests` directories and the spark submit commands below for examples.

### Use vasapi as a library

Instead of directly using the vasapi package / jar, you can also add it as a dependency to your own sbt project:

``` scala
libraryDependencies ++= Seq("com.bosch.asc" %% "vasapi" % "<version>")
```

When doing so, you can still use the mechanism described above to pass configuration files to your application.
However, you can also use the `pureconfig` library to load configuration files from the classpath or from a URL.

To achieve this, simply pass your main conf file as a command line argument to the jar in your Spark submit (see examples below).
This will attempt to load the file from a local file, url or a resource on the classpath.
If your main conf file references other files, they will be loaded from the same location as the main conf file.

## Running a vasapi application on a Spark cluster

Once you have prepared your application, you can run it on a Spark cluster.
Since Vasapi is just a wrapper around Apache Spark, we can simply use the [spark-submit utility](https://spark.apache.org/docs/latest/submitting-applications.html) to start an application:

```
spark-submit \
--master yarn \
--deploy-mode cluster \
--name <enter app name> \
--class com.bosch.asc.vasapi.Pipeline \
--conf spark.yarn.submit.waitAppCompletion=false \
--conf spark.sql.shuffle.partitions=5 \
--conf spark.sql.streaming.schemaInference=true \
--conf spark.sql.files.ignoreCorruptFiles=true \
--conf spark.cleaner.referenceTracking.cleanCheckpoints=true \
--num-executors 2 \
--driver-memory 6G \
--driver-cores 4 \
--executor-memory 4G \
--executor-cores 4 \
--packages com.github.pureconfig:pureconfig_2.12:0.15.0, \
--repositories https://rb-artifactory.bosch.com/artifactory/BIDOS,https://rb-artifactory.bosch.com/artifactory/maven-central-remote,\
https://rb-artifactory.bosch.com/artifactory/cloudera-maven-remote,https://rb-artifactory.bosch.com/artifactory/asc-de-generic-remote \
https://artifactory.boschdevcloud.com/ui/native/asc-de-generic-local/com/bosch/asc/vasapi_2.12/1.2.0/vasapi_2.12-1.2.0.jar
<include main application conf file to load from url / file / resource>
```

Notes:
* application resources (cores / memory) are just an example and should be adjusted
* you can add or omit command line arguments to the vasapi jar at the end of the spark-submit command (see [above](#use-vasapi-as-a-library)) 
* the vasapi jar is published to `artifactory.boschdevcloud.com` (cloud facing Bosch development cloud) and can be referenced from there
* to run vasapi inside the Bosch network, you can also use the Bosch internal artifactory: `rb-artifactory.bosch.com` (see next section)

<br>

## Running on a RB Analytics Hadoop / Spark cluster

### spark-submit

You can further customize the spark-submit command shown in the previous section like shown below.

This extended spark-submit contains:
* additional configuration options
* additional logging dependencies to replace Spark's default logging (log4j) with logback
* enable apache iceberg
* configuration to make the SparkUI accessible to a specific group

```
spark3-submit \
--master yarn \
--deploy-mode cluster \
--name <enter app name> \
--conf 'spark.driver.extraJavaOptions=-Dconfig.file=application.conf -Duser.timezone=UTC' \
--class com.bosch.asc.vasapi.Pipeline \
--conf spark.executor.extraJavaOptions=-Duser.timezone=UTC \
--conf spark.sql.session.timeZone=UTC \
--conf spark.yarn.submit.waitAppCompletion=false \
--conf spark.sql.shuffle.partitions=5 \
--conf spark.dynamicAllocation.enabled=false \
--conf spark.sql.streaming.schemaInference=true \
--conf spark.sql.files.ignoreCorruptFiles=true \
--conf spark.cleaner.referenceTracking.cleanCheckpoints=true \
--conf spark.acls.enable=true \
--conf spark.ui.view.acls.groups=DE/idm2bcd_aesi01dev_global_read \
--conf spark.sql.catalog.<cluster name>=org.apache.iceberg.spark.SparkCatalog,
--conf spark.sql.catalog.<cluster name>.type=hive,
--conf spark.sql.catalog.<cluster name>.uri=hive metastore url(s),
--conf spark.sql.catalog.<cluster name>.cache-enabled=false,
--num-executors 2 \
--driver-memory 6G \
--driver-cores 4 \
--executor-memory 4G \
--executor-cores 4 \
--files /path/to/main/application.conf#application.conf,/path/to/further/files/referenced/by/application.conf \
--file "https://rb-artifactory.bosch.com/artifactory/asc-de-generic-remote-cache/com/bosch/asc/vasapi_2.12/1.2.0/vasapi_2.12-1.2.0.jar" \
--packages com.github.pureconfig:pureconfig_2.12:0.15.0,org.apache.spark:spark-avro_2.12:3.3.2,\
org.json4s:json4s-xml_2.12:3.6.12,com.bosch.bidos:solace-source-sink_2.12:2.0.1,\
org.apache.iceberg:iceberg-spark-runtime-3.2_2.12:1.3.0,org.apache.iceberg:iceberg-hive-runtime:1.3.1,\
com.bosch.asc:vasapi_2.12:1.1.0,
--jars "https://rb-artifactory.bosch.com/artifactory/maven-central-remote-cache/org/apache/logging/log4j/log4j-to-slf4j/2.18.0/log4j-to-slf4j-2.18.0.jar",\
"https://rb-artifactory.bosch.com/artifactory/jcenter-cache/ch/qos/logback/logback-classic/1.2.13/logback-classic-1.2.13.jar",\
"https://rb-artifactory.bosch.com/artifactory/jcenter-cache/ch/qos/logback/logback-core/1.2.13/logback-core-1.2.13.jar",\
"https://rb-artifactory.bosch.com/artifactory/jcenter-cache/net/logstash/logback/logstash-logback-encoder/6.4/logstash-logback-encoder-7.4.jar"\
--repositories https://rb-artifactory.bosch.com/artifactory/BIDOS,https://rb-artifactory.bosch.com/artifactory/maven-central-remote,\
https://rb-artifactory.bosch.com/artifactory/cloudera-maven-remote,https://rb-artifactory.bosch.com/artifactory/asc-de-generic-remote \
https://rb-artifactory.bosch.com/artifactory/asc-de-generic-remote/com/bosch/asc/vasapi_2.12/1.2.0/vasapi_2.12-1.2.0.jar
```

### Livy

Alternatively, you can make use of Apache Livy, which is a REST interface for Spark. It is enabled on all RB Analytics Platform Hadoop clusters.
Check the respective Cloudera Manager instance for the livy server fqdn of interest.

```
curl --negotiate -u : -H "Content-Type: application/json" https:// Enter the livy server:28998/batches -X POST \
--data '{"className": "com.bosch.asc.vasapi.Pipeline", "name": "Enter application name", "driverMemory": "8g", "driverCores": 4, \
"executorCores": 3, "executorMemory": "4g", \
"jars": [
  "https://rb-artifactory.bosch.com/artifactory/maven-central-remote-cache/org/apache/logging/log4j/log4j-to-slf4j/2.18.0/log4j-to-slf4j-2.18.0.jar",
  "https://rb-artifactory.bosch.com/artifactory/jcenter-cache/ch/qos/logback/logback-classic/1.2.13/logback-classic-1.2.13.jar",
  "https://rb-artifactory.bosch.com/artifactory/jcenter-cache/ch/qos/logback/logback-core/1.2.13/logback-core-1.2.13.jar",
  "https://rb-artifactory.bosch.com/artifactory/jcenter-cache/net/logstash/logback/logstash-logback-encoder/7.4/logstash-logback-encoder-7.4.jar"
  ], \
"file": "https://rb-artifactory.bosch.com/artifactory/asc-de-generic-remote-cache/com/bosch/asc/vasapi_2.12/1.2.0/vasapi_2.12-1.2.0.jar", \
"files": [
  "/path/to/main/application.conf#application.conf","/path/to/further/files/referenced/by/application.conf",
  "logback.xml file"
  ], \
"conf": { \
  "spark.driver.extraJavaOptions": "-Dconfig.file=application.conf -Dcom.bosch.asc.sparkstreamssolace.replay.block.size=100 -Duser.timezone=UTC -Djava.io.tmpdir=/tmp", \
  "spark.executor.extraJavaOptions": "-Duser.timezone=UTC", \
  "spark.sql.session.timeZone": "UTC", \
  "spark.yarn.submit.waitAppCompletion": "false", \
  "spark.sql.shuffle.partitions": 5, \
  "spark.sql.streaming.schemaInference": "true", \
  "spark.sql.files.ignoreCorruptFiles": "true", \
  "spark.jars.ivySettings": "/var/lib/livy/ivysettings.xml", \
  "spark.shuffle.service.enabled": "true", \
  "spark.cleaner.referenceTracking.cleanCheckpoints": "true", \
  "spark.acls.enable": "true", \
  "spark.ui.view.acls.groups": "DE/idm2bcd_aesi01dev_global_read", \
  "spark.executor.extraClassPath": "log4j-over-slf4j-2.0.7.jar:logback-classic-1.2.12.jar:logback-core-1.2.12.jar:logstash-logback-encoder-6.4.jar", \
  "spark.driver.extraClassPath": "log4j-over-slf4j-2.0.7.jar:logback-classic-1.2.12.jar:logback-core-1.2.12.jar:logstash-logback-encoder-6.4.jar", \
  "spark.jars.packages": "com.github.pureconfig:pureconfig_2.12:0.15.0,org.apache.spark:spark-avro_2.12:3.3.2,org.json4s:json4s-xml_2.12:3.6.12,com.bosch.bidos:solace-source-sink_2.12:2.0.1,org.apache.iceberg:iceberg-spark-runtime-3.2_2.12:1.3.0,org.apache.iceberg:iceberg-hive-runtime:1.3.1", \
  "spark.jars.repositories": "https://rb-artifactory.bosch.com/artifactory/BIDOS,https://rb-artifactory.bosch.com/artifactory/maven-central-remote,https://rb-artifactory.bosch.com/artifactory/cloudera-maven-remote,https://rb-artifactory.bosch.com/artifactory/maven2-remote,https://github.boschdevcloud.com/bios-asc/vasapi/", \
  "spark.sql.catalog.cluster name": "org.apache.iceberg.spark.SparkCatalog", \
  "spark.sql.catalog.cluster name.type": "hive", \
  "spark.sql.catalog.cluster name.uri": <Enter the livy server for cluster e.g.thrift://clj020l.emea.bosch.com:9083>, \
  "spark.sql.catalog.cluster name.cache-enabled": "false", \
  "spark.dynamicAllocation.enabled": "false"}
}' | python -m json.tool
```

