# Transforming data

Once you have set up your sources, you can start transforming the data. This is done by defining a sequence of transformations
that will be applied to the data as it flows through the pipeline.

## Basic transformations

Let us assume that you have created a source called `myKafkaSource` reading data from Kafka.
You can now express a sequence of 1...n transformations that will be applied to the data read from Kafka, e.g.:

```HOCON
{
    type: "view",
    name: "parsedParametersArrayZip",
    sql: """
          SELECT
            mes_source,
            location_result_uid,
            payload.document.basicinfo.identifier as uniquepart_id,
            cast(NULL as STRING) as group_id,
            cast(NULL as STRING) as group_pos,
            payload.document.basicinfo.locationid as location_id,
            line_number,
            CAST(payload.document.basicinfo.procno AS INT) as process_number
        FROM
            myKafkaSource
        """
}
```

This is a simple example that reads data from `myKafkaSource` and selects a subset of the columns.
You can define more complex transformations as needed. The content of the `sql` attribute will be executed by the underlying Spark
engine (executed by `spark.sql(...)`), so you can use all the features of Spark SQL to define your transformations.

Here's a slightly more involved example from a real-world pipeline:

```HOCON
{
    type: "view",
    name:"mwsSourceSchemaValidation",
    sql:
      """
      WITH schemaValidation AS (
        SELECT
          content,
          xmlSchemavalidation(content, 'mws_xsd.xsd') AS schema_validation_successful,
          """'${params.SCHEMA_VALIDATION_REQUIRED}'""" AS is_schema_validation_required
        FROM
          mwsSource
      )
    
      SELECT
        content,
        schema_validation_successful,
        CASE
          WHEN schema_validation_successful = 'false' AND is_schema_validation_required = 'yes' THEN 'no' ELSE 'yes'
        END AS is_processing_required
      FROM
        schemaValidation
      """
}
```

This example reads from a source called `mwsSource`, validates the content against an XML schema, and then decides whether further processing is required based on the validation result.
It calls a udf (user-defined function) called `xmlSchemavalidation` that vasapi defines on top of what is already available in Spark SQL out of the box.
See vasapi's [CommonUDFs](https://pages.github.boschdevcloud.com/bios-asc/vasapi/com/bosch/asc/vasapi/udf/CommonUDF$.html) for a list of what is available.

This example also makes use of HOCON variable substitution to make the pipeline more flexible. This allows e.g. to resolve environment specific values at runtime.
For a complete example you can take a look at the [integration tests](https://github.boschdevcloud.com/bios-asc/vasapi/tree/develop/integrationTests/src/test/resources) in the vasapi repository.

You can chain as many views (i.e. transformation steps) as you like as long as each view references the name of one or multiple
sources or views in its sql statement. 

## Advanced transformations

Apart from such [basic transformations](https://spark.apache.org/docs/latest/structured-streaming-programming-guide.html#basic-operations---selection-projection-aggregation) like selecting, type casting or filtering data, you can also perform more advanced transformations.
For example, you can define more advanced operations such as [window operations](https://spark.apache.org/docs/latest/structured-streaming-programming-guide.html#window-operations-on-event-time) and [joins](https://spark.apache.org/docs/latest/structured-streaming-programming-guide.html#join-operations).

Here is an example of a window operation making use of an additional `watermark` parameter to handle late data (see Spark docs for details on this concept).

```HOCON
{
    type: "view",
    name: "windowedCounts",
    watermark: {
        eventTime: "timestamp",
        delayThreshold: "10 minutes"
    }
    sql: """
      SELECT
        window,
        word,
        count
      FROM (
        SELECT
          explode(split(value, ' ')) as word,
          count(*) as count,
          window(timestamp, '10 minutes') as window
        FROM
          myKafkaSource
        GROUP BY
          window(timestamp, '10 minutes'), explode(split(value, ' '))
      )
    """
}
```




