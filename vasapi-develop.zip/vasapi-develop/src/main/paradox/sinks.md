# Sinks

Once the transformations are concluded and the data is ready to be persisted, the data can be written to a sink.
In principle, all sources can also be used as sinks. However, the most common sinks are file sinks, Iceberg tables, Solace and Kafka.

## Common Properties

All sinks take a common set of properties (listed below). Most of them are optional. The examples in the sections further below
show how to use them in a source configuration.

Find details (e.g. data types) in the [Sink API docs](https://pages.github.boschdevcloud.com/bios-asc/vasapi/com/bosch/asc/vasapi/conf/Sink.html)

| Attribute          | Description                                                                                                                                                                                                                                                             |
|:-------------------|:------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| sql                | sql statement to be executed before writing to this source                                                                                                                                                                                                              |
| format             | sink format. Can be e.g. `kafka`, `solace_sink`, `iceberg` or any other sink format supported by Spark                                                                                                                                                                  |
| coalesce           | (optional) coalesce number of partitions before writing, e.g. to reduce number of output files                                                                                                                                                                          |
| log-path           | (optional) deprecated - will be removed in future releases                                                                                                                                                                                                              |
| data-base-name     | (optional) only needed for Hive table sinks                                                                                                                                                                                                                             |
| table-name         | (optional) only needed for Hive table sinks                                                                                                                                                                                                                             |
| partition-by       | (optional) list of columns by which to partition the dataframe before writing to sink                                                                                                                                                                                   |
| execution-mode     | (optional) can be `batch` or `stream` (default). Only use for specific batch sources                                                                                                                                                                                    |
| trigger            | (optional) trigger interval for Spark's micro-batch execution. Should always be set.                                                                                                                                                                                    |
| spark-listener     | (optional) list of spark listeners, e.g. to report metrics, or trigger callback to other external system (see [Spark docs](https://spark.apache.org/docs/latest/structured-streaming-programming-guide.html#reporting-metrics-programmatically-using-asynchronous-apis) |
| options            | (optional) a Map[String, String] containing further configuration options passed to the sink                                                                                                                                                                            |
| credential-options | (optional) a Map[String, String] containing credential-related options. See details in @ref:[Credential handling](#credential-handling).                                                                                                                                |


### Credential Handling

Sinks support the same secret handling mechanisms as sources. Take a look at the @ref:[sources](sources.md) section for details.

## Streaming Sinks

Vasapi is mainly built for usage with Spark's Structured Streaming API. It supports all kinds of sinks that are supported by Spark.
Additionally, the Solace message broker is supported as a streaming sink.

### File (e.g. Parquet) Sink

You can write data to a file sink using the target file type as `format`. The `path` option specifies the location of the file sink.

```HOCON
{
    type: "sink",
    sql: """SELECT * FROM myLastView""",
    coalesce: 3,
    format: "parquet",
    output-mode: "append",
    partition-by: ["mes_source", "result_date"],
    trigger: { type: "processingtime", interval: "10 minutes" },
    spark-listener: [
      { type: "progress-sql-statement", sql: "alter table myDB.myTable recover partitions"}
    ],
    options:
    {
        checkpointLocation: "/path/to/checkpoint",
        path: "/path/to/target/file/location",
        queryName: "mySink"
    }
}
```

### Iceberg Table

You can write data to an Iceberg table using the `iceberg` format. The `path` option specifies the location of the Iceberg table.
Note that the iceberg table has to be created before writing data into it.

```HOCON

{
    type: "sink",
    sql: """
          SELECT
            col1,
            col2
          FROM
            myView
          """,
    format: "iceberg",
    output-mode: "append",
    trigger: { type: "processingtime", interval: "10 minutes" },
    options:
    {
        checkpointLocation: "/path/to/checkpoint/location",
        path: catalog.dbName.tableName,
        queryName: "mesdp_archive_iceberg_sink"
    }
}
```

For the ```path``` option, note that we are not specifying a path to a directory, but rather the fully qualified name of 
the Iceberg table (including the catalog). More on Iceberg catalogs [here](https://iceberg.apache.org/concepts/catalog/).
In RB Analytics Platform (Hadoop) clusters, we typically work with the Hive Metastore catalog, which is the same service that Hive and Impala use.

### Solace

You can write data to a Solace topic using the `solace_sink` format.
The `host`, `vpn`, `username`, and `channel` options specify the Solace broker connection details and the topic to write to.
Check [spark-streams-solace](https://github.boschdevcloud.com/bios-asc/spark-streams-solace) for configuration options.

```HOCON
{
  type: "sink",
  sql: "select to_json(struct(current_timestamp() as `timestamp`, value as `content`)) from fileSource",
  format: "solace_sink",
  trigger: {
    type: "processingtime",
    interval: "30 second"
  },
  options: {
    username: "vasapi_user",
    vpn: "default",
    host: "smf://si0vm02909.de.bosch.com:55555",
    channel: "witches/output",
    checkpointLocation: "witches/checkpoint"
  }
  credential-options: {
    password: {
      credential-type = "jceks"
      path = "jceks:///path/to/my/secret"
      alias = "myAlias"
    }
  }
}
```

### Kafka

Likewise, you can write data to a Kafka topic using the `kafka` format. The `topic` option specifies the Kafka topic to write to.

```HOCON
{
    type: "sink",
    sql: """SELECT * FROM parameter_results_kafka""",
    format: "kafka",
    output-mode: "append",
    trigger: { type: "processingtime", interval: "60 seconds" },
    options:
    {
        jceksPath: "jceks:///path/to/my.jceks",
        passwordAlias: "myAlias.password",
        kafka.bootstrap.servers: "server.de.bosch.com:9093",
        subscribe: "...",
        checkpointLocation: "/path/to/checkpoint/location"
        queryName: "parameter_results_kafka_sink"
    }
}
```

Take a look at the section @ref:[Credential Handling](#credential-handling) for details on how to handle Kafka credentials.

## Batch Sinks

While the most common use case for vasapi is streaming (Spark Structured Streaming), there are also some specific use cases that require batch processing.
For these cases, you can use the `executionMode` attribute to specify that the sink should be executed in `batch` mode.

It is important to note that Spark does not allow mixing batch and streaming sources in the same pipeline.
Therefore, you should only use batch sinks in pipelines that do not contain streaming sources:

- omit the source & define one or multiple ```views``` only instead (check the @ref:[transformation](transformation.md) section)
- in the view, you can directly reference existing Hive or Iceberg tables, see [use hive table as source](#use-hive-table-as-source) --> Spark has access to all tables defined in the current (Hive) Metastore

### Hive Batch Sink

Since version 1.2.0, vasapi supports appending or overwriting data to Hive tables.

> **_Attention:_**
> this features uses Spark's insertInto functionality, see the [Spark documentation](https://spark.apache.org/docs/3.3.2/api/java/org/apache/spark/sql/DataFrameWriter.html#insertInto-java.lang.String-).\
> Columns names are ignored and only inserted based on position.\
> Ensure that the DataFrame's schema exactly machtes the table's schema.
>

<br>


You can specify a Hive batch sink as shown below.
Note that `data-base-name`, `table-name`, `output-mode` and `fileFormat` options are mandatory.


```HOCON
{
    type: "sink",
    sql: "select * from final",
    format: "hive",
    output-mode: "overwrite",
    execution-mode: "batch",
    data-base-name: "test_sample",
    table-name:"demo_hive",
    options: {
      fileFormat: "parquet"
    }
}
```

### S3 Sink

Since version 1.1.0, vasapi supports writing to S3-compatible object stores.
You can set up S3 Sinks as shown below. Note that bucketName and filePrefix options are mandatory and define where your data will end up: ```s3://<bucketName>/<ilePrefix>/...```
Partition columns (if specified) will be added to the prefix.

```HOCON
{
  type: "sink",
  sql: "select * from image_metadata",
  format: "s3",
  coalesce: "3",
  output-mode: "append",
  execution-mode: "batch",
  options: {
    bucketName: ${params.bucket_name},
    filePrefix: ${params.cluster_name}"/"${params.data_base_name}"/v_inspection_classifications",
    fs.s3a.endpoint: "https://..."
  }
  credential-options: {
    accessKeyPasswordAlias: {
      credential-type = "jceks"
      path = "jceks:///path/to/my/secret"
      alias = "myAlias"
    },
    secretKeyPasswordAlias: {
      credential-type = "jceks"
      path = "jceks:///path/to/my/secret"
      alias = "myAlias"
    }
  },
}
```

After credential decryption, this will be converted to:

```HOCON
{
  type: "sink",
  sql: "select * from image_metadata",
  format: "s3",
  coalesce: "3",
  output-mode: "append",
  execution-mode: "batch",
  options: {
    bucketName: ${params.bucket_name},
    filePrefix: ${params.cluster_name}"/"${params.data_base_name}"/v_inspection_classifications",
    fs.s3a.endpoint: "https://...",
    fs.s3a.access.key: "...",
    fs.s3a.secret.key: "..."
  }
}
```