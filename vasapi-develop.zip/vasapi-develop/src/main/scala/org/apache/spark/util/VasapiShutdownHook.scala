/*
 * Copyright (c) 2009, 2018 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */

package org.apache.spark.util

import org.apache.spark.sql.streaming.StreamingQueryManager
import org.apache.spark.internal.Logging

/** Installing a shutdown hook which stops every active streaming query on a
  * shutdown before the SparkContext is shut down.
  */

@deprecated(
  "deprecated because it is covered through Spark's built-in WAL logic",
  "vasapi 1.0.0"
)
@SuppressWarnings(Array("all"))
object VasapiShutdownHook extends Logging {
  // its needed because org.apache.hadoop.util.ShutdownHookManager is triggered when the exception happens.
  val install = (streamsManager: StreamingQueryManager) => {
    // Streaming query need to get stopped before the SparkContext is stopped.
    ShutdownHookManager.addShutdownHook(
      ShutdownHookManager.SPARK_CONTEXT_SHUTDOWN_PRIORITY + 1
    ) { () =>
      logInfo(
        "Invoking stop() on all active streaming queries from shutdown hook and awaiting their termination"
      )
      try {
        streamsManager.active.foreach(query => query.stop())
        streamsManager.awaitAnyTermination()
      } catch {
        case e: Throwable =>
          logWarning(
            "Ignoring Exception while stopping streaming queries from shutdown hook",
            e
          )
      }
    }
  }
}
