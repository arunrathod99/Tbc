/*
 *  Copyright (c) 2023 Robert Bosch GmbH and its subsidiaries.
 *  This program and the accompanying materials are made available under
 *  the terms of the Bosch Internal Open Source License v4
 *  which accompanies this distribution, and is available at
 *  http://bios.intranet.bosch.com/bioslv4.txt
 */

package com.bosch.asc.vasapi.validation

import com.bosch.asc.vasapi.utils.VasapiSchemaUtils
import io.github.embeddedkafka.{EmbeddedK, EmbeddedKafka, EmbeddedKafkaConfig}
import org.apache.kafka.clients.producer.ProducerRecord
import org.apache.kafka.common.serialization.{
  ByteArrayDeserializer,
  ByteArraySerializer,
  Deserializer,
  Serializer,
  StringDeserializer,
  StringSerializer
}
import org.apache.spark.internal.Logging
import org.apache.spark.sql.DataFrame

import java.net.{InetAddress, Socket}
import scala.util.{Failure, Success, Try}

/** convenience class allowing setup of [[EmbeddedKafka]] instances for usage in
  * unit and integration tests.
  * @param kafkaPort
  *   broker port
  * @param zkPort
  *   zookeeper port
  */
class KafkaFixture(
    kafkaPort: Int,
    zkPort: Int
) extends EmbeddedKafka
    with Logging {

  // needed for (de)serialization of kafka messages
  implicit val stringSerializer: Serializer[String] = new StringSerializer()
  implicit val stringDeserializer: Deserializer[String] =
    new StringDeserializer()

  implicit val byteArraySerializer: Serializer[Array[Byte]] =
    new ByteArraySerializer()
  implicit val byteArrayDeserializer: Deserializer[Array[Byte]] =
    new ByteArrayDeserializer()

  private val customBrokerConfig: Map[String, String] = Map(
    "replica.fetch.max.bytes" -> "2000000",
    "message.max.bytes" -> "2000000"
  )

  // hint: implicit conf needs to be in scope for topic creation and producing data
  implicit val customKafkaConfig: EmbeddedKafkaConfig = EmbeddedKafkaConfig(
    kafkaPort = kafkaPort,
    zooKeeperPort = zkPort,
    customBrokerProperties = customBrokerConfig
  )

  // beforeAll returns unit, so we use a shared object instance as workaround
  val kafka: EmbeddedK = EmbeddedKafka.start()

  // test setup: create kafka topic and publish some records onto it
  logInfo(s"embedded kafka instance is running: ${EmbeddedKafka.isRunning}")

  private[vasapi] def status(host: String = "localhost"): String = {
    Try(new Socket(InetAddress.getByName(host), kafkaPort)) match {
      case Failure(_) => "NotAvailable"
      case Success(_) => "Available"
    }
  }

  private[vasapi] def createTopic(name: String): Unit = {
    EmbeddedKafka.createCustomTopic(name) match {
      case Success(_) => logInfo("successfully created topic")
      case Failure(f) =>
        logInfo(s"topic creation failed due to: ${f.getMessage}")
    }
  }

  /** Creates a topic in this embedded kafka instance and populates some data
    * into it. The data can be of type [[String]] or [[Array]] of [[Byte]]
    * @param name
    *   topic name
    * @param data
    *   initial data loaded into topic
    */
  private[vasapi] def initTopic[T](
      name: String,
      data: Option[Map[String, T]]
  ): Unit = {

    createTopic(name)

    // initial fill is optional
    data.foreach { m =>
      for {
        (key, value) <- m
      } yield {
        value match {
          case v: String =>
            val record = new ProducerRecord[String, String](name, key, v)
            EmbeddedKafka.publishToKafka(record)
          case v: Array[Byte] =>
            val record = new ProducerRecord[String, Array[Byte]](name, key, v)
            EmbeddedKafka.publishToKafka(record)
        }
      }
    }
  }

  /** like initTopic() but takes a dataframe and uses Spark's avro mechanism to
    * serialize it to avro and send it to the topic
    * @param name
    *   topic name
    * @param data
    *   [[DataFrame]] to be produced to kafka to topic
    */
  private[vasapi] def initAvroTopic(name: String, data: DataFrame): Unit = {
    import org.apache.spark.sql.avro.functions._
    import org.apache.spark.sql.functions.{struct, col}

    createTopic(name)

    val avroSchema: String = VasapiSchemaUtils.createSchemaStringFromAvsc(
      "src/test/resources/test-schemas/lotr_test.avsc"
    )

    data
      .select(to_avro(struct(data.columns.map(col): _*), avroSchema) as "value")
      .write
      .format("kafka")
      .option("kafka.bootstrap.servers", s"localhost:$kafkaPort")
      .option("topic", s"$name")
      .save()
  }
}

/** companion object
  */
object KafkaFixture {
  def apply(kafkaPort: Int, zookeeperPort: Int): KafkaFixture = {
    new KafkaFixture(kafkaPort: Int, zookeeperPort: Int)
  }
}
