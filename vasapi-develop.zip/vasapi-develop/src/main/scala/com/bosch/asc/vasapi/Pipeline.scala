/*
 * Copyright (c) 2018-2023 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */

package com.bosch.asc.vasapi

import com.bosch.asc.environment.SparkConfig
import com.bosch.asc.vasapi.conf._
import com.bosch.asc.vasapi.udf.{CommonUDF, RuntimeUDF}
import com.bosch.asc.vasapi.utils.VasapiConfUtils
import org.apache.spark.internal.Logging
import org.apache.spark.sql.SparkSession
import org.slf4j.MDC
import pureconfig.ConfigSource
import pureconfig.generic.auto._

/** Pipeline object serves as the entry point for the Vasapi application.
  * initializes Spark, reads Vasapi configuration, processes inits block,
  * registers UDFs, and registers queries.
  *
  * @note
  *   Requires Apache Spark for DataFrame operations.
  */
object Pipeline extends Logging {

  /** Entry point to the pipeline
    *
    * @param args:
    *   possible command line arguments as an array of strings
    */
  def main(args: Array[String]): Unit = {
    logInfo("starting vasapi application")
    // determine vasapi config source and read it accordingly
    val vasapiConfig = readVasapiConfig(args.headOption)
    logInfo("vasapi configuration loaded")
    // process vasapi configuration

    // initialize Spark Session for this application
    implicit val spark: SparkSession = SparkSession
      .builder()
      .config(SparkConfig())
      .enableHiveSupport()
      .getOrCreate()

    this.addContextInfoToLogs()
    this.registerUDFs(vasapiConfig)
    this.runVasapiInits(vasapiConfig)
    this.registerQueries(vasapiConfig.queries)
    logInfo("vasapi configuration processed. streams started.")

    // shutting down vasapi on sigterm
    // VasapiShutdownHook.install(spark.streams)
    if (!spark.streams.active.isEmpty) {
      spark.streams.awaitAnyTermination()
    }
    logInfo("Vasapi shutting down because at least one stream stopped.")
  }

  /** attempts to read a Vasapi configuration through pureconfig's conf loading
    * mechanism. If confLocator is None, the default configuration is used.
    * Check the pureconfig documentation for how default configurations are
    * loaded.
    *
    * Otherwise, attempts to load the config from a resource (file, resource,
    * url).
    *
    * @param confLocator
    *   location of the configuration
    * @return
    *   [[Vasapi]] object
    */
  def readVasapiConfig(confLocator: Option[String]): Vasapi = {
    val conf = {
      confLocator match {
        case None =>
          logInfo("No configuration specified, using default configuration")
          ConfigSource.default.load[Vasapi]

        case Some(arg) =>
          logInfo(s"Attempting to load vasapi config from: $arg")
          VasapiConfUtils.readConfFromLocator(arg)
      }
    }
    conf match {
      case Left(ex)          => throw new RuntimeException(ex.toList.toString())
      case Right(vasapiConf) => vasapiConf
    }
  }

  /** Method to fetch the application ID and application name from sparkContext
    * and put it in MDC (Mapped Diagnostic Context) as key-value pairs which can
    * then be used to enrich log messages with contextual information.
    *
    * @param spark
    *   a Spark Session object
    */
  def addContextInfoToLogs()(implicit spark: SparkSession): Unit = {
    val appId = spark.sparkContext.applicationId
    MDC.put("applicationid", appId)
    val appName = spark.sparkContext.appName
    MDC.put("applicationname", appName)
    val MDCListener = new SparkStreamingListenerMDC(spark)
    spark.streams.addListener(MDCListener)
  }

  /** Method to process the inits block of a vasapi configuration. Works by
    * means of dynamic dispatching of register() method calls to the class
    * corresponding to the current type
    *
    * @param config
    *   a Vasapi configuration object
    * @param spark
    *   a Spark Session object
    */
  def runVasapiInits(config: Vasapi)(implicit spark: SparkSession): Unit = {
    config.inits.foreach(_.foreach(_.register))
    logInfo("inits block processed")
  }

  /** method to register all custom UDFs from vasapi config.
    */
  def registerRuntimeUDFs(
      config: Vasapi
  )(implicit spark: SparkSession): Unit = {

    // Load and register on runtime defined UDFs from configuration
    config.udfs.foreach(udfs => {
      for ((name, term) <- udfs) {
        val udf = RuntimeUDF.createTypedUdf(term)
        spark.udf.register(name, udf)
        logInfo(s"Registered Runtime UDF: $name")
      }
    })
  }

  /** method to register all UDFs (pre-defined common UDFs as well as custom
    * UDFs from vasapi config).
    */
  def registerUDFs(config: Vasapi)(implicit spark: SparkSession): Unit = {
    CommonUDF.register()
    registerRuntimeUDFs(config)
    logInfo("UDFs registration done")
  }

  /** method to register all queries defined in the vasapi configuration. This
    * includes all sources, intermediate views (containing data transformations)
    * and sinks. Specifying sinks will also start the related streaming queries.
    */
  def registerQueries(
      queries: List[Query]
  )(implicit spark: SparkSession): Unit = {
    logDebug(s"registering ${queries.length} queries: ${queries.map(_.name)}")
    queries.foreach { q =>
      logDebug(s"registering query: ${q.name}")
      q.register
    }
    logInfo("queries registration done")
  }
}
