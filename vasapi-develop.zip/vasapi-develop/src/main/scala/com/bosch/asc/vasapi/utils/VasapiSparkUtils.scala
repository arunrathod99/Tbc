/*
 * Copyright (c) 2018-2024 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */

package com.bosch.asc.vasapi.utils

import scala.util.{Failure, Success, Try}
import org.apache.spark.sql.SparkSession
import org.apache.spark.internal.Logging

object VasapiSparkUtils extends Logging {

  def dropTempView(name: String, spark: SparkSession): Unit = {
    // drop the temp view if it exists to make sure we can register the test source
    Try {
      spark.catalog.dropTempView(name)
    } match {
      case Success(_) => logInfo(s"dropped temp view $name successfully")
      case Failure(_) =>
        logInfo(
          "encountered error while dropping view, probably because it does not exist"
        )
    }
  }

}
