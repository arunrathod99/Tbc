/*
 * Copyright (c) 2018-2024 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */

package com.bosch.asc.vasapi.utils

import com.bosch.asc.utils.PasswordHandler
import com.databricks.sdk.scala.dbutils.DBUtils

import scala.util.Try

/** sealed family representing possible secret types, their attributes &
  * decryption methods Extend this trait to add further supported secret
  * backends to vasapi.
  *
  * Currently supports:
  *   - [[PasswordHandler]] based on
  *     [[https://tinyurl.com/bdz89a6t Hadoop CredentialProvider API]]
  *   - Databricks Secret Scopes based on
  *     [[https://github.com/databricks/databricks-dbutils-scala databricks-db-utils-scala]]
  */
sealed trait Credential {
  override def toString: String = super.toString
  def decryptSecret: Try[String]
}

/** JCEKSSecret case class to represent a secret stored in a JCEKS keystore.
  * @param jceksPath
  *   path to the JCEKS keystore
  * @param pwdAlias
  *   alias of the password in the keystore
  */
final case class JCEKSSecret(
    jceksPath: String,
    pwdAlias: String
) extends Credential {

  override def toString: String =
    s"JCEKSSecret (jceksPath: $jceksPath, pwdAlias: $pwdAlias)"

  override def decryptSecret: Try[String] = {
    Try {
      new PasswordHandler(
        jceksPath,
        pwdAlias
      ).password
    }
  }
}

/** DatabricksSecret case class to represent a secret stored in a Databricks
  * secret scope.
  * @param secretScope
  *   secret scope name
  * @param secretKey
  *   secret key name
  */
final case class DatabricksSecret(
    secretScope: String,
    secretKey: String
) extends Credential {

  override def toString: String =
    s"DatabricksSecret (scope: $secretScope, key: $secretKey)"

  override def decryptSecret: Try[String] = {
    /*
    getDBUtils can be instantiated with custom config, but not used here. Instead rely on default config.
    This works only within a Databricks environment.
     */
    Try {
      val dbutils = DBUtils.getDBUtils()
      dbutils.secrets.get(scope = secretScope, key = secretKey)
    }
  }
}
