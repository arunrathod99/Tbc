/*
 *  Copyright (c) 2023 Robert Bosch GmbH and its subsidiaries.
 *  This program and the accompanying materials are made available under
 *  the terms of the Bosch Internal Open Source License v4
 *  which accompanies this distribution, and is available at
 *  http://bios.intranet.bosch.com/bioslv4.txt
 */

package com.bosch.asc.vasapi.conf.sources

import com.bosch.asc.vasapi.utils.{VasapiSchemaUtils, VasapiConfUtils}
import com.bosch.asc.vasapi.conf.Source
import org.apache.spark.internal.Logging
import org.apache.spark.sql.avro.functions.from_avro
import org.apache.spark.sql.functions.{col, from_json}
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.{DataFrame, Dataset, SparkSession}

import scala.collection.JavaConverters._

/** case classes and companion objects modelling kafka messages. Each message
  * has a number of fields as specified in the
  * [[https://spark.apache.org/docs/latest/structured-streaming-kafka-integration.html Spark docs]].
  * TODO: include headers
  */
final case class KafkaStringMessage(
    offset: Long,
    timestamp: java.sql.Timestamp,
    topic: String,
    key: String,
    value: String,
    partition: Int,
    timestampType: Int
    // headers: Array[(String, Array[Byte])]
)

case object KafkaStringMessage {
  // generate StructType from case class definition
  val msgSchema: StructType =
    org.apache.spark.sql.Encoders.product[KafkaStringMessage].schema
}

final case class KafkaByteMessage(
    offset: Long,
    timestamp: java.sql.Timestamp,
    topic: String,
    key: Array[Byte],
    value: Array[Byte],
    partition: Int,
    timestampType: Int
    // headers: Array[(String, Array[Byte])]
)

case object KafkaByteMessage {
  // generate StructType from case class definition
  val msgSchema: StructType =
    org.apache.spark.sql.Encoders.product[KafkaByteMessage].schema
}

/** Models a vasapi / spark kafka source. Can handle batch and streaming
  * sources. Json and Avro serialization formats are supported. Special case of
  * a generic [[Source]]. Due to pureconfig automatic reader derivation
  * limitations, composition instead of inheritance is used to pass properties
  * from the generic [[Source]] down to the KafkaSource.
  * @param s
  *   related [[Source]] object
  */
class KafkaSource(s: Source) extends Logging {

  // column name if spark encounters corrupt records during parsing
  private val columnNameOfCorruptRecord: String = "corrupt_records"

  /** Creates a Dataframe from a Kafka batch source including schema handling.
    *
    * @param spark
    *   SparkSession
    * @return
    *   Kafka batch DataFrame
    */
  def loadKafkaBatch(implicit spark: SparkSession): DataFrame = {

    val kafkaDataFrame = spark.read
      // hardcode kafka, otherwise kafkaBatch is used which throws an error
      .format("kafka")
      .options(VasapiConfUtils.getValidOptionsByFormat(s))
      .load()

    parseMessagesWithSchema(kafkaDataFrame)
  }

  /** Registers a Kafka streaming source with optional schema. Handles JSON and
    * Avro serialization formats. Note that when avro serialization is chosen,
    * the value field is maintained as a byte array.
    *
    * @param spark
    *   SparkSession
    */
  def loadKafkaStream(implicit spark: SparkSession): DataFrame = {

    val kafkaDataFrame = spark.readStream
      .format(s.format)
      .options(VasapiConfUtils.getValidOptionsByFormat(s))
      .load()

    parseMessagesWithSchema(kafkaDataFrame)
  }

  /** applies a format specific (json or avro) schema to a
    * [[org.apache.spark.sql.DataFrame]] if one is specified for this
    * [[Source]].
    *
    * If a schema for this [[Source]] object is given, the resulting
    * [[org.apache.spark.sql.DataFrame]] has this schema, otherwise the message
    * remains in a column called value (as is the default for reading data from
    * Kafka).
    *
    * In both cases, the remaining default fields that each Kafka message has
    * (key, topic, partition, timestamp, timestampType) are added to the
    * [[org.apache.spark.sql.DataFrame]]
    *
    * If this [[Source]] has no serialization format defined, json is used as
    * the default. When explicitly passed, only json and avro are permissible as
    * serialization formats. Both can be read with our without schema based
    * record parsing.
    *
    * @param df
    *   [[org.apache.spark.sql.DataFrame]]
    * @return
    *   a [[org.apache.spark.sql.DataFrame]] containing either parsed or
    *   unparsed messages including additional message fields (key,
    *   partition,...)
    */
  private[sources] def parseMessagesWithSchema(
      df: DataFrame
  )(implicit spark: SparkSession): DataFrame = {

    s.serialization match {
      case Some("json") =>
        val ds: Dataset[KafkaStringMessage] = KafkaSource.parseKafkaStringDF(df)
        makeDataFrameFromJson(ds)

      case Some("avro") =>
        val ds: Dataset[KafkaByteMessage] = KafkaSource.parseKafkaByteDF(df)
        makeDataFrameFromAvro(ds)

      case Some(_) =>
        logWarning(
          "serialization formats other than json or avro cannot be used with a fixed schema - returning dataframe with default Kafka schema (see spark docs)"
        )
        df

      case None =>
        logInfo(
          "no serialization format for source specified - returning dataframe with default Kafka schema (see spark docs)"
        )
        df
    }
  }

  /** applies this KafkaSource's schema to a
    * [[org.apache.spark.sql.Dataset[KafkaStringMessage]]]. If this source has a
    * schema defined, the Kafka record's value column is parsed into this
    * schema. All resulting columns are added to the final dataframe. The
    * initial columns (value, key, offset etc) are retained. A column containing
    * corrupt records found during parsing is added.
    *
    * @param ds
    *   [[org.apache.spark.sql.Dataset]] containing records of type
    *   [[KafkaByteMessage]]
    * @return
    *   [[org.apache.spark.sql.DataFrame]] containing the parsed records
    */
  private[conf] def makeDataFrameFromJson(
      ds: Dataset[KafkaStringMessage]
  ): DataFrame = {
    s.createSourceSchema(s.ddlSchema, s.jsonSchemaFile) match {
      case Some(schemaStruct) =>
        val jsonParsingOptions: Map[String, String] = Map(
          "mode" -> "PERMISSIVE",
          "columnNameOfCorruptRecord" -> columnNameOfCorruptRecord
        )
        val schema: StructType = schemaStruct.add(
          StructField(columnNameOfCorruptRecord, StringType, nullable = true)
        )
        val cols = "parsed.*" :: KafkaStringMessage.msgSchema.fieldNames.toList

        logInfo(
          s"Registering Kafka source with JSON serialization for $s.name; schema: $schema"
        )

        ds
          .withColumn(
            "parsed",
            from_json(ds("value"), schema, jsonParsingOptions)
          )
          .select(cols.map(col): _*)

      case None => ds.toDF()
    }
  }

  /** applies this KafkaSource's schema to a [[Dataset[KafkaByteMessage]]]. If
    * this source has a schema defined, the Kafka record's value column is
    * parsed into this schema. All resulting columns are added to the final
    * dataframe. The initial columns (value, key, offset etc) are retained. A
    * column containing corrupt records found during parsing is added. TODO: fix
    * & add corrupt records column
    * @param ds
    *   [[Dataset]] containing records of type [[KafkaByteMessage]]
    * @return
    *   [[org.apache.spark.sql.DataFrame]] containing the parsed records
    */
  private[conf] def makeDataFrameFromAvro(
      ds: Dataset[KafkaByteMessage]
  ): DataFrame = {
    logInfo(
      s"Registering Kafka stream source with avro serialization for $s.name"
    )

    s.avroSchemaFile match {
      case Some(f) =>
        val avsc: String = VasapiSchemaUtils.createSchemaStringFromAvsc(f)
        val kafkaParsingOptions: Map[String, String] = Map(
          "mode" -> "PERMISSIVE",
          "columnNameOfCorruptRecord" -> columnNameOfCorruptRecord
        )
        val cols: List[String] =
          "parsed.*" :: KafkaByteMessage.msgSchema.fieldNames.toList

        // using spark's default options for avro records, see here: https://spark.apache.org/docs/latest/sql-data-sources-avro.html
        ds
          .withColumn(
            "parsed",
            from_avro(
              ds("value"),
              jsonFormatSchema = avsc,
              options = kafkaParsingOptions.asJava
            )
          )
          .select(cols.map(col): _*)

      case None => ds.toDF()
    }
  }
}

object KafkaSource {
  def apply(s: Source): KafkaSource = new KafkaSource(s)

  /** helper function to parse a generic dataframe into a dataset of type
    * [[KafkaStringMessage]]
    *
    * part of companion object to enable static-like access to this method
    *
    * @param df
    *   input [[org.apache.spark.sql.DataFrame]]
    * @param spark
    *   implicit [[org.apache.spark.sql.SparkSession]]
    * @return
    *   a dataset of type [[KafkaStringMessage]]
    */
  def parseKafkaStringDF(
      df: DataFrame
  )(implicit spark: SparkSession): Dataset[KafkaStringMessage] = {
    import spark.implicits._

    df
      .selectExpr(
        "CAST(offset AS BIGINT)",
        "CAST(timestamp AS TIMESTAMP)",
        "CAST(topic AS STRING)",
        "CAST(key AS STRING)",
        "CAST(value AS STRING)",
        "CAST(partition AS INT)",
        "CAST(timestampType AS INT)"
      )
      .as[KafkaStringMessage]
  }

  /** helper function to parse a generic dataframe into a typed dataset where
    * the 'value' column is a byte array.
    *
    * part of companion object to enable static-like access to this method
    *
    * @param df
    *   input [[org.apache.spark.sql.DataFrame]]
    * @param spark
    *   implicit [[org.apache.spark.sql.SparkSession]]
    * @return
    *   a dataset of type [[KafkaByteMessage]]
    */
  def parseKafkaByteDF(
      df: DataFrame
  )(implicit spark: SparkSession): Dataset[KafkaByteMessage] = {
    import spark.implicits._

    df
      .selectExpr(
        "offset",
        "timestamp",
        "topic",
        "key",
        "value",
        "partition",
        "timestampType"
      )
      .as[KafkaByteMessage]
  }
}
