/*
 *  Copyright (c) 2024 Robert Bosch GmbH and its subsidiaries.
 *  This program and the accompanying materials are made available under
 *  the terms of the Bosch Internal Open Source License v4
 *  which accompanies this distribution, and is available at
 *  http://bios.intranet.bosch.com/bioslv4.txt
 */

package com.bosch.asc.vasapi.conf.sinks

import com.bosch.asc.vasapi.utils.VasapiConfUtils
import com.bosch.asc.vasapi.conf.Sink
import org.apache.spark.internal.Logging
import org.apache.spark.sql.{DataFrameWriter, Row, SparkSession}

/** S3Sink class to write batch Dataframes to an object store with a s3a
  * interface
  * @param s
  *   [[Sink]] object - passed via constructor injection due to pureconfig
  *   limitations
  * @param spark
  *   [[SparkSession]] to register dataframe
  */
class S3Sink(sink: Sink, spark: SparkSession) extends Logging {

  val s3Options: Map[String, String] =
    VasapiConfUtils.getValidOptionsByFormat(sink)
  val s3Coordinates: String =
    s"""s3a://${s3Options.getOrElse("bucketName", "")}/${s3Options.getOrElse(
        "filePrefix",
        ""
      )}"""

  /** Registers a S3 sink
    */
  def execute(): Unit = {
    logInfo("registering S3 sink")

    val df = sink.registerDF(spark)
    val dfWriter: DataFrameWriter[Row] = sink.partitionBy match {
      case Some(partitionBy) => df.write.partitionBy(partitionBy: _*)
      case None              => df.write
    }

    dfWriter
      .format("parquet")
      .options(s3Options)
      .mode(sink.outputMode.getOrElse("append"))
      .save(s3Coordinates)

    logInfo(s"done writing to S3 sink: $s3Coordinates")
  }

}
