/*
 * Copyright (c) 2009, 2018 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */
package com.bosch.asc.utils

import com.bosch.asc.environment.HadoopEnvironment
import org.apache.hadoop.security.alias.CredentialProviderFactory

/** The `PasswordHandler` class is responsible for receiving a decrypted
  * password from a file that contains the encrypted version. It extends the
  * `HadoopEnvironment` trait to utilize Hadoop configuration settings for
  * credential management.
  *
  * Makes use of the:
  * [[https://tinyurl.com/bdz89a6t Hadoop CredentialProvider API]].
  *
  * @param jceksPath
  *   Path where the encrypted version of the password is stored.
  * @param passwordAlias
  *   Alias for the encrypted password.
  *
  * @note
  *   The `PasswordHandler` uses Hadoop's `Configuration` to set the credential
  *   provider path, allowing it to retrieve and decrypt the password from the
  *   specified JCEKS file
  */
class PasswordHandler(jceksPath: String, passwordAlias: String)
    extends HadoopEnvironment {

  hadoopConf.set(CredentialProviderFactory.CREDENTIAL_PROVIDER_PATH, jceksPath)
  val password: String = hadoopConf.getPassword(passwordAlias).mkString

}
