/*
 * Copyright (c) 2018-2024 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */

package com.bosch.asc.vasapi.utils

import org.apache.spark.sql.avro.SchemaConverters
import org.apache.spark.sql.types.{DataType, StructType}
import org.apache.spark.internal.Logging

import java.io.IOException
import scala.util.{Failure, Success, Try}

object VasapiSchemaUtils extends Logging {

  /** A helper method to safely read a json schema file and convert it into a
    * StructType for usage in Spark
    *
    * @param schemaLocator
    *   File containing the JSON schema.
    * @return
    *   JSON schema converted to StructType.
    * @throws IOException
    *   If the JSON schema file could not be found.
    * @throws IllegalArgumentException
    *   If the JSON schema is not a valid Spark schema json representation
    */
  def createStructTypeFromJsonSchema(schemaLocator: String): StructType = {

    VasapiFileUtils.safeFileOrResourceToString(schemaLocator) match {
      case Success(schemaString) =>
        Try(DataType.fromJson(schemaString)) match {
          case Success(schema: StructType) =>
            logInfo("Successfully parsed JSON schema to Spark StructType")
            schema
          case Success(_) =>
            val errorMsg = "Parsed JSON schema is not a StructType"
            logError(errorMsg)
            throw new IOException(errorMsg)
          case Failure(ex) =>
            val errorMsg = "Parsed JSON schema is not a StructType"
            logError(errorMsg + ex)
            throw ex
        }
      case Failure(e) =>
        logError(s"schema file could not be found: $e")
        throw e
    }
  }

  /** Safely loads an Avro schema from an AVSC file into a string
    *
    * @param avscFileName
    *   File holding the Avro schema.
    * @return
    *   a schema expressed as [[org.apache.spark.sql.types.StructType]]
    * @throws IOException
    *   If the Avro schema file could not be found
    */
  def createSchemaStringFromAvsc(avscFileName: String): String = {

    VasapiFileUtils.safeFileToString(avscFileName) match {
      case Success(schemaString) =>
        new org.apache.avro.Schema.Parser().parse(schemaString).toString()

      case Failure(e: IOException) =>
        logError("avro schema file could not be found")
        throw e
      case Failure(e) =>
        throw e
    }
  }

  /** utility method to create a [[org.apache.spark.sql.types.StructType]]
    * schema from an avro schema stored in a file.
    *
    * @param avscFileName
    *   file holding the avro schema
    * @return
    *   a schema expressed as [[org.apache.spark.sql.types.StructType]]
    * @throws IOException
    *   If the Avro schema file could not be found.
    */
  def createStructTypeFromAvsc(avscFileName: String): StructType = {
    VasapiFileUtils.safeFileToString(avscFileName) match {
      case Success(schemaString) =>
        val avroSchema = new org.apache.avro.Schema.Parser().parse(schemaString)

        val structType = SchemaConverters.toSqlType(avroSchema).dataType match {
          case stype: StructType => stype
          case _ =>
            logError("could not create StructType from avro schema")
            throw new IOException()
        }
        structType

      case Failure(e: IOException) =>
        logError("json schema file could not be found")
        throw e
      case Failure(e) =>
        throw e
    }
  }

}
