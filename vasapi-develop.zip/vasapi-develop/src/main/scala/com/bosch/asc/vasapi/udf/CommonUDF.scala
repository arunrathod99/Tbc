/*
 * Copyright (c) 2009, 2018 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */

package com.bosch.asc.vasapi.udf

import org.apache.commons.codec.binary.Base64.decodeBase64
import org.apache.commons.io.FileUtils
import org.apache.spark.internal.Logging
import org.apache.spark.sql.Row
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions.udf
import org.everit.json.schema.loader.SchemaLoader
import org.everit.json.schema.{ValidationException, Schema => EveritSchema}
import org.json.{JSONObject, JSONTokener}
import org.json4s.JsonAST.{JArray, JObject, JValue}
import org.json4s.Xml.toJson
import org.json4s.jackson.JsonMethods
import org.json4s.jackson.JsonMethods.{compact, render}

import java.io.{ByteArrayInputStream, File}
import java.sql.Timestamp
import java.time.format.DateTimeFormatter
import java.time.temporal.TemporalAccessor
import java.time.{Instant, LocalDateTime, OffsetDateTime, ZoneOffset}
import java.util.Base64
import java.util.zip.GZIPInputStream
import scala.util.{Failure, Success, Try, Using}
import javax.xml.XMLConstants
import javax.xml.transform.stream.StreamSource
import javax.xml.validation.{Schema, SchemaFactory}
import scala.collection.immutable.ListMap
import scala.language.postfixOps
import scala.util.matching.Regex

/** Most common and tested UDF's
  *
  * This object summarizes all commonly used UDF's and provides an interface for
  * testing them.
  */
object CommonUDF extends VasapiUDF with Logging {

  /** Helper function to validate a JSON string against a JSON schema file.
    *
    * This function reads the JSON schema from the specified file, validates the
    * given JSON string against the schema, and logs the validation result.
    *
    * @param jsonString
    *   The JSON string to be validated.
    * @param jsonSchemaFile
    *   The path to the JSON schema file in the local filesystem.
    * @return
    *   Try[Unit] containing a Success if validation succeeds, otherwise exact
    *   exception.
    */
  private def validateJsonHelper(
      jsonString: String,
      jsonSchemaFile: String
  ): Try[Unit] = {
    Try {
      val schema_file = new File(jsonSchemaFile)
      val schemaString = FileUtils.readFileToString(schema_file, "UTF-8")
      val jsonSchema = new JSONObject(new JSONTokener(schemaString))
      val jsonObject = new JSONObject(new JSONTokener(jsonString))
      val schema: EveritSchema = SchemaLoader.load(jsonSchema)

      logDebug(
        s"Attempting schema validation for json Obj: ${jsonObject.toString()}"
      )
      schema.validate(jsonObject)
    }
  }

  /** Helper function to validate a XML message against a XSD file.
    *
    * This function reads the XML Schema from specified XSD file, validates the
    * given XML message string against the schema, and logs the validation
    * result.
    *
    * @param message
    *   The XML message to be validated.
    * @param schemaFile
    *   The path to the XSD file in the local filesystem.
    * @return
    *   Try[Unit] containing a Success if validation succeeds, otherwise exact
    *   exception.
    */

  private[vasapi] def xmlSchemaValidationHelper(
      message: String,
      schemaFile: String
  ): Try[Unit] = {
    Try {
      val schemaFactory =
        SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI)
      val xsd_file = new File(schemaFile)
      val schema: Schema = schemaFactory.newSchema(xsd_file)
      val inputStream = new ByteArrayInputStream(message.getBytes())
      logDebug(s"Attempting schema validation for : ${inputStream.toString}")
      schema.newValidator().validate(new StreamSource(inputStream))
    }
  }

  /** Helper function to decompress the message
    * @param msg
    *   the message to be decompressed
    * @return
    *   the (decompressed) message as a String
    */
  private[vasapi] def decompressHelper(msg: Array[Byte]): Try[String] = {
    // see: https://www.scala-lang.org/api/2.13.6/scala/util/Using$.html
    Using.Manager { use =>
      val contentStream = use(new ByteArrayInputStream(msg))
      val unzippedStream = use(new GZIPInputStream(contentStream))
      logDebug("decompressing gzipped message")
      val decompressedMsg: String = scala.io.Source
        .fromInputStream(unzippedStream)
        .mkString // converts the unzipped stream into string

      decompressedMsg
    }
  }

  /** Commonly used UDF's defined in a collection for better registration in
    * Spark
    */
  val udfs: Map[String, UserDefinedFunction] = Map(
    /* used in Webscada template, Converts the input string to a UUID
     *
     * @param s : string
     * @return : string
     */
    "uuidFromString" -> udf((s: String) =>
      java.util.UUID.nameUUIDFromBytes(s.getBytes).toString
    ),

    /* used in Webscada template, Calculates the sum of a specified column from an array of structs.
     *
     * @param row : The input sequence of Row objects representing the array of structs
     * @param col : The name of the column to sum within each struct
     * @return The sum of the specified column from all structs in the array
     */
    "sumStructArrayEntry" -> udf((row: Seq[Row], col: String) =>
      row.map(struct => struct.getAs[Long](col)).sum
    ),

    /* used in Webscada template, Returns the count of elements in a sequence of StructType based on a given column and constant value.
     *
     * @param row The input sequence of Row containing StructType elements
     * @param col The column name to filter within each StructType element
     * @return The count of elements matching the column and constant value
     */
    "filteredStructArrayCount" -> udf(
      (row: Seq[Row], col: String, const: Any) =>
        row.map(struct => struct.getAs[Any](col)).count(entry => entry == const)
    ),

    /* Converts a date string into an unformatted timestamp
     *
     * @param dateStr The date string to be parsed
     * @return An unformatted timestamp if the input is not null, otherwise null
     */
    "getTimestampUnformatted" -> udf((dateStr: String) => {
      val resultDateFormat = "yyyy-MM-dd:HH:mm:ss.n XXX"
      var valueToReturn: Option[Timestamp] = None
      if (dateStr != null) {
        val formatter: DateTimeFormatter =
          DateTimeFormatter.ofPattern(resultDateFormat)
        val accessor: TemporalAccessor = formatter.parse(dateStr)
        valueToReturn = Some(
          Timestamp.valueOf(
            Instant.from(accessor).atZone(ZoneOffset.UTC).toLocalDateTime
          )
        )
      }
      valueToReturn.orNull
    }),

    /* Converts a date string into UTC timestamp
     * first it will filter based on accepted timestamp formats
     * then will parse with the input format with offset
     * if input value doesn't have offset, then
     * from the second input date string, it will extract the offset part
     * then UTC conversion will be happen
     * @param dateValue The date value to be convert into UTC
     * @param dateValueForOffset The date value to get offset
     * @return UTC timestamp if the input is not null, otherwise null
     */

    "getUTCTimestamp" -> udf(
      (dateValue: String, dateValueForOffset: String) => {
        val inputValue = Option(dateValue)
        val utcValue: String =
          inputValue match {
            case Some(dateValue) =>
              /* Input formats for all kind of correct timestamp format */
              val inputFormatWithOffset: DateTimeFormatter =
                DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss[.n]XXX")
              val inputFormatWithOutOffset: DateTimeFormatter =
                DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss[.n]")

              /* Filtering the input dates which doesn't match the correct format as mentioned above */
              if (
                Try(
                  LocalDateTime.parse(dateValue, inputFormatWithOffset)
                ).isSuccess || Try(
                  LocalDateTime.parse(dateValue, inputFormatWithOutOffset)
                ).isSuccess
              ) {
                /*
                 * parsing as per the defined format for input value
                 * if input comes with offset it will be parsed as per the defined input format
                 * if input comes without offset then append with the offsetValue
                 */
                val parsedInput: TemporalAccessor = {
                  Try(OffsetDateTime.parse(dateValue)) match {
                    case Success(parsedInput) => parsedInput
                    case Failure(ex) =>
                      logWarning(
                        s"parsing failed with exception: $ex as input format: $dateValue doesn't have offset"
                      )
                      val offsetValue: String = OffsetDateTime
                        .parse(dateValueForOffset)
                        .getOffset
                        .toString
                      OffsetDateTime.parse(dateValue.concat(offsetValue))
                  }
                }
                /* convert into UTC value */
                Timestamp
                  .valueOf(
                    Instant
                      .from(parsedInput)
                      .atZone(ZoneOffset.UTC)
                      .toLocalDateTime
                  )
                  .toString
              } else {
                logWarning(
                  s"parsing failed for input : $dateValue as it doesn't match with expected formats"
                )
                null
              }
            case None => null
          }
        utcValue
      }
    ),

    /* UDF to validate a JSON string against a JSON schema file
     *
     * @param jsonString     The JSON string to validate
     * @param jsonSchemaFile The path to the JSON schema file
     * @return true if the JSON string is valid according to the schema, false otherwise
     */
    "validateJson" -> udf((jsonString: String, jsonSchemaFile: String) => {
      validateJsonHelper(jsonString, jsonSchemaFile) match {
        case Success(_) =>
          logDebug("schema validation passed for json Obj")
          true
        case Failure(ex: ValidationException) =>
          logWarning(
            s"schema validation did not pass for json Obj: ${ex.toJSON.toString()}"
          )
          false
        case Failure(ex) =>
          logWarning(
            s"schema validation did not pass due to an unexpected problem: $ex"
          )
          false
      }
    }),

    /* UDF to validate a JSON string against a JSON schema file
     *
     * @param jsonString     The JSON string to validate
     * @param jsonSchemaFile The path to the JSON schema file
     * @return Success if the JSON string is valid according to the schema, error message otherwise
     */

    "validateJsonToString" -> udf(
      (jsonString: String, jsonSchemaFile: String) => {
        validateJsonHelper(jsonString, jsonSchemaFile) match {
          case Success(_) => "success"
          case Failure(ex: ValidationException) =>
            val errorMsg: String = ex.toJSON.toString()
            logWarning(
              "schema validation did not pass for json Obj"
            )
            errorMsg
          case Failure(ex) =>
            val errorMsg: String =
              "schema validation did not pass due to an unexpected problem"
            logWarning(errorMsg)
            ex.toString()
        }
      }
    ),

    /* used in MWS template, performs XML schema validation on a given message using the provided schema file.
     *
     * @param message    : The XML message to be validated
     * @param schemaFile : The path to the XML schema file used for validation
     * @return true if the validation passes, false otherwise
     */
    "xmlSchemavalidation" -> udf((message: String, schemaFile: String) => {
      xmlSchemaValidationHelper(message, schemaFile) match {
        case Success(_) =>
          logDebug("schema validation passed ")
          true
        case Failure(ex: org.xml.sax.SAXParseException) =>
          if (ex.getMessage.contains("cvc-")) {
            logWarning(
              s"schema validation did not pass for Obj: ${ex.getMessage}"
            )
          } else {
            logWarning(s"XML message is not a valid XML: ${ex.getMessage}")
          }
          false
        case Failure(ex) =>
          logWarning(
            s"schema validation did not pass due to an unexpected problem: $ex"
          )
          false
      }
    }),

    /* used in MWS template, validates either input message is in XML format or not
     *
     * @param message :XML format data
     * @return : boolean
     */
    "isValidXml" -> udf((message: String) => {
      Try(scala.xml.XML.loadString(message)) match {
        case Success(_) => true
        case Failure(_) => false
      }
    }),

    /*
     * used in MWS template, transforms input xml message into Json format.
     * should be paired with previous message / schema validation to make sure to only process valid records.
     *
     * @param message: XML format data
     * @return OutputJsonString: json format data
     */
    "parseXml" -> udf((message: String, xmlPattern: String) => {
      Try {
        val ScalaElem = scala.xml.XML.loadString(message)
        val JsonData = toJson(ScalaElem \\ xmlPattern)
        compact(render(JsonData))
      } match {
        case Success(jsonString) => jsonString
        case Failure(ex) =>
          logWarning(
            s"xml parsing and conversion to json failed for input: $message due to $ex"
          )
          "xml conversion failure"
      }
    }),

    /* used in MES template, returns the matching content from input message based on input table
     *
     * @param message :content column
     * @param table   : table name
     * @return : List
     */
    "selectFromTable" -> udf((message: String, table: String) => {
      if (message == null) {
        List[String]()
      } else {
        val tablePattern: Regex = ("table\\\":\\\"" + "[A-Z0-9\\_]+" + table).r
        val singleMessages = message.split("}\\{").map(e => "{" + e + "}")
        val tailPosition = singleMessages.length - 1
        singleMessages(tailPosition) = singleMessages(tailPosition)
          .substring(0, singleMessages(tailPosition).length - 1)
        singleMessages(0) = singleMessages(0).substring(1)
        singleMessages.toList.filter(tablePattern.findAllMatchIn(_).nonEmpty)
      }
    }),

    /* used in MES template, returns the result based the input dataType parameter
     *
     * @param dataType     : expected a double data type value
     * @param resultString : String format data
     * @param resultValue  : String format data
     * @return : String
     */
    "getResultColumn" -> udf(
      (dataType: Double, resultString: String, resultValue: String) => {
        if (Math.abs(dataType - 8.0d) < 0.00001d) {
          resultString
        } else {
          resultValue
        }
      }
    ),

    /* used in MES DP template, transforms input json keys to lowercase by visiting
     * all keys recursively. Values are kept unchanged.
     * see: [json4s library](https://github.com/json4s/json4s)
     * @param strjson: Json String
     * @return : String
     */
    "convertKeysToLower" -> udf((jsonString: String) => {
      val json: JValue = JsonMethods.parse(jsonString)

      /*
       * helper function to recurse through json structure
       * see json4s docs
       */
      def processJson(json: JValue): JValue = json match {
        // generic case --> a key value pair is a valid json object
        case JObject(fields) =>
          val lowercaseFields = fields.map { case (key, value) =>
            key.toLowerCase() -> processJson(value)
          }
          JObject(lowercaseFields)

        // special case --> a json array (which is not a subtype of JObject)
        case JArray(elements) =>
          JArray(elements.map(processJson))

        // base case --> a simple value is neither a JObject nor a JArray, but only a JValue (super type of both)
        case other =>
          other
      }

      val resultJson = processJson(json)
      compact(render(resultJson))
    }),

    /* used in radar template, returns String where the elements are ordered based on the integer values of index1
     * @param index1: array
     * @param value1: array
     * @return : String
     */
    "rotate_value" -> udf((index1: Seq[String], value1: Seq[String]) => {
      val df = index1.map(_.toInt) zip value1 toMap
      val sorted = ListMap(df.toSeq.sortBy(_._1): _*)
      sorted.values.mkString(",")
    }),

    /* Retrieves the sub-columns from the specified column. For each sub-column, it gets the corresponding hexadecimal value
     * then converts each hexadecimal to its ASCII equivalent then reverse it.
     * returns concatenated reversed ASCII string
     *
     * @param input column
     * @return concatenated reverse ASCII string
     */
    "processStructAndReverseHexToAscii" -> udf((input: Row) => {
      if (input != null) {
        val columns = input.schema.fieldNames.toSeq
        val HexBase = 16
        val concatenatedResult = columns.flatMap(colName => {
          val columnValue = Option(input.getAs[Long](colName))
          columnValue match {
            case Some(value) =>
              val hexString = value.toHexString
              val asciiCode = hexString
                .grouped(2)
                .map(hexPair => Integer.parseInt(hexPair, HexBase).toChar)
                .mkString("")
              Some(asciiCode.reverse) // Use Some to wrap non-null values
            case None =>
              None // Skip null values
          }
        })
        concatenatedResult.flatten
          .mkString("")
          .trim // Flatten the Option values and concatenate them
      } else {
        "" // Return an empty string for NULL input column
      }
    }),

    /* used in matdb template, returns String by inserting spaces between every two characters, and then encloses the whole string within square brackets
     * @param str: String
     * @return : String
     */
    "formatHexString" -> udf((str: String) => {
      if (str == null) {
        str
      } else {
        val StepBack = -2
        var input_str = str
        var idx = input_str.length - 2
        while (idx > 0) {
          input_str = input_str.patch(idx, " ", 0)
          idx += StepBack
        }
        input_str = "[" + input_str + "]"
        input_str
      }
    }),

    /* Decodes a Base64 encoded string into bytes.
     *
     * @param encodedString The Base64 encoded string
     * @return An array of decoded bytes
     */

    "decodeBase64" -> udf((encodedString: String) => {
      val decoder = Base64.getDecoder
      decoder.decode(encodedString)
    }),

    /* Decodes a Base64 encoded string into fixed-point numbers, considering
     * Big Endian encoding. Fixed-point numbers are essentially integers with a
     * decimal point moved to a specific position. The scale factor is used to
     * adjust the decimal position after decoding.
     *
     * Implementation details :
     *   - The bytes are grouped into sets of 4, as each set represents a
     *     32-bit integer.
     *   - ByteBuffer's wrap method is used to create a view of the byte array
     *     as an integer, with Big Endian ordering.
     *   - The integers are then divided by the scale factor to adjust the
     *     decimal position, and converted to doubles.
     *
     * @param encodedString
     *   The Base64 encoded string representing fixed-point numbers
     * @param scaleFactor
     *   The scale factor to divide the decoded integers by, adjusting their
     *   decimal position
     * @return
     *   An array of doubles representing the decoded fixed-point numbers
     */
    "encodedString2ArrayOfDoubles" -> udf(
      (encodedString: String, scaleFactor: Int) => {
        if (encodedString == null) {
          Array.empty[Double]
        } else {
          val decodedBytes = decodeBase64(encodedString)
          val doubleArray = decodedBytes
            .grouped(4)
            .map { bytes =>
              java.nio.ByteBuffer
                .wrap(bytes)
                .order(java.nio.ByteOrder.BIG_ENDIAN)
                .getInt
                .toDouble / scaleFactor
            }
            .toArray
          doubleArray
        }
      }
    ),

    /* takes a message and decompresses it if it is gzipped, otherwise
     * returns the message as is
     * @param message
     *   the message to be decompressed
     * @return
     *   the (decompressed) message as a String, as it is if the message is not
     *   able to decompress
     */
    "decompressGzippedMessage" -> udf((message: Array[Byte]) => {
      (for {
        msg <- Option(message)
        _ = logDebug("decompressing message")
        decompressedMsg <- decompressHelper(msg).toOption.orElse {
          logDebug("message is not gzipped - skipping decompression")
          Option(new String(msg))
        }
      } yield {
        decompressedMsg
      }).orNull
    })
  )
}
