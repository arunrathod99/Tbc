/*
 * Copyright (c) 2009, 2018 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */
package com.bosch.asc.vasapi.conf

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.streaming.StreamingQueryListener
import org.slf4j.MDC

/** Listener interface to extend logging information with header fields about
  * applicationid and appname.
  */
@SuppressWarnings(Array("EmptyMethodBlock"))
class SparkStreamingListenerMDC(spark: SparkSession)
    extends StreamingQueryListener {

  /** Invoked when a streaming query makes progress
    *
    * @param event
    *   QueryProgressEvent containing information about the query progress.
    */
  def onQueryStarted(event: StreamingQueryListener.QueryStartedEvent): Unit = {
    val appId = spark.sparkContext.applicationId
    MDC.put("applicationid", appId)
    val appName = spark.sparkContext.appName
    MDC.put("applicationname", appName)
  }

  /** Invoked when a streaming query makes progress. This method does not
    * perform any action.
    *
    * @param event
    *   QueryProgressEvent containing information about the query progress.
    */
  def onQueryProgress(
      event: StreamingQueryListener.QueryProgressEvent
  ): Unit = {
    // This method does not do anything
  }

  /** Invoked when a streaming query is terminated. This method does not perform
    * any action.
    *
    * @param event
    *   QueryTerminatedEvent containing information about the terminated query.
    */
  def onQueryTerminated(
      event: StreamingQueryListener.QueryTerminatedEvent
  ): Unit = {
    // This method does not do anything
  }
}
