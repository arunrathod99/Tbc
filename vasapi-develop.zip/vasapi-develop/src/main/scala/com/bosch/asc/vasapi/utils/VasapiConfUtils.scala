/*
 * Copyright (c) 2018-2024 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */

package com.bosch.asc.vasapi.utils

import com.bosch.asc.vasapi.Vasapi
import com.bosch.asc.vasapi.conf.{Query, Sink, Source}
import org.apache.spark.internal.Logging
import pureconfig.{ConfigObjectSource, ConfigReader, ConfigSource}
import pureconfig.generic.auto._

import scala.util.{Failure, Success, Try}

/** Various utility methods used for processing of configurations in Vasapi.
  */
object VasapiConfUtils extends Logging {

  private[utils] type SparkOption = Map[String, String]
  private[utils] type SparkCredentialOption = Map[String, Credential]

  /** takes a [[com.bosch.asc.vasapi.conf.Query]] object and applies source /
    * sink type specific conversions on its options attribute. This includes
    * mainly handling of secret providers and credentials.
    *
    * @param query
    *   [[com.bosch.asc.vasapi.conf.Source]] or
    *   [[com.bosch.asc.vasapi.conf.Sink]] to apply options to
    * @return
    *   a map of options with secret values decrypted and other format specific
    *   conversions applied. Returns options unchanged if the source / sink is
    *   not one of: avro, kafka, solace_source, solace_sink, s3
    */
  def getValidOptionsByFormat(
      query: Query
  ): SparkOption = {

    val defaultOpts = Map[String, String]()

    // options and secretOptions are optional, check if they contain anything
    // decrypt secrets if there are any
    // TODO: remove decrypted secrets from credentialOptions?
    val allOpts: SparkOption = getOpts(query).getOrElse(defaultOpts) ++
      decryptCredentialOpts(query).getOrElse(defaultOpts)

    // add any format specifics e.g. for avro
    (for {
      format <- getFormat(query)
    } yield format match {
      case "kafka" | "kafkaBatch" => handleKafkaOptions(allOpts)
      case "avro"                 => handleAvroOptions(allOpts)
      case "s3"                   => handleS3Options(allOpts)
      case _                      => allOpts
    }) match {
      case Some(opts) => opts
      case None       => allOpts
    }
  }

  private def getOpts(q: Query): Option[SparkOption] = {
    q match {
      case s: Source => s.options
      case s: Sink   => s.options
      case _         => None
    }
  }

  private def getFormat(q: Query): Option[String] = {
    q match {
      case s: Source => Some(s.format)
      case s: Sink   => Some(s.format)
      case _         => None
    }
  }

  /** attempts to decrypt all credentials in a query's secret options attribute
    * @param q
    *   vasapi [[Query]] object
    * @return
    *   optional [[SparkOption]] map containing the credentials that were
    *   successfully decrypted
    */
  private def decryptCredentialOpts(q: Query): Option[SparkOption] = {
    for {
      secretMap <- getSecretOpts(q)
    } yield {
      decryptSecrets(secretMap).collect({ case (key, Success(value)) =>
        key -> value
      })
    }
  }

  /** gets the secret options from a query if it's a source or a sink; returns
    * empty map otherwise
    * @param q
    *   vasapi [[Query]] object
    * @return
    */
  private def getSecretOpts(q: Query): Option[SparkCredentialOption] = {
    q match {
      case s: Source => s.credentialOptions
      case s: Sink   => s.credentialOptions
      case _         => Option(Map[String, Credential]())
    }
  }

  /** attempts to decrypt all credentials
    * @param credentials
    *   map of credentials
    * @return
    *   a [[Map]] containing a [[Try]] with the result of the decryption
    */
  private[utils] def decryptSecrets(
      credentials: SparkCredentialOption
  ): Map[String, Try[String]] = {
    logDebug("start decrypting credential opts")
    for {
      (key, value) <- credentials
    } yield {
      val decryptedCred = value.decryptSecret match {
        case Success(credential) =>
          logInfo(s"successfully decrypted secret for $key")
          Success(credential)
        case Failure(ex) =>
          logWarning(s"failed to decrypt secret for $key due to: $ex")
          Failure(ex)
      }
      key -> decryptedCred
    }
  }

  /** handles kafka options by adding jaas config for PLAIN sasl mechanism. For
    * any other security mechanisms, the options are returned unchanged.
    * @param options
    *   the options map
    * @return
    *   options map with jaas config added if PLAIN sasl mechanism is used
    */
  private[utils] def handleKafkaOptions(
      options: SparkOption
  ): SparkOption = {
    (for {
      mech <- options.get("kafka.sasl.mechanism")
      protocol <- options.get("kafka.security.protocol")
      username <- options.get("kafka.sasl.username")
      password <- options.get("kafka.sasl.password")
    } yield (mech, protocol, username, password) match {
      case ("PLAIN", "SASL_SSL", username, password) =>
        logInfo("setting up kafka sasl jaas config for PLAIN mechanism")
        val jaasConf =
          s"org.apache.kafka.common.security.plain.PlainLoginModule required username=$username password=$password;"
        options + ("kafka.sasl.jaas.config" -> jaasConf) - "kafka.sasl.username" - "kafka.sasl.password"
      case _ =>
        logInfo("no PLAIN sasl mechanism used - skipping jaas config")
        options
    }).getOrElse(options)
  }

  /** loads an avro schema file into a String and adds to options
    *
    * @param options
    *   the Avro source's options map
    * @return
    *   options map enriched with avro schema string if avro schema filed
    *   property set in options, returns unchanged options otherwise
    */
  private[utils] def handleAvroOptions(
      options: SparkOption
  ): SparkOption = {

    options.get("avroSchemaFile") match {
      case Some(avscFile) =>
        val avroSchemaString: String =
          VasapiSchemaUtils.createSchemaStringFromAvsc(avscFile)
        logInfo(s"loading avro schema from $avscFile")
        options + ("avroSchema" -> avroSchemaString)
      case None =>
        logInfo(
          "no avro schema passed for avro source - skipping schema loading"
        )
        options
    }
  }

  private[utils] def handleS3Options(
      options: SparkOption
  ): SparkOption = {
    if (containsS3PathParams(options)) {
      options
    } else {
      throw new IllegalArgumentException(
        "s3 sinks need bucketName and filePrefix defined"
      )
    }
  }

  /** predicate function to check whether a map contains a specific set of key
    * -> value pairs needed to form s3 output paths work (incl. empty strings)
    *
    * @param m
    *   map to check
    * @return
    *   boolean of result
    */
  private[utils] def containsS3PathParams(m: SparkOption): Boolean = {
    (m.get("bucketName"), m.get("filePrefix")) match {
      case (Some(bn), Some(fp)) => bn.nonEmpty && fp.nonEmpty
      case _                    => false
    }
  }

  /** attempts to instantiate pureconfig ConfigReaders from various sources.
    * Returns the first Source that could be successfully loaded. Priority is:
    *   - file
    *   - resource
    *   - url
    * @param locator
    *   String representing the file, resource or url
    * @return
    *   [[ConfigReader.Result]] of loading a [[Vasapi]] object
    */
  private[vasapi] def readConfFromLocator(
      locator: String
  ): ConfigReader.Result[Vasapi] = {
    val vasapiConfAttempts =
      loadSources(locator).zipWithIndex.map {
        // keep track of the index to log which source worked
        case (src, idx) => (idx, src.load[Vasapi])
      }

    // find the first successfully loaded conf (has type Right)
    val vasapiConf = vasapiConfAttempts.find(_._2.isRight)

    vasapiConf match {
      case Some(conf) =>
        val srcType: String = conf._1 match {
          case 0 => "file"
          case 1 => "resource"
          case 2 => "url"
        }
        logInfo(s"successfully loaded conf from $srcType")
        conf._2
      case None =>
        throw new NoSuchElementException(
          s"""configuration location was given but could not be resolved
        through pureconfig's file, resource or url mechanism. Errors are:
         ${vasapiConfAttempts
              .collect { case (_, failures) => failures }
              .toString()}
         """
        )
    }
  }

  /** attempts to load a configuration from a file, resource and url.
    * @param locator
    *   String representing the file, resource or url
    * @return
    *   List of [[ConfigObjectSource]] objects, each representing a source type.
    *   This can be used to iterate over the sources and load the configuration
    *   from the first successful source.
    */
  private def loadSources(locator: String): List[ConfigObjectSource] = {
    Try {
      new java.net.URL(locator)
    } match {
      case Success(url) =>
        ConfigSource.file(locator) :: ConfigSource.resources(
          locator
        ) :: ConfigSource.url(url) :: Nil
      case Failure(_) =>
        ConfigSource.file(locator) :: ConfigSource.resources(locator) :: Nil
    }
  }
}
