/*
 * Copyright (c) 2020, 2023 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */

package com.bosch.asc.vasapi

import com.bosch.asc.vasapi.conf._

import scala.reflect.ClassTag

/** Wrapper class containing all objects needed to set up a spark structured
  * streaming application.
  *
  * Objects of this class can be explicitly created, but its intended use is
  * rather in combination with [[https://pureconfig.github.io/ Pureconfig]].
  * This usage is displayed in [[com.bosch.asc.vasapi.Pipeline]] where
  * Pureconfig's config loader mechanisms are used to create a Vasapi object
  * from Hocon configuration file.
  *
  * Vasapi objects contain the following blocks:
  *   - inits (optional): code that needs to be run only once on application
  *     start, i.e. initial table creation
  *   - udfs (optional): definition of unser-defined functions (udf) to be
  *     registered in Spark
  *   - queries: contains [[com.bosch.asc.vasapi.conf.Source sources]],
  *     [[com.bosch.asc.vasapi.conf.View views]] and
  *     [[com.bosch.asc.vasapi.conf.Sink sinks]]; these represent the logical
  *     flow of the spark application, which reads input data from sources,
  *     applies a series of transformations (using spark sql views) and writing
  *     the transformed data to output sinks.
  *
  * @since 0.0.1
  */
final case class Vasapi(
    inits: Option[List[Initialization]],
    udfs: Option[Map[String, String]],
    queries: List[Query]
) {

  // TODO: should validation already run at Vasapi object creation?
  // TODO: figure out how E2E data transformation validation can be done

  // query collections
  val sources: List[Source] = filterQueriesByType[Source]()
  val views: List[View] = filterQueriesByType[View]()
  val sinks: List[Sink] = filterQueriesByType[Sink]()

  // initialization collections
  val allTables: List[BaseTable] =
    filterInitsByType[BaseTable]()

  val externalTbls: List[ExternalHiveTable] =
    filterInitsByType[ExternalHiveTable]()

  val icebergTbls: List[IcebergTable] =
    filterInitsByType[IcebergTable]()

  /** generic method to filter all [[Query]] by one of its subtypes
    * @tparam T
    *   type by which to filter, must be subtype of [[Query]]
    * @return
    *   List containing only elements of type T
    */
  private[vasapi] def filterQueriesByType[T <: Query: ClassTag](): List[T] = {
    this.queries flatMap {
      case q: T => Some(q)
      case _    => None
    }
  }

  /** generic method to filter all [[Initialization]] objects by one of its
    * subtypes
    * @tparam T
    *   type by which to filter, must be subtype of [[Initialization]]
    * @return
    *   List containing only elements of type T
    */
  private[vasapi] def filterInitsByType[T <: Initialization: ClassTag]()
      : List[T] = {
    this.getInits flatMap {
      case q: T => Some(q)
      case _    => None
    }
  }

  /** extracts all Initialization objects from inits Option of a Vasapi object.
    * Empty list if inits Option is empty
    *
    * @return
    *   list of all Initialization objects
    */
  private[vasapi] def getInits: List[Initialization] = {
    this.inits.getOrElse(List.empty[Initialization])
  }

  /** returns all udfs of a Vasapi object. Empty list if udfs Option is empty
    *
    * @return
    *   list of all Initialization objects
    */
  private[vasapi] def getUdfs: Map[String, String] = {
    this.udfs.getOrElse(Map.empty)
  }
}
