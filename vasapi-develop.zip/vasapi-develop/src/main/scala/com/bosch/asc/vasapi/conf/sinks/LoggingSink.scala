/*
 * Copyright (c) 2009, 2018 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */
package com.bosch.asc.vasapi.conf.sinks

import org.apache.spark.internal.Logging
import org.apache.spark.sql.DataFrame

/** LoggingSink object provides a builder for creating a function to log
  * DataFrame content.
  *
  * The builder takes options, such as prefix, separator, and postfix, as input
  * and returns a function that logs the content of a DataFrame with specified
  * formatting.
  */
object LoggingSink extends Logging {

  /** Builder method for creating a function to log the contents of a dataframe
    * @param options
    *   Options for logging (e.g., prefix, separator, postfix)
    * @return
    *   A function that takes a DataFrame and a batchId, formats the content,
    *   and logs it
    */
  def builder(
      options: Option[Map[String, String]]
  ): (DataFrame, Long) => Unit = {
    val prefix = options.getOrElse(Map.empty).getOrElse("prefix", "")
    val separator = options.getOrElse(Map.empty).getOrElse("separator", "\n")
    val postfix = options.getOrElse(Map.empty).getOrElse("postfix", "")

    (batchDF: DataFrame, batchId: Long) => {
      val text =
        batchDF.collect().map(row => row.getString(0)).mkString(separator)
      logInfo(prefix + text + postfix)
    }
  }
}
