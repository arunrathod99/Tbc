/*
 *  Copyright (c) 2023 Robert Bosch GmbH and its subsidiaries.
 *  This program and the accompanying materials are made available under
 *  the terms of the Bosch Internal Open Source License v4
 *  which accompanies this distribution, and is available at
 *  http://bios.intranet.bosch.com/bioslv4.txt
 */

package com.bosch.asc.vasapi.validation

import com.bosch.asc.vasapi.conf._
import com.bosch.asc.vasapi.utils.VasapiFileUtils
import org.apache.spark.internal.Logging
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.{DataFrame, SparkSession}

/** test source for Solace sources to be used during validation.
  *
  * @param src
  *   Source to be replaced by a test source
  * @param testDataPath
  *   Path to the test data
  */
class SolaceTestSource(src: Source, testDataPath: String)
    extends TestSource(src, testDataPath)
    with Logging {

  override def createDataFrame(implicit spark: SparkSession): DataFrame = {

    import spark.implicits._

    val testData: Seq[String] = VasapiFileUtils.filesToSeqString(testDataPath)

    testData
      .toDF("content")
      .withColumn("uuid", lit(java.util.UUID.randomUUID().toString))
  }
}
