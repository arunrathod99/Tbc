/*
 * Copyright (c) 2019-2023 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */

package com.bosch.asc.vasapi.conf

import com.bosch.asc.vasapi.conf.sources.{GenericStreamSource, KafkaSource}
import com.bosch.asc.vasapi.conf.sinks.{
  HiveBatchSink,
  HiveSink,
  HttpPostSink,
  LoggingSink,
  S3Sink
}
import com.bosch.asc.vasapi.utils.{
  VasapiConfUtils,
  VasapiSchemaUtils,
  Credential
}
import com.bosch.asc.vasapi.validation.{KafkaTestSource, SolaceTestSource}
import org.apache.spark.internal.Logging
import org.apache.spark.sql.streaming.StreamingQuery
import org.apache.spark.sql.{DataFrame, SparkSession}

import scala.util.{Success, Try}

/** Query trait resembles an interface to all nodes of a query plan tree, e.g.
  * like Sink (leaf node)
  */
sealed trait Query {
  val name: String

  /** Registers the query block in a sparksession
    * @param spark
    *   Session object
    */
  def register(implicit spark: org.apache.spark.sql.SparkSession): Unit
}

/** Configuration for a source in a streaming query.
  *
  * @param name
  *   Name of the source
  * @param format
  *   Format of the source data. In addition to Spark's built in sources, you
  *   can specify:
  *   - kafkaBatch --> a kafka batch source to join against streaming queries
  *   - solace --> see <a
  *     href=https://sourcecode.socialcoding.bosch.com/projects/BIDOS/repos/bidos.sparkstreamssolace>SparkStreamsSolace</a>
  * @param serialization
  *   Optional serialization method when reading from Kafka (json / avro)
  * @param ddlSchema
  *   Optional DDL schema for the source
  * @param jsonSchemaFile
  *   Optional JSON schema file for the source
  * @param avroSchemaFile
  *   Optional Avro schema file for the source
  * @param load
  *   Optional load path for the source
  * @param options
  *   Optional options for the source TODO: should avro parsing only work with
  *   avro schema or fallback to ddl and json schemas?
  * @param credentialOptions
  *   Optional credential options for the source
  */
final case class Source(
    name: String,
    format: String,
    serialization: Option[String],
    ddlSchema: Option[String],
    jsonSchemaFile: Option[String],
    avroSchemaFile: Option[String],
    load: Option[String],
    options: Option[Map[String, String]],
    credentialOptions: Option[Map[String, Credential]]
) extends Query
    with Logging {

  /** Registers a source based on the specified format. Delegates to specific
    * methods based on the format type.
    *
    * @param spark
    *   SparkSession
    */
  def register(implicit spark: SparkSession): Unit = {
    format match {

      case "avro" =>
        registerAvroFileStreamSource(spark: SparkSession)

      case "com.databricks.spark.avro" =>
        logWarning("this source type is deprecated, use 'avro' instead")
        registerAvroFileStreamSource(spark: SparkSession)

      case "kafkaBatch" =>
        val kfkSrc = KafkaSource(this)
        val kafkaBatchDF = kfkSrc.loadKafkaBatch(spark: SparkSession)
        kafkaBatchDF.createTempView(name)
        logInfo(s"Registered kafka batch source $name")

      case "kafka" =>
        val kfkSrc = sources.KafkaSource(this)
        val kafkaStreamDF = kfkSrc.loadKafkaStream(spark: SparkSession)
        kafkaStreamDF.createTempView(name)
        logInfo(s"Registered kafka stream source $name")

      case _ =>
        val genSrc = GenericStreamSource(this).registerSource(spark)
        genSrc.createTempView(name)
        logInfo(s"registered generic stream source $name")
    }
  }

  /** Registers an Avro streaming source, with schema provided or loaded from a
    * file.
    *
    * @param spark
    *   SparkSession
    */
  private def registerAvroFileStreamSource(spark: SparkSession): Unit = {
    logInfo(s"registering new avro source: $name")

    val sourcePath: String = load match {
      case Some(p) =>
        logInfo(s"input path for source is: $p")
        p
      case None =>
        logError(
          "input path should be explicitly passed using the source's `load` parameter"
        )
        throw new NoSuchElementException(
          "specify load parameter for avro file source"
        )
    }

    val inputDF: DataFrame = avroSchemaFile match {
      case Some(s) =>
        logInfo(s"registering avro source using schema file $s")

        val optionsWithSchemaFile: Option[Map[String, String]] =
          Option(
            options.getOrElse(
              Map.empty[String, String]
            ) + ("avroSchemaFile" -> s)
          )

        // TODO: not very elegant; delegate schema handling to utils
        this.copy(options = optionsWithSchemaFile)

        spark.readStream
          .format(format)
          .options(
            VasapiConfUtils
              .getValidOptionsByFormat(this)
          )
          .load(sourcePath)

      case None =>
        logInfo(
          "registering avro source without passing explicit schema - spark will attempt to infer schema"
        )
        spark.readStream
          .format(format)
          .options(VasapiConfUtils.getValidOptionsByFormat(this))
          .load(sourcePath)
    }
    inputDF.createTempView(name)
  }

  /** Helper method for creating schema to be passed to vasapi source.
    * @param ddlSchemaDetail:
    *   Option[String]
    * @param jsonSchema:
    *   Option[String]
    * @return
    *   a tuple containing a map of source options and a schema StructType
    */
  private[conf] def createSourceSchema(
      ddlSchemaDetail: Option[String],
      jsonSchema: Option[String]
  ): Option[org.apache.spark.sql.types.StructType] =
    (ddlSchemaDetail, jsonSchema) match {
      case (_, Some(jsonSchemaFilename)) =>
        logInfo("creating json based schema")
        Some(
          VasapiSchemaUtils.createStructTypeFromJsonSchema(jsonSchemaFilename)
        )
      case (Some(schemaDdl), None) =>
        logInfo("creating ddl based schema")
        Some(org.apache.spark.sql.types.StructType.fromDDL(schemaDdl))

      case (None, None) =>
        None
    }
}

/** Configuration for a test source. Test sources are used to replace actual
  * sources during validation. This helps to run data validation tests without
  * connecting to actual sources.
  *
  * TestSources are exclusively used for testing / validation / dry runs etc and
  * not intended to be used in production pipelines. They are still part of the
  * config tree to allow for easy switching between test and production sources
  * (actual [[Source]] instances and [[TestSource]] are part of the same class
  * hierarchy and thus have compatible types with [[Query]] being the common
  * super type).
  *
  * @param src
  *   Source to be replaced by a test source
  * @param testDataPath
  *   Path to the test data
  * @see
  *   [[com.bosch.asc.vasapi.validation.VasapiValidator]]
  * @since 1.2.0
  */
case class TestSource(src: Source, testDataPath: String)
    extends Query
    with Logging {

  val name: String = src.name
  val format: String = src.format
  val options: Option[Map[String, String]] = Option(Map.empty)
  val credentialOptions: Option[Map[String, Credential]] = Option(Map.empty)

  /** register a [[DataFrame]] as a temporary view that can be queried using
    * {{{
    *   spark.sql("select * from <name>")
    * }}}
    */
  def register(implicit spark: SparkSession): Unit = {
    createDataFrame.createTempView(name)
  }

  /** creates a [[DataFrame]] from this object's testDataPath attribute test
    * data path.
    *
    * @param spark
    *   implicit [[SparkSession]]
    * @return
    */
  def createDataFrame(implicit spark: SparkSession): DataFrame = {
    val testSrc: TestSource = format match {
      case "solace_source" => new SolaceTestSource(src, testDataPath)
      case "kafka"         => new KafkaTestSource(src, testDataPath)
      case _ =>
        throw new NoSuchElementException(
          "currently, only solace_source and kafka sources supported for validation"
        )
    }

    // delegate to the respective test source to create the DataFrame
    testSrc.createDataFrame
  }
}

/** Watermark arguments.
  */
final case class Watermark(
    eventTime: String,
    delayThreshold: String
)

/** registers a spark temp view (refer to the documentation of
  * org.apache.spark.sql.Dataset.createTempView()). Views can reference other
  * sources, views etc. (since these again are registered as spark temp views).
  * @param sql
  *   SQL statement for the view
  * @param name
  *   Name of the view
  * @param watermark
  *   Optional watermark configuration
  */
final case class View(
    sql: String,
    name: String,
    watermark: Option[Watermark]
) extends Query
    with Logging {

  /** implements abstract method from Query Trait. Registers view as temp view
    * into spark context.
    *
    * @param spark
    *   SparkSession
    */
  def register(implicit spark: org.apache.spark.sql.SparkSession): Unit = {
    Try {
      val df = this.watermark match {
        case None => spark.sql(sql): DataFrame
        case Some(wm) =>
          spark
            .sql(sql)
            .withWatermark(wm.eventTime, wm.delayThreshold): DataFrame
      }
      df.createTempView(this.name)
    } match {
      case Success(_) => logInfo(s"successfully registered view $name")
      case scala.util.Failure(ex) =>
        logError(s"failed to register view $name: ${ex.getMessage}")
        throw ex
    }
  }
}

/** used to add <a
  * href=https://spark.apache.org/docs/latest/structured-streaming-programming-guide.html#triggers>triggers</a>
  * to Vasapi pipelines.
  *
  * This trait (and its derived classes), are used to infer trigger
  * configurations from Vasapi configurations. The [[Sink]] class translates
  * them into Spark's internal trigger representation and registers them into
  * streaming queries.
  */
sealed trait Trigger

/** Trigger at specified intervals.
  */
final case class Processingtime(interval: String) extends Trigger

/** Trigger once.
  */
final case class Once() extends Trigger

/** Listener trait to provide logging information after a batch is progressed.
  */
sealed trait SparkStreamingListener

/** Run Spark SQL statement on streaming progress event to trigger log
  * information.
  * @param sql
  *   SQL statement to run on streaming progress
  */
final case class ProgressSqlStatement(sql: String)
    extends SparkStreamingListener

/** Calls LogPersister on streaming progress event to persist log information on
  * given path.
  * @param path
  *   The path to persist the log information
  */
final case class LogProgress(path: String) extends SparkStreamingListener

/** Configuration for a sink in a streaming query.
  *
  * @param sql
  *   SQL statement for the sink.
  * @param coalesce
  *   Optional coalesce value for reducing the number of output files.
  * @param format
  *   Format of the sink data.
  * @param outputMode
  *   Optional output mode for the sink.
  * @param logPath
  *   Optional path for logging.
  * @param dataBaseName
  *   Optional database name for Hive sink.
  * @param tableName
  *   Optional table name for Hive sink.
  * @param partitionBy
  *   Optional list of columns for partitioning.
  * @param trigger
  *   Trigger configuration for the sink.
  * @param sparkListener
  *   Optional list of Spark streaming listeners.
  * @param options
  *   Optional options for the sink.
  * @param credentialOptions
  *   Optional credential options for the source
  */
final case class Sink(
    sql: String,
    coalesce: Option[Int],
    format: String,
    outputMode: Option[String],
    logPath: Option[String],
    dataBaseName: Option[String],
    tableName: Option[String],
    partitionBy: Option[List[String]],
    executionMode: Option[String],
    trigger: Option[Trigger],
    sparkListener: Option[List[SparkStreamingListener]],
    options: Option[Map[String, String]],
    credentialOptions: Option[Map[String, Credential]]
) extends Query
    with Logging {

  val name: String = "sink_" + java.util.UUID.randomUUID.toString

  /** starts writing for a sink based on the execution mode and sink format.
    * Note that in the current vasapi architecture, batch and stream sinks are
    * allowed. Vasapi would allow combining (stream) sources with batch sinks,
    * which would result in a Spark exception.
    *
    * Since no explicit batch sources exist, batch sinks can only be applied
    * directly on views (that do not depend on any [[Source]] to avoid that they
    * become streaming dataframes).
    *
    * The default sink type is streaming.
    *
    * @param spark
    *   [[SparkSession]]
    */
  def register(implicit spark: SparkSession): Unit = {

    /*
      execute the sink based on the execution mode
      sinks are not always exclusively batch or stream, hence execution mode avoids ambiguity
     */
    executionMode match {
      case Some("batch") =>
        startBatchSinks(spark)

      case Some("stream") | None =>
        startStreamingSinks(spark)

      case Some(otherMode) =>
        throw new IllegalArgumentException(
          s"Unknown execution mode: $otherMode"
        )
    }
  }

  /** helper method returning an (un)partitioned [[DataFrame]] based on this
    * Source's configuration.
    * @return
    */
  private[conf] def registerDF(spark: SparkSession): DataFrame = {
    // register sink sql statement and apply coalesce if specified
    coalesce match {
      case None                => spark.sql(sql)
      case Some(numPartitions) => spark.sql(sql).coalesce(numPartitions)
    }
  }

  /** starts this sink if it's a batch sink
    */
  private[conf] def startBatchSinks(spark: SparkSession): Unit = {
    format match {
      case "s3"   => new S3Sink(this, spark).execute()
      case "hive" => HiveBatchSink(this, spark).execute()
      case _ =>
        throw new IllegalArgumentException(
          s"at the moment, only s3 and hive sinks support batch mode; $format not allowed"
        )
    }
  }

  /** starts a streaming sink. For some specific sink types (http-post, logging,
    * hive), Spark's forEachBatch is used. All other cases are handled by
    * Spark's writeStream method.
    */
  private[conf] def startStreamingSinks(implicit spark: SparkSession): Unit = {
    var stream = registerDF(spark).writeStream
    outputMode.foreach(om => stream = stream.outputMode(om))

    val triggerConf = trigger match {
      case None => None
      case Some(Processingtime(interval: String)) =>
        Some(org.apache.spark.sql.streaming.Trigger.ProcessingTime(interval))
      case Some(Once()) => Some(org.apache.spark.sql.streaming.Trigger.Once())
    }

    format match {
      case "http-post" =>
        partitionBy.foreach(pb => stream = stream.partitionBy(pb: _*))
        val sink = stream
          .trigger(
            triggerConf.getOrElse(
              throw new IllegalArgumentException(
                "streaming sinks need a trigger"
              )
            )
          )
          .foreachBatch(HttpPostSink.builder(options))
          .options(VasapiConfUtils.getValidOptionsByFormat(this))
          .start()

        setStreamingListeners(spark, sink)

      case "logging" =>
        partitionBy.foreach(pb => stream = stream.partitionBy(pb: _*))
        val sink = stream
          .trigger(
            triggerConf.getOrElse(
              throw new IllegalArgumentException(
                "streaming sinks need a trigger"
              )
            )
          )
          .foreachBatch(LoggingSink.builder(options))
          .options(VasapiConfUtils.getValidOptionsByFormat(this))
          .start()
        setStreamingListeners(spark, sink)

      case "hive" =>
        val sink = stream
          .trigger(
            triggerConf.getOrElse(
              throw new IllegalArgumentException(
                "streaming sinks need a trigger"
              )
            )
          )
          .options(VasapiConfUtils.getValidOptionsByFormat(this))
          .foreachBatch(
            HiveSink.builder(options, dataBaseName, tableName, partitionBy)
          )
          .start()
        setStreamingListeners(spark, sink)

      case _ =>
        partitionBy.foreach(pb => stream = stream.partitionBy(pb: _*))
        val sink = stream
          .trigger(
            triggerConf.getOrElse(
              throw new IllegalArgumentException(
                "streaming sinks need a trigger"
              )
            )
          )
          .format(format)
          .options(VasapiConfUtils.getValidOptionsByFormat(this))
          .start()
        setStreamingListeners(spark, sink)
    }

  }

  /** takes this sink's List of StreamingListeners and registers them for the
    * given sink
    * @param spark
    *   spark session in which sink exists
    * @param sink
    *   for which to register streaming listeners
    */
  private[conf] def setStreamingListeners(implicit
      spark: SparkSession,
      sink: StreamingQuery
  ): Unit = {
    sparkListener.foreach { streamingListeners =>
      streamingListeners.foreach {
        case ProgressSqlStatement(sql: String) =>
          val sinkId = sink.id
          val listener = new SparkStreamingListenerSQL(spark, sinkId, sql)
          spark.streams.addListener(listener)

        case LogProgress(path: String) =>
          val listener = new SparkStreamingListenerLog(spark, path)
          spark.streams.addListener(listener)
      }
    }
  }
}
