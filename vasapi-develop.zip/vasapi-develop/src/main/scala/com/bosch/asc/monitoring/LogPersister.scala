/*
 * Copyright (c) 2020 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */

package com.bosch.asc.monitoring

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.streaming.StreamingQueryListener
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.DateType
import org.apache.spark.sql.SaveMode

class LogPersister {

  /** this method is used to persists the progress event into HDFS
    *
    * @param spark
    *   The SparkSession object used to persist the progress JSON
    * @param event
    *   The QueryProgressEvent to be transformed before persisting
    * @param logPath
    *   The path to persist the progress JSON
    * @note
    *   The method reads the event's progress as a JSON, extracts specific
    *   columns, performs column renaming, and saves the result as Parquet files
    *   in HDFS. The data is partitioned by date
    */
  def persist(
      spark: SparkSession,
      event: StreamingQueryListener.QueryProgressEvent,
      logPath: String
  ): Unit = {
    import spark.implicits._
    val progressJson = spark.read.json(Seq(event.progress.toString()).toDS)

    val reqColumnNames = Seq(
      "batchId",
      "id",
      "runId",
      "numInputRows",
      "inputRowsPerSecond",
      "processedRowsPerSecond",
      "timestamp",
      "sources",
      "sink.description"
    )
    val finalJson = progressJson
      .select(reqColumnNames.map(c => col(c)): _*)
      .withColumn("date", progressJson("timestamp").cast(DateType))
      .selectExpr("*", "sources[0].description")
      .withColumnRenamed("sources[0].description", "sourcesDescription")
      .withColumnRenamed("description", "sinkDescription")
      .drop("sources")

    finalJson.write
      .mode(SaveMode.Append)
      .partitionBy("date")
      .format("parquet")
      .save(logPath)

  }

}
