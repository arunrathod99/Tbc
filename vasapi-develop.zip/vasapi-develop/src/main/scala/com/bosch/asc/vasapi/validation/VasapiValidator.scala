/*
 *  Copyright (c) 2023 Robert Bosch GmbH and its subsidiaries.
 *  This program and the accompanying materials are made available under
 *  the terms of the Bosch Internal Open Source License v4
 *  which accompanies this distribution, and is available at
 *  http://bios.intranet.bosch.com/bioslv4.txt
 */

package com.bosch.asc.vasapi.validation

import com.bosch.asc.vasapi

import scala.util.{Failure, Success, Try}
import org.apache.spark.internal.Logging
import org.apache.spark.sql.SparkSession
import com.bosch.asc.vasapi.conf._
import com.bosch.asc.vasapi.{Pipeline, Vasapi}
import com.bosch.asc.vasapi.utils.VasapiSparkUtils

/** Utility class for easier testability of vasapi configurations
  *
  * Provides convenience methods to test vasapi configurations locally or in a
  * CI/CD workflow Testing can be done on two levels:
  *   - syntactical correctness of the configuration (e.g. correct SQL syntax,
  *     correct view names)
  *   - data validation (validate data transformation based on validation data)
  *
  * See integration tests and docs for usage examples.
  *
  * @author
  *   Andreas Kreitschmann (andreas.kreitschmann@de.bosch.com)
  * @since 1.2.0
  * @param spark
  *   [[org.apache.spark.sql.SparkSession]]
  * @param vasapiConfig
  *   [[Vasapi]]
  */
class VasapiValidator(val vasapiConfig: Vasapi)(implicit spark: SparkSession)
    extends Logging {

  /** parses all [[IcebergTable]] and [[ExternalHiveTable]] creation statements
    * in the inits section of the vasapi configuration.
    *
    * @return
    *   [[Success]] if no exception found during validation, [[Failure]]
    *   otherwise
    */
  def validateInits(): Try[Unit] = {
    Try {
      this.vasapiConfig.getInits.foreach {
        case t: BaseTable =>
          logInfo(s"validating table creation for table: ${t.name}")
          t.register
        case _ =>
          logInfo("no inits found for validation")
      }
    } match {
      case Success(s) =>
        logInfo("successfully validated init block")
        Success(s)
      case Failure(ex) =>
        logError(
          s"found exception during validation of of inits. ${ex.getMessage}"
        )
        throw ex
    }
  }

  /** convenience wrapper around validateInits(). Returns a Boolean indicating
    * whether all inits are valid.
    */
  def allInitsValid(): Boolean = {
    Try(validateInits()) match {
      case Success(_) =>
        logInfo("successfully validated inits")
        true
      case Failure(ex) =>
        logError(s"found errors during inits validation: ${ex.getMessage}")
        false
    }
  }

  /** validates the vasapi configuration by registering all sources and views in
    * Spark. only targets views, however sources need to be registered as well
    * since views reference them.
    *
    * sinks are skipped since we do not want to start actual processing /
    * streaming to start. due to lazy execution, Spark only constructs a logical
    * plan (which helps validate correctness), but does not actually connect to
    * sources and / or start processing --> no exceptions are thrown during
    * validation.
    *
    * @param registerUDFs
    *   if true, all UDFs are registered before registering sources and views if
    *   false, caller needs to explicitly handle (or ignore) UDFs
    * @return
    *   [[Try]] containing Unit if validation was successful, else a
    *   [[Throwable]] is returned
    */
  def validateTransformations(registerUDFs: Boolean = true): Try[Unit] = {
    Try {
      // UDFs need to be registered before registering sources / views / sinks
      if (registerUDFs) {
        Pipeline.registerUDFs(vasapiConfig)
      }
      logInfo("Vasapi UDFs set up for config validation")

      // skip sinks to prevent streams from starting
      val sourcesSinks: List[Query] = vasapiConfig.queries flatMap {
        case s: Source      => Some(s)
        case ts: TestSource => Some(ts)
        case v: View        => Some(v)
        case _              => None
      }

      Pipeline.registerQueries(sourcesSinks)
      logInfo("sources and views are registered - validation done")
    }
  }

  /** Convenience wrapper method around validate() returning a Boolean instead
    * of a Try object.
    */
  def allTransformationsValid: Boolean = {
    validateTransformations() match {
      case Success(_) =>
        logInfo("successfully loaded and validated vasapi configuration")
        true
      case Failure(ex) =>
        logInfo(s"found errors during pipeline validation: ${ex.getMessage}")
        false
    }
  }

  /** replaces a source in the vasapi configuration with a test source
    * containing test / validation data.
    *
    * This enables testing of the vasapi configuration without the need to
    * connect to actual sources. Can be combined with other methods in this
    * class to validate the configuration.
    *
    * @param srcName
    *   name of source to be replaced by a dummy source for validation
    * @param testDataPath
    *   the path to the test data
    * @return
    */
  def replaceSource(srcName: String, testDataPath: String): VasapiValidator = {

    // find the source to be replaced
    val src: Source = vasapiConfig.sources
      .find(s => s.name == srcName)
      .getOrElse(
        throw new IllegalArgumentException(s"source $srcName does not exist")
      )

    // instantiate the respective dummy source type
    val dummySrc: Query = src.format match {
      case "solace_source" => new SolaceTestSource(src, testDataPath)
      case "kafka"         => new KafkaTestSource(src, testDataPath)
      case _ =>
        throw new NoSuchElementException(
          "only solace_source and kafka sources supported for validation"
        )
    }

    // drop the temp view if it exists to make sure we can register the test source
    VasapiSparkUtils.dropTempView(srcName, spark)

    // replace the source with the test source
    val queriesSrcReplaced: List[Query] =
      dummySrc :: vasapiConfig.queries.filter(q => q.name != src.name)
    logInfo(
      s"replaced source $srcName with test source, views for validation are: ${queriesSrcReplaced
          .map(_.name)}"
    )

    // return the updated vasapi object
    val vasapiSrcReplaced: Vasapi = vasapi.Vasapi(
      inits = vasapiConfig.inits,
      udfs = vasapiConfig.udfs,
      queries = queriesSrcReplaced
    )

    VasapiValidator(vasapiConfig = vasapiSrcReplaced)
  }
}

/** companion object containing factory methods for VasapiValidator object
  * creation
  */
object VasapiValidator extends Logging {

  /** default factory method to create a VasapiValidator object
    * @param vasapiConfig
    *   [[Vasapi]] object to validate
    * @param spark
    *   [[SparkSession]] object
    * @return
    *   VasapiValidator object
    */
  def apply(
      vasapiConfig: Vasapi
  )(implicit spark: SparkSession): VasapiValidator = {
    new VasapiValidator(vasapiConfig)
  }

  /** factory method to create a VasapiValidator object with replaced sources
    *
    * @param vasapiConfig
    *   [[Vasapi]] object to validate
    * @param replaceSources
    *   map where keys are source names to be replaced and values are paths to
    *   test data; should point to a path that can be found in this
    *   application's resources
    *
    * @param spark
    *   [[SparkSession]] object
    * @return
    *   VasapiValidator object with replaced sources
    */
  def apply(vasapiConfig: Vasapi, replaceSources: Map[String, String])(implicit
      spark: SparkSession
  ): VasapiValidator = {

    val conValidator = new VasapiValidator(vasapiConfig)

    replaceSources.foldLeft(conValidator) {
      case (validator, (srcName, testDataPath)) =>
        validator.replaceSource(srcName, testDataPath)
    }
  }
}
