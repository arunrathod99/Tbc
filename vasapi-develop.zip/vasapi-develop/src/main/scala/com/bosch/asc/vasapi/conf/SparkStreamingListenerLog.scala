package com.bosch.asc.vasapi.conf

import com.bosch.asc.monitoring.LogPersister
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.streaming.StreamingQueryListener

/** Listener interface to persist logging information with data from Spark SQL
  * streaming queries. This class implements the Spark `StreamingQueryListener`
  * interface, allowing it to listen to events related to Spark SQL streaming
  * queries. It is specifically designed to persist logging information using
  * the `LogPersister` class when a streaming query makes progress.
  * @param spark
  *   SparkSession instance to interact with Spark functionality.
  * @param logPath
  *   String representing the path where logging information is to be persisted.
  */
class SparkStreamingListenerLog(spark: SparkSession, logPath: String)
    extends StreamingQueryListener {
  // Invoked when a streaming query is started.
  def onQueryStarted(event: StreamingQueryListener.QueryStartedEvent): Unit = {
    throw new UnsupportedOperationException
  }

  /** Invoked when a streaming query makes progress
    * @param event
    *   QueryProgressEvent containing information about the query progress
    */
  def onQueryProgress(
      event: StreamingQueryListener.QueryProgressEvent
  ): Unit = {
    val logPersister = new LogPersister()
    logPersister.persist(spark, event, logPath)
  }

  /** Invoked when a streaming query is terminated
    *
    * @param event
    *   QueryTerminatedEvent containing information about the terminated query
    */
  def onQueryTerminated(
      event: StreamingQueryListener.QueryTerminatedEvent
  ): Unit = {
    throw new UnsupportedOperationException
  }
}
