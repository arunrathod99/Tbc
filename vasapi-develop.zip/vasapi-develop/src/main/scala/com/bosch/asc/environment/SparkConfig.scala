/*
 * Copyright (c) 2018-2024 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */

package com.bosch.asc.environment

import org.apache.spark.SparkConf

/** Encapsulates the Spark configuration used by vasapi.
  */
object SparkConfig {

  def apply(): SparkConf = {
    new SparkConf()
      .set("hive.exec.dynamic.partition", "true")
      .set("hive.exec.dynamic.partition.mode", "nonstrict")
      .set(
        "fs.s3a.aws.credentials.provider",
        "org.apache.hadoop.fs.s3a.SimpleAWSCredentialsProvider"
      )
      .set("fs.s3a.connection.ssl.enabled", "true")
      .set("fs.s3a.path.style.access", "true")
  }
}
