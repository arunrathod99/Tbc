/*
 * Copyright (c) 2009, 2018 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */
package com.bosch.asc.vasapi.conf.sinks

import org.apache.spark.internal.Logging
import org.apache.spark.sql.DataFrame

import java.util.InvalidPropertiesFormatException

/** HiveSink object provides a builder for creating a function to write a
  * DataFrame into a Hive table.
  *
  * The builder takes options, database name, table name, and partition columns
  * as input and returns a function that writes the DataFrame into a Hive table.
  *
  * This HiveSink assumes the use of Apache Spark for DataFrame operations.
  *
  * Example usage:
  * {{{
  *   val writeToHiveTable = HiveSink.builder(
  *     options = Some(Map("path" -> "/path/to/write")),
  *     dataBaseName = Some("myDatabase"),
  *     tableName = Some("myTable"),
  *     partitionBy = Some(List("column1", "column2"))
  *   )
  *
  *   writeToHiveTable(dataFrame, batchId)
  * }}}
  */
object HiveSink extends Logging {

  /** Builder method for creating a function to write a DataFrame into a Hive
    * table.
    *
    * @param options
    *   Options for writing DataFrame (e.g., path to write).
    * @param dataBaseName
    *   Database name for the Hive table.
    * @param tableName
    *   Table name for the Hive table.
    * @param partitionBy
    *   Optional list of partition columns.
    * @return
    *   A function that takes a DataFrame and a batchId and writes it into a
    *   Hive table.
    * @throws InvalidPropertiesFormatException
    *   if database name or table name is not specified.
    */
  def builder(
      options: Option[Map[String, String]],
      dataBaseName: Option[String],
      tableName: Option[String],
      partitionBy: Option[List[String]]
  ): (DataFrame, Long) => Unit = {

    val pathToWrite: String = options.getOrElse(Map.empty).getOrElse("path", "")

    (batchDF: DataFrame, batchId: Long) => {
      var dfToWrite = if (pathToWrite == "") {
        batchDF.write
      } else {
        batchDF.write
          .option("path", pathToWrite)
      }
      partitionBy.foreach(pb => dfToWrite = dfToWrite.partitionBy(pb: _*))

      (dataBaseName, tableName) match {
        case (Some(db), Some(tb)) =>
          dfToWrite
            .format("parquet")
            .mode("append")
            .saveAsTable(s"$db.$tb")

          logInfo(s"Data Written into $db.$tb table")

        case (_, _) =>
          throw new InvalidPropertiesFormatException(
            "dataBaseName and tableName have to be specified via conf for HiveSink"
          )

      }
    }
  }
}
