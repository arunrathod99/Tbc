/*
 *  Copyright (c) 2023 Robert Bosch GmbH and its subsidiaries.
 *  This program and the accompanying materials are made available under
 *  the terms of the Bosch Internal Open Source License v4
 *  which accompanies this distribution, and is available at
 *  http://bios.intranet.bosch.com/bioslv4.txt
 */

package com.bosch.asc.vasapi.validation

import com.bosch.asc.vasapi.conf._
import com.bosch.asc.vasapi.conf.sources.KafkaSource
import com.bosch.asc.vasapi.utils.VasapiFileUtils

import scala.util.Random
import org.apache.spark.internal.Logging
import org.apache.spark.sql.{DataFrame, SparkSession}

/** test source for Kafka sources to be used during validation. uses embedded
  * Kafka topics to simulate a Kafka source
  *
  * @param src
  *   Source to be replaced by a test source
  * @param testDataPath
  *   Path to the test data
  */
class KafkaTestSource(src: Source, testDataPath: String)
    extends TestSource(src, testDataPath)
    with Logging {

  private val kfkPort: Int = Random.nextInt(9000) + 1000
  private val zkPort: Int = Random.nextInt(9000) + 1000
  private val topicName: String = "test-topic"
  private val embeddedKafka = KafkaFixture(kfkPort, zkPort)

  /** creates a DataFrame from an embedded, in-memory Kafka topic
    * @param spark
    *   [[SparkSession]] object
    * @return
    *   [[DataFrame]] with the structure of a
    *   [[com.bosch.asc.vasapi.conf.sources.KafkaStringMessage]]
    */
  override def createDataFrame(implicit spark: SparkSession): DataFrame = {

    embeddedKafka.initTopic(name = topicName, Option(loadData()))

    val rawDF: DataFrame = spark.read
      .format("kafka")
      .option("kafka.bootstrap.servers", s"localhost:$kfkPort")
      .option("subscribe", "test-topic")
      .option("startingOffsets", "earliest")
      .option("endingOffsets", "latest")
      .load()

    KafkaSource.parseKafkaStringDF(df = rawDF).toDF()
  }

  /** helper method to load test data from a file
    * @return
    *   a [[Map]] of keys & values to pass to a Kafka topic
    */
  private def loadData(): Map[String, String] = {
    val testData: Seq[String] = VasapiFileUtils.filesToSeqString(testDataPath)

    testData.map(elem => java.util.UUID.randomUUID().toString -> elem).toMap
  }
}
