/*
 * Copyright (c) 2018-2024 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */

package com.bosch.asc.vasapi.utils

import java.io.IOException
import java.nio.file.{Files, Paths}
import scala.io.BufferedSource
import scala.util.{Failure, Success, Try}
import org.apache.spark.internal.Logging

import scala.collection.JavaConverters._

object VasapiFileUtils extends Logging {

  /** Utility method to safely read a file source's content into a string. It
    * uses [[https://tinyurl.com/5any2jnm this]] functional approach.
    *
    * @param fileName
    *   Path to the input file.
    * @return
    *   A Try containing the file content as a string.
    */
  def safeFileToString(fileName: String): Try[String] = {
    readBufferedSource(
      Try(scala.io.Source.fromFile(fileName))
    )
  }

  /** Utility method to safely read a resource's content into a string.
    *
    * @param resource
    *   Path to the input resource.
    * @return
    *   A Try containing the resource content as a string.
    */
  def safeResourceToString(resource: String): Try[String] = {
    readBufferedSource(
      Try(scala.io.Source.fromResource(resource))
    )
  }

  /** attempts to safely read a source either from file (using
    * scala.io.Source.fromFile) or from a resource
    * (scala.io.Source.fromResource)
    * @param fileName
    *   the source to read
    * @return
    */
  def safeFileOrResourceToString(fileName: String): Try[String] = {
    safeResourceToString(fileName).orElse(safeFileToString(fileName))
  }

  /** helper to read a buffered source and returns the content as a string
    *
    * TODO: closing the source causes NullPointerExceptions
    *
    * @param src
    *   the buffered source wrapped in a [[Try]]
    * @return
    *   the content as a string wrapped in a [[Try]]
    */
  private def readBufferedSource(src: Try[BufferedSource]): Try[String] = {
    src match {
      case Success(f) => Try(f.getLines().mkString)
      case Failure(e) =>
        logError(s"could not read from buffered source: ${e.getMessage}")
        Failure(e)
    }
  }

  /** reads files in a directory and puts the content of each file in a [[Seq]]
    * of [[String]]. Used to read test data files during testing
    * @return
    *   [[Seq]] where each element corresponds to the content of one file
    */
  def filesToSeqString(testDataPath: String): Seq[String] = {
    val files: List[String] = resourcePathToFileList(testDataPath)
    logDebug(s"found ${files.length} files in $testDataPath)")

    val content: Seq[String] = files
      .map(f => safeResourceToString(f))
      .collect { case Success(value) =>
        value
      }

    logDebug(s"content is $content")

    content
  }

  /** reads a resource directory and lists all files in it. The files are listed
    * with their relative path, meaning resourcePath/fileName here. This is
    * important so that the output of this function can be further passed into
    * scala.io.Source.fromResource, which expects the relative path (throws
    * NullPointerException for absolute paths).
    *
    * @param resourcePath
    *   Path to the input directory.
    * @return
    *   List of strings.
    */
  private def resourcePathToFileList(resourcePath: String): List[String] = {

    Option(getClass.getClassLoader.getResource(resourcePath)) match {
      case Some(url) =>
        val dirPath = Paths.get(url.toURI)
        if (Files.isDirectory(dirPath)) {
          val files = Files
            .walk(dirPath)
            .iterator()
            .asScala
            .filter(Files.isRegularFile(_))
            .map(dirPath.relativize(_).toString)
            .map(file => s"$resourcePath$file")
            .toList
          logDebug(s"files found in resource directory: $files")
          files
        } else {
          throw new IOException(s"resource $resourcePath is not a directory")
        }
      case None =>
        throw new IOException(s"could not find resource $resourcePath")
    }
  }

}
