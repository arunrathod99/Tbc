/*
 * Copyright (c) 2018, 2024 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */

package com.bosch.asc.vasapi.conf

import com.bosch.asc.vasapi.utils.VasapiSchemaUtils
import org.apache.spark.sql.SparkSession
import org.apache.spark.internal.Logging
import org.apache.spark.sql.types.{DataType, StructType}

/** Initialization trait for nodes in an initialization block. */
sealed trait Initialization {

  /** Registers the initialization block in a SparkSession. */
  def register(implicit spark: SparkSession): Unit
}

/** Abstract base class for different table types. Implement this class to add a
  * new table type to vasapi.
  *
  * @param name
  *   Table name.
  * @param jsonSchemaFile
  *   Optional JSON schema file.
  * @param ddlSchema
  *   Optional DDL schema.
  * @param partitionBy
  *   Optional partition columns.
  * @param comment
  *   Optional table comment.
  * @param tblProperties
  *   Optional table properties.
  * @param location
  *   Optional location where the table will be created.
  */
sealed abstract class BaseTable(
    val name: String,
    val jsonSchemaFile: Option[String],
    val ddlSchema: Option[String],
    val partitionBy: Option[List[String]],
    val comment: Option[String],
    val tblProperties: Option[Map[String, String]],
    val location: Option[String]
) extends Initialization
    with Logging {

  private[conf] val dropTblStmt: Option[String] = None
  private[conf] val alterTblStmt: Option[String] = None

  /** registers table and any additional ddl statements in the spark session.
    * @param spark
    *   current [[SparkSession]]
    */
  def register(implicit spark: SparkSession): Unit = {

    val ddlStatements: Seq[Option[String]] = Seq(
      dropTblStmt,
      Some(initTableStmt()),
      alterTblStmt
    )

    ddlStatements.foreach { stmtOption =>
      stmtOption.map { stmt =>
        logInfo(s"executing ddl initialization statement: $stmt")
        spark.sql(stmt)
      }
    }
  }

  /** abstract method implemented in subclasses to create the table
    * initialization statement as a ddl string
    */
  def initTableStmt(): String

  /** abstract method; implemented in subclasses to initialize table creatin
    * using CREATE (EXTERNAL) TABLE
    */
  protected def withCreateStatement(stmt: StringBuilder): StringBuilder

  /** Adds a schema definition to the table definition. */
  protected def withSchema(
      schemaStr: String
  )(stmt: StringBuilder): StringBuilder = {
    stmt ++= s"$schemaStr)"
  }

  /** Adds a PARTITIONED BY clause to the table definition if partitions are
    * specified.
    */
  protected def withPartitioning(
      partitionStr: String
  )(stmt: StringBuilder): StringBuilder = {
    if (partitionStr.nonEmpty) {
      stmt ++= s" PARTITIONED BY ($partitionStr)"
    } else {
      stmt
    }
  }

  /** Adds a LOCATION clause with the specified location to the table
    * definition.
    */
  protected def withLocation(
      path: Option[String]
  )(stmt: StringBuilder): StringBuilder = {
    path match {
      case Some(loc) => stmt ++= s" LOCATION '$loc'"
      case None      => stmt
    }
  }

  /** Adds a COMMENT clause with the specified comment to the table definition.
    */
  protected def withComment(
      tblComment: Option[String]
  )(stmt: StringBuilder): StringBuilder = {
    tblComment match {
      case Some(comment) if comment.nonEmpty =>
        stmt ++= s" COMMENT '${comment.replaceAll("'", "")}'"
      case _ => stmt
    }
  }

  /** Adds TBLPROPERTIES with the specified properties to the table definition.
    */
  protected def withTblProperties(
      properties: Option[Map[String, String]]
  )(stmt: StringBuilder): StringBuilder = {
    properties match {
      case Some(props) if props.nonEmpty =>
        stmt ++= " TBLPROPERTIES ("
        stmt ++= props.map { case (k, v) => s"'$k'='$v'" }.mkString(", ")
        stmt ++= ")"
      case _ => stmt
    }
  }

  /** Builds an un-partitioned StructType schema from JSON or DDL.
    *
    * Allows merging of json and ddl schemas, while filtering out duplicate
    * fields. Json schema fields take precedence over ddl schema fields in case
    * of duplicates.
    */
  private def buildUnpartTblSchema(): StructType = {

    val jsonFields = createStructFromJSON().getOrElse(Seq.empty)
    val ddlFields = createStructFromDDL().getOrElse(Seq.empty)

    val filteredDDLFields =
      ddlFields.filter(f => !jsonFields.map(_.name).contains(f.name))

    val allSchemaFields = (jsonFields ++ filteredDDLFields).toList
    logDebug(s"schema fields for create stmts: $allSchemaFields")

    StructType(allSchemaFields)
  }

  /** creates a [[StructType]] from a json schema file specified in the config
    */
  private def createStructFromJSON(): Option[StructType] = {
    jsonSchemaFile.map(VasapiSchemaUtils.createStructTypeFromJsonSchema)
  }

  /** creates a [[StructType]] from a ddl schema if defined in the config
    * @return
    */
  private def createStructFromDDL(): Option[StructType] = {
    ddlSchema.map(ddlSchemaString => StructType.fromDDL(ddlSchemaString))
  }

  /** Filters data types to exclude complex types. */
  private def isComplexType(dtype: DataType): Boolean = {
    dtype match {
      case _: org.apache.spark.sql.types.StructType => false
      case _: org.apache.spark.sql.types.ArrayType  => false
      case _: org.apache.spark.sql.types.MapType    => false
      case _                                        => true
    }
  }

  /** Creates a partitioned schema ensuring columns used for partitioning are
    * only simple column types.
    */
  protected def createPartitionedSchema(
      withPartitionColumns: Boolean = false
  ): (StructType, Set[String]) = {
    val schemaBeforePartition = buildUnpartTblSchema()

    val rootColumnNamesBeforePartition = schemaBeforePartition
      .filter(f => isComplexType(f.dataType))
      .map(f => f.name)
      .toSet
    val partitionBySet = partitionBy.toList.flatten.toSet

    // Check if partition keys are part of root column names. If not, throw an error.
    if (!partitionBySet.subsetOf(rootColumnNamesBeforePartition)) {
      logError(
        "Partition keys provided " + partitionBySet +
          " are not a subset of the columns names in the root of the given schema " +
          rootColumnNamesBeforePartition + "."
      )
      throw new IllegalArgumentException(
        "Partition keys are no subset of root column names in schema."
      )
    }

    // Exclude partition columns from the main schema if needed
    val schemaAfterPartition = if (withPartitionColumns) {
      schemaBeforePartition
    } else {
      org.apache.spark.sql.types.StructType(
        schemaBeforePartition.filter(field =>
          !partitionBySet.contains(field.name)
        )
      )
    }

    (schemaAfterPartition, partitionBySet)
  }

  /** Generates partition string for the table definition making sure columns
    * used for partitioning are only simple column types.
    */
  protected def generatePartitionString(partitionKeys: Set[String]): String = {
    val partitionSchema = org.apache.spark.sql.types.StructType(
      partitionKeys
        .flatMap(key => buildUnpartTblSchema().find(field => field.name == key))
        .map(field => field)
        .toSeq
    )
    partitionSchema.toDDL
  }
}

/** Allows initial creation of an external Hive table upon pipeline start. */
final case class ExternalHiveTable(
    override val name: String,
    dropTable: Option[Boolean],
    override val jsonSchemaFile: Option[String],
    override val ddlSchema: Option[String],
    override val partitionBy: Option[List[String]],
    override val comment: Option[String],
    override val tblProperties: Option[Map[String, String]],
    storedAs: Option[String],
    override val location: Option[String]
) extends BaseTable(
      name,
      jsonSchemaFile,
      ddlSchema,
      partitionBy,
      comment,
      tblProperties,
      location
    ) {

  override private[conf] val dropTblStmt: Option[String] = createDropTblStmt()
  override private[conf] val alterTblStmt: Option[String] =
    createRecoverPartitionStmt()

  /** builds a complete DDL String for creating an external hive table as per
    * config object
    * @return
    *   the DDL String
    */
  override def initTableStmt(): String = {
    val (schemaAfterPartition, partitionBySet) = createPartitionedSchema()

    (withCreateStatement _)
      .andThen(withSchema(schemaStr = schemaAfterPartition.toDDL))
      .andThen(
        withPartitioning(partitionStr = generatePartitionString(partitionBySet))
      )
      .andThen(withComment(tblComment = comment))
      .andThen(withStoredAs(format = storedAs))
      .andThen(withLocation(path = location))
      .andThen(withTblProperties(properties = tblProperties))
      .apply(new StringBuilder())
      .toString()
  }

  /** creates a drop tbl statement if dropTable conf option is set to true */
  private def createDropTblStmt(): Option[String] = {
    if (dropTable.getOrElse(false)) {
      Some(s"DROP TABLE IF EXISTS $name")
    } else {
      None
    }
  }

  /** Adds a CREATE EXTERNAL TABLE clause to the table definition. */
  override protected def withCreateStatement(
      stmt: StringBuilder
  ): StringBuilder = {
    stmt ++= "CREATE EXTERNAL TABLE IF NOT EXISTS " + name + " ("
  }

  /** creates a ALTER TABLE ... RECOVER PARTITIONS statement if dropTable conf
    * option is set to true. Also, the table needs to be partitioned, otherwise
    * Spark throws an [[org.apache.spark.sql.AnalysisException]]
    */
  private def createRecoverPartitionStmt(): Option[String] = {
    def needsRecoverPartition(): Boolean = {
      dropTable.getOrElse(false) && partitionBy.isDefined
    }

    if (needsRecoverPartition()) {
      Some(s"ALTER TABLE $name RECOVER PARTITIONS")
    } else {
      None
    }
  }

  /** Adds a STORED AS clause with the specified format to the EXTERNAL HIVE
    * table definition.
    */
  protected def withStoredAs(
      format: Option[String]
  )(stmt: StringBuilder): StringBuilder = {
    format match {
      case Some(fmt) => stmt ++= s" STORED AS ${fmt.toUpperCase}"
      case None      => stmt
    }
  }
}

/** Allows initial creation of an Iceberg table upon pipeline start. */
final case class IcebergTable(
    override val name: String,
    override val jsonSchemaFile: Option[String],
    override val ddlSchema: Option[String],
    override val partitionBy: Option[List[String]],
    override val comment: Option[String],
    override val tblProperties: Option[Map[String, String]],
    override val location: Option[String]
) extends BaseTable(
      name,
      jsonSchemaFile,
      ddlSchema,
      partitionBy,
      comment,
      tblProperties,
      location
    ) {

  private val validFileFormats = Set("PARQUET", "AVRO", "ORC")

  /** builds a complete DDL String for creating an iceberg table as per config
    * object
    *
    * @return
    *   the DDL String
    */
  override def initTableStmt(): String = {
    val (schemaAfterPartition, partitionBySet) = createPartitionedSchema()

    (withCreateStatement _)
      .andThen(withSchema(schemaStr = schemaAfterPartition.toDDL))
      .andThen(withIcebergFormat)
      .andThen(
        withPartitioning(partitionStr = generatePartitionString(partitionBySet))
      )
      .andThen(withComment(tblComment = comment))
      .andThen(withLocation(path = location))
      .andThen(withTblProperties(properties = tblProperties))
      .apply(new StringBuilder())
      .toString()
  }

  /** Adds a CREATE TABLE clause to the table definition. */
  override protected def withCreateStatement(
      stmt: StringBuilder
  ): StringBuilder = {
    stmt ++= "CREATE TABLE IF NOT EXISTS " + name + " ("
  }

  /** Adds a USING clause with the specified format to the ICEBERG table
    * definition.
    */
  private def withIcebergFormat(stmt: StringBuilder): StringBuilder = {
    stmt ++= " USING iceberg"
  }

  /** Adds TBLPROPERTIES with the specified properties to the table definition.
    */
  override protected def withTblProperties(
      properties: Option[Map[String, String]]
  )(stmt: StringBuilder): StringBuilder = {

    val formatIsValid: Boolean = (for {
      format <- properties.flatMap(_.get("write.format.default"))
    } yield {
      isValidIcebergFileFormat(format)
      // if format not given, use default which is valid by definition
    }).getOrElse(true)

    // if format is valid, add all tbl properties --> this includes a format if given
    if (formatIsValid) {
      super.withTblProperties(properties)(stmt)
    } else {
      throw new IllegalArgumentException(
        s"iceberg tables only support $validFileFormats"
      )
    }
  }

  /** predicate checking if format is one of the admissible iceberg formats:
    * parquet, avro, orc
    *
    * @param format
    *   the file format
    * @return
    *   true if valid format, false otherwise
    */
  private def isValidIcebergFileFormat(format: String): Boolean = {
    validFileFormats.contains(format.toUpperCase)
  }

}
