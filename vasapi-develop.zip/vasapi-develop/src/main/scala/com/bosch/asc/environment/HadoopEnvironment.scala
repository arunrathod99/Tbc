/*
 * Copyright (c) 2019 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */

package com.bosch.asc.environment

import org.apache.hadoop.conf.Configuration

/** The `@transient lazy val hadoopConf` field is used to store the Hadoop
  * configuration. The `@transient` annotation indicates that this field should
  * not be serialized, and the `lazy` initialization ensures that the
  * configuration is computed on the first access. Example usage:
  * {{{
  *   class MyHadoopEnabledClass extends HadoopEnvironment {
  *     // Access Hadoop configuration
  *     val mySetting = hadoopConf.get("mySettingKey")
  *   }
  * }}}
  *
  * @see
  *   org.apache.hadoop.conf.Configuration
  */
trait HadoopEnvironment {
  @transient lazy val hadoopConf: Configuration = new Configuration()
}
