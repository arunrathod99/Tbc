/*
 * Copyright (c) 2009 - 2024 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */
package com.bosch.asc.vasapi.conf.sinks

import com.bosch.asc.vasapi.conf.Sink
import com.bosch.asc.vasapi.utils.VasapiConfUtils
import org.apache.spark.internal.Logging
import org.apache.spark.sql.SparkSession

/** HiveBatchSink is a class responsible for writing data to a Hive table using
  * the configured DataFrameWriter.
  * @param sink
  *   [[Sink]] object - passed via constructor injection due to pureconfig
  *   limitations
  * @param spark
  *   [[SparkSession]] to register dataframe
  * @param db
  *   the Hive database name
  * @param tb
  *   the Hive table name
  */
class HiveBatchSink(sink: Sink, spark: SparkSession, db: String, tb: String)
    extends Logging {

  // Hive options obtained from the sink configuration
  val hiveOptions: Map[String, String] =
    VasapiConfUtils.getValidOptionsByFormat(sink)

  /** register a hive sink
    */
  def execute(): Unit = {

    // Register DataFrame from the sink
    val df = sink.registerDF(spark)

    // Write the DataFrame to the Hive table using the configured options
    df.write
      .format(hiveOptions.getOrElse("fileFormat", ""))
      .mode(s"${sink.outputMode.getOrElse("")}")
      .insertInto(s"$db.$tb")

    logInfo(
      s"Data written to ${sink.dataBaseName}.${sink.tableName} table with ${sink.outputMode} mode"
    )
  }

}

object HiveBatchSink {

  /** To create a HiveBatchSink instance.
    *
    * @param sink
    *   the Sink instance containing configuration and data
    * @param spark
    *   the SparkSession instance
    * @return
    *   a new instance of HiveBatchSink
    * @throws IllegalArgumentException
    *   if database name or table name is not specified
    */
  def apply(sink: Sink, spark: SparkSession): HiveBatchSink = {
    (sink.dataBaseName, sink.tableName) match {
      case (Some(db), Some(tb)) => new HiveBatchSink(sink, spark, db, tb)
      case (_, _) =>
        throw new IllegalArgumentException(
          "dataBaseName and tableName have to be specified via conf for HiveSink in case executionMode is batch"
        )
    }
  }
}
