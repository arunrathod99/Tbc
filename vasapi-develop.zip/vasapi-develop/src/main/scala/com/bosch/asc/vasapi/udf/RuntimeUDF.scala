/* * Copyright (c) 2009, 2018 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt*/

package com.bosch.asc.vasapi.udf

import org.apache.spark.internal.Logging
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions.udf
import java.sql.Timestamp
import scala.collection.mutable.Map
import scala.reflect.runtime.universe._
import scala.tools.reflect.ToolBox

/** Provides functionality to compile scala term strings into udfs, which can be
  * called in the SQL context. I.e., you can configure UDFs and use them within
  * a Vasapi configuration file.
  */
@SuppressWarnings(Array("AsInstanceOf"))
object RuntimeUDF extends Logging with Serializable {

  /** Method which takes a term containing the string representation of a Scala
    * anonymous function and transforms it into a typed Spark udf
    * @param term
    *   String represntation of a scala anonymous function
    * @return
    *   UserDefinedFunction represnting the udf
    */

  def createTypedUdf(term: String): UserDefinedFunction = {
    // get a handle to the scala reflection toolbox
    lazy val tb = scala.reflect.runtime.universe
      .runtimeMirror(getClass.getClassLoader)
      .mkToolBox()
    // extract a typed Tree from a term String through reflection and derive function type of a term
    val funcType = tb.typecheck(tb.parse(term)).tpe
    // evaluate a term String into an anonymous function of type Any through reflection
    lazy val reflectedFunction = {
      lazy val toolbox = scala.reflect.runtime.universe
        .runtimeMirror(getClass.getClassLoader)
        .mkToolBox()
      lazy val tree = toolbox.parse(term)
      toolbox.compile(tree)()
    }
    logInfo(s"creating udf of type ${funcType.toString}")

    /*
     * This snippet converts a generic function of type Any to a typed Spark udf.
     * Note that this only works for function type patterns contained in the match case statements.
     * E.g. a function of type (Int, Int) => String could not be interpreted and would result
     * in a NoSuchMethodException.
     *
     * The following function types are used in vasapi implementations but not reflected here yet:
     * MES: val getResultColumn = (Double, String, String) => String
     * RADAR: val rotate_value = (Seq[String], Seq[String]) => String
     *
     */
    funcType match {
      case t if t =:= typeOf[Int => Int] =>
        logDebug("matched udf of type Int => Int")
        val funcDef = new Function1[Int, Int] with Serializable {
          def apply(x0: Int): Int =
            reflectedFunction.asInstanceOf[(Int) => Int](x0)
        }
        udf(funcDef)

      case t if t =:= typeOf[String => String] =>
        logDebug("matched udf of type String => String")
        val funcDef = new Function1[String, String] with Serializable {
          def apply(x0: String): String =
            reflectedFunction.asInstanceOf[(String) => String](x0)
        }
        udf(funcDef)

      case t if t =:= typeOf[(String, String) => String] =>
        logDebug("matched udf of type (String, String) => String")
        val funcDef = new Function2[String, String, String] with Serializable {
          def apply(x0: String, x1: String): String =
            reflectedFunction.asInstanceOf[(String, String) => String](x0, x1)
        }
        udf(funcDef)

      case t if t =:= typeOf[String => Boolean] =>
        logDebug("matched udf of type String => Boolean")
        val funcDef = new Function1[String, Boolean] with Serializable {
          def apply(x0: String): Boolean =
            reflectedFunction.asInstanceOf[String => Boolean](x0)
        }
        udf(funcDef)

      case t if t =:= typeOf[Int => Boolean] =>
        logDebug("matched udf of type Int => Boolean")
        val funcDef = new Function1[Int, Boolean] with Serializable {
          def apply(x0: Int): Boolean =
            reflectedFunction.asInstanceOf[Int => Boolean](x0)
        }
        udf(funcDef)

      case t if t =:= typeOf[(String) => List[String]] =>
        logDebug("matched udf of type  String => List[String]")
        val funcDef = new Function1[String, List[String]] with Serializable {
          def apply(x0: String): List[String] =
            reflectedFunction.asInstanceOf[(String) => List[String]](x0)
        }
        udf(funcDef)

      case t if t =:= typeOf[(String, String) => List[String]] =>
        logDebug("matched udf of type String, String => List[String]")
        val funcDef = new Function2[String, String, List[String]]
          with Serializable {
          def apply(x0: String, x1: String): List[String] = reflectedFunction
            .asInstanceOf[(String, String) => List[String]](x0, x1)
        }
        udf(funcDef)

      case t if t =:= typeOf[(String, String) => Timestamp] =>
        logDebug("matched udf of type String, String => Timestamp")
        val funcDef = new Function2[String, String, Timestamp]
          with Serializable {
          def apply(x0: String, x1: String): Timestamp = reflectedFunction
            .asInstanceOf[(String, String) => Timestamp](x0, x1)
        }
        udf(funcDef)

      case t if t =:= typeOf[(Double, String, String) => String] =>
        logDebug("matched udf of type Double, String, String => String")
        val funcDef = new Function3[Double, String, String, String]
          with Serializable {
          def apply(x0: Double, x1: String, x2: String): String =
            reflectedFunction
              .asInstanceOf[(Double, String, String) => String](x0, x1, x2)
        }
        udf(funcDef)

      case t
          if t =:= typeOf[
            (String, Seq[String], String) => Map[String, String]
          ] =>
        logDebug(
          "matched udf of type String, Seq[String], String => Map[String,String]"
        )
        val funcDef =
          new Function3[String, Seq[String], String, Map[String, String]]
            with Serializable {
            def apply(
                x0: String,
                x1: Seq[String],
                x2: String
            ): Map[String, String] =
              reflectedFunction.asInstanceOf[
                (String, Seq[String], String) => Map[String, String]
              ](x0, x1, x2)
          }
        udf(funcDef)

      case t if t =:= typeOf[(Seq[String], Int, Int) => Seq[String]] =>
        logDebug("matched udf of type Seq[String], Int, Int => Seq[String]")
        val funcDef = new Function3[Seq[String], Int, Int, Seq[String]]
          with Serializable {
          def apply(x0: Seq[String], x1: Int, x2: Int): Seq[String] =
            reflectedFunction
              .asInstanceOf[(Seq[String], Int, Int) => Seq[String]](x0, x1, x2)
        }
        udf(funcDef)

      case t if t =:= typeOf[(Seq[String], Seq[String]) => String] =>
        logDebug("matched udf of type Seq[String], Seq[String] => String")
        val funcDef = new Function2[Seq[String], Seq[String], String]
          with Serializable {
          def apply(x0: Seq[String], x1: Seq[String]): String =
            reflectedFunction
              .asInstanceOf[(Seq[String], Seq[String]) => String](x0, x1)
        }
        udf(funcDef)

      case _ =>
        throw new NoSuchMethodException(
          s"Cannot register udf of type ${funcType.toString}"
        )
    }
  }
}
