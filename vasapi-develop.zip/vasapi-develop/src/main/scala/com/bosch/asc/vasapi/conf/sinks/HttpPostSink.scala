/*
 * Copyright (c) 2009, 2018 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */
package com.bosch.asc.vasapi.conf.sinks

import org.apache.spark.internal.Logging
import org.apache.spark.sql.DataFrame

/** HttpPostSink object provides a builder for creating a function to send a
  * DataFrame content via HTTP POST.
  *
  * The builder takes options, particularly the URL, as input and returns a
  * function that sends the content of a DataFrame via HTTP POST to the
  * specified URL.
  *
  * This HttpPostSink assumes the use of Apache Spark for DataFrame operations.
  */
object HttpPostSink extends Logging {

  /** Builder method for creatinga function to send content of a dataframe via
    * HTTP POST
    * @param options
    *   Options for HTTP Post
    * @return
    *   A function that takes dataframe and a batchId,extracts the contents and
    *   send it via HTTP POST
    */
  def builder(
      options: Option[Map[String, String]]
  ): (DataFrame, Long) => Unit = {
    val urlString = options match {
      case Some(op) => op("url")
      case None     => ""
    }

    (batchDF: DataFrame, batchId: Long) => {
      val text = batchDF.collect().map(row => row.getString(0)).mkString("\n")
      val content = "{'text':'<pre>" + text + "</pre>'}"
      val postData = content.getBytes(java.nio.charset.StandardCharsets.UTF_8)
      val url = new java.net.URL(urlString)
      val conn = url.openConnection match {
        case con: java.net.HttpURLConnection => con
      }
      conn.setDoOutput(true)
      conn.setInstanceFollowRedirects(false)
      conn.setRequestMethod("POST")
      conn.setRequestProperty("Content-Type", "Content-Type: application/json")
      conn.setRequestProperty(
        "Content-Length",
        Integer.toString(postData.length)
      )
      conn.setRequestProperty("charset", "utf-8")
      conn.setUseCaches(false)
      val wr = new java.io.DataOutputStream(conn.getOutputStream())
      wr.write(postData)

      val resp = conn.getResponseCode
      logInfo("POST message sent. Response code " + resp.toString + ".")
    }
  }
}
