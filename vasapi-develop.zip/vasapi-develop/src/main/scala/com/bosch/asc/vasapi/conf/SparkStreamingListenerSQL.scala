/*
 * Copyright (c) 2020, 2023 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */
package com.bosch.asc.vasapi.conf

import org.apache.spark.internal.Logging
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.streaming.StreamingQueryListener

/** Listener interface to extend logging information with data from Spark SQL
  * streaming queries.
  */
class SparkStreamingListenerSQL(
    spark: SparkSession,
    sinkId: java.util.UUID,
    sql: String
) extends StreamingQueryListener
    with Logging {

  /** Invoked when a streaming query is started. This implementation logs a
    * message indicating that the listener is skipped during query startup
    */
  def onQueryStarted(event: StreamingQueryListener.QueryStartedEvent): Unit = {
    logInfo(
      s"skipping StreamingQueryListener while query (id: ${event.id}, name: ${event.name}) starts "
    )
  }

  /** Invoked when a streaming query makes progress. This implementation
    * executes the SQL statement if the progress event is associated with the
    * specified sink identifier.
    *
    * @param event
    *   QueryProgressEvent containing information about the query progress.
    */
  def onQueryProgress(
      event: StreamingQueryListener.QueryProgressEvent
  ): Unit = {
    if (event.progress.id == sinkId) {
      logDebug(s"executing StreamingQueryListener statement: ${this.sql}")
      spark.sql(sql).show()
    }
  }

  /** Invoked when a streaming query is terminated. This implementation logs a
    * message indicating that the listener is skipped during query termination.
    *
    * @param event
    *   QueryTerminatedEvent containing information about the terminated query.
    */
  def onQueryTerminated(
      event: StreamingQueryListener.QueryTerminatedEvent
  ): Unit = {
    logInfo(
      s"skipping StreamingQueryListener while query (id: ${event.id}) is shut down due to ${event.exception}"
    )
  }
}
