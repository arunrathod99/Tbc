package com.bosch.asc.vasapi.udf

import org.apache.spark.internal.Logging
import org.apache.spark.sql.expressions.UserDefinedFunction

/** base trait for registering udfs in vasapi based pipelines */
trait VasapiUDF extends Logging {

  val udfs: Map[String, UserDefinedFunction]

  /** Registers the udfs to spark
    * @param spark
    *   Spark Session object
    */
  def register()(implicit spark: org.apache.spark.sql.SparkSession): Unit = {
    for ((name, udf) <- udfs) {
      spark.udf.register(name, udf)
      logInfo(s"Registered UDF: $name")
    }
  }

}
