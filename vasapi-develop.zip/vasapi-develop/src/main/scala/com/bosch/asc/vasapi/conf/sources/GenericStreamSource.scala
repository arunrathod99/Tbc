/*
 *  Copyright (c) 2023 Robert Bosch GmbH and its subsidiaries.
 *  This program and the accompanying materials are made available under
 *  the terms of the Bosch Internal Open Source License v4
 *  which accompanies this distribution, and is available at
 *  http://bios.intranet.bosch.com/bioslv4.txt
 */

package com.bosch.asc.vasapi.conf.sources

import com.bosch.asc.vasapi.utils.VasapiConfUtils
import com.bosch.asc.vasapi.conf.Source
import org.apache.spark.internal.Logging
import org.apache.spark.sql.{DataFrame, SparkSession}

/** models a generic source for a spark structured streaming query
  * @param s
  *   [[Source]] configuration for the generic streaming source
  */
class GenericStreamSource(s: Source) extends Logging {

  /** Registers a generic streaming source, with optional schema.
    *
    * @param spark
    *   SparkSession to register the source
    * @return
    *   A DataFrame representing the registered streaming source.
    */
  private[conf] def registerSource(spark: SparkSession): DataFrame = {
    val schemaStruct = s.createSourceSchema(s.ddlSchema, s.jsonSchemaFile)

    (s.load, schemaStruct) match {
      case (Some(path), Some(schemaStructType)) =>
        logInfo(
          s"registered streaming source loading data from $path using the following schema: ${schemaStructType.toString} "
        )

        spark.readStream
          .format(s.format)
          .schema(schemaStructType)
          .options(VasapiConfUtils.getValidOptionsByFormat(s))
          .load(path)

      case (Some(path), None) =>
        logInfo(
          s"registered streaming source loading data from $path without explicitly passing schema"
        )

        spark.readStream
          .format(s.format)
          .options(VasapiConfUtils.getValidOptionsByFormat(s))
          .load(path)

      case (None, Some(schemaStructType)) =>
        logInfo(
          s"registered streaming source using the following schema: ${schemaStructType.toString}"
        )

        spark.readStream
          .format(s.format)
          .schema(schemaStructType)
          .options(VasapiConfUtils.getValidOptionsByFormat(s))
          .load()

      case (None, None) =>
        logInfo("registered streaming source without schema")

        spark.readStream
          .format(s.format)
          .options(VasapiConfUtils.getValidOptionsByFormat(s))
          .load()
    }
  }

}

/** Companion object
  */

object GenericStreamSource {

  /** Creates a new instance of [[GenericStreamSource]] with the provided
    * [[Source]] configuration.
    *
    * @param s
    *   The [[Source]] configuration for the generic streaming source.
    * @return
    *   A new [[GenericStreamSource]] instance.
    */
  def apply(s: Source): GenericStreamSource = {
    new GenericStreamSource(s)
  }

}
