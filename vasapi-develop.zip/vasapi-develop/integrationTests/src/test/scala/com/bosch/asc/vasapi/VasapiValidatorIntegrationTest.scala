/* * Copyright (c) 2024 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */

package com.bosch.asc.vasapi

import com.bosch.asc.vasapi.conf._
import com.bosch.asc.vasapi.validation.VasapiValidator
import org.scalatest.matchers.should.Matchers
import org.apache.spark.internal.Logging
import org.scalatest.{BeforeAndAfter, BeforeAndAfterAll}

/**
 * this class tests the basic functionality of the VasapiValidator class using a more complex pipeline example
 * vs what is used in unit tests.
 *
 * Here, only logical and syntactical correctness are tested by VasapiValidator's methods such as
 * validateTransformations() and allTransformationsValid().
 *
 * In a typical pipeline validation setup, this would be combined with tests for the actual data transformations.
 * Such tests can be found in the test class [[VasapiDataValidationTest]].
 */
class VasapiValidatorIntegrationTest extends UnitSpec with Matchers with BeforeAndAfter with BeforeAndAfterAll with Logging {

  before {
    dropViewsTables()
  }

  override def afterAll(): Unit = {
    spark.stop()
  }

  /**
   * fixture creating a [[Vasapi]] object
   */
  trait TestSetup {
    val vasapiObj: Vasapi = Pipeline.readVasapiConfig(Some("mws-application.conf"))
  }

  /**
   * fixture creating a [[Vasapi]] object with an error in the configuration
   */
  trait ErrorTestSetup {
    val vasapiObj: Vasapi = Pipeline.readVasapiConfig(Some("mws-error-application.conf"))
  }

  /*
   * test suite to be run against mws pipeline configuration templates
   */
  ("loading the main application template" should "resolve all config dependencies") in {
    new TestSetup {
      val queries: List[Query] = vasapiObj.queries
      assert(queries.length > 10)
      }
    }

  it should "resolve the elements of the vasapi object correctly" in {
    new TestSetup {

      val queries: List[Query] = vasapiObj.queries
      val queryNames: List[String] = queries.map(q => q.name)

      val views: List[View] = vasapiObj.views
      val viewNames: List[String] = views.map(v => v.name)

      logInfo(s"number of views is: ${views.length}")

      assert(
        viewNames.forall(vn => queryNames.contains(vn))
          && queryNames.length - viewNames.length >= 0)
    }
  }

  ("the validateTransformations" should "succeed if run against the original config tree") in {
    new TestSetup {
      val confValidator: VasapiValidator = VasapiValidator(vasapiObj)
      assert(confValidator.validateTransformations().isSuccess)
    }
  }

  (it should "successfully parse all sources & views if the source is replace with a test source") in {
    new TestSetup {
      val confValidator: VasapiValidator = VasapiValidator(vasapiObj)
      confValidator.allTransformationsValid should be(true)
    }
  }

  (it should "produce a Failure for an invalid configuration") in {
    new ErrorTestSetup {
      val confValidator: VasapiValidator = VasapiValidator(vasapiObj)
      assert(confValidator.validateTransformations().isFailure)
    }
  }
}

