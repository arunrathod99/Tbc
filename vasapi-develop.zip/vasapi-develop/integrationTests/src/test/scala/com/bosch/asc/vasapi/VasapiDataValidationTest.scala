/* * Copyright (c) 2024 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */

package com.bosch.asc.vasapi

import com.bosch.asc.vasapi.validation.VasapiValidator
import org.apache.spark.internal.Logging
import org.apache.spark.sql.DataFrame
import org.scalatest.BeforeAndAfter
import org.scalatest.BeforeAndAfterAll
import org.scalatest.matchers.should.Matchers

/**
 * Integration test for the VasapiValidator. While [[VasapiValidatorIntegrationTest]] focuses on syntactical and logical
 * correctness of the sequence of data transformations, this test suite validates the transformations against
 * a set of test data.
 *
 * We simulate source data and apply the sequence of data transformations on it.
 * Then, we run number of spark.sql(...) queries to validate of the data is transformed correctly.
 */
class VasapiDataValidationTest extends UnitSpec with Matchers with BeforeAndAfter with BeforeAndAfterAll with Logging {

  override def beforeAll(): Unit = {
    // delete any remaining artifacts from previous tests
    dropViewsTables()
  }

  override def afterAll(): Unit = {
    spark.stop()
  }

  /**
   * Test setup for all tests in this class. Run in a test setup itself, so that beforeAll does not
   * clean up views and tables before the remaining tests are run.
   *
   * For efficiency, we do not follow the usual fixture setup using Traits. This would mean that the whole
   * test setup, including the SparkSession, would be created for each test. This is not necessary.
   */
  ("setting up the validation" should "not produce any errors and work for all subsequent tests") in {
    val vasapiObj: Vasapi = Pipeline.readVasapiConfig(Some("mws-application.conf"))

    val confValidator: VasapiValidator = VasapiValidator(
      vasapiConfig = vasapiObj,
      replaceSources = Map("mwsSource" -> "test-data/")
    )

    confValidator.validateTransformations()
  }

  ("querying the row" should "return a df with two rows") in {
    val sourceDF: DataFrame = spark.sql("SELECT * FROM mwsSource")

    sourceDF.show()
    sourceDF.count() should be (2)
  }

  ("skipping schema validation" should "result in an empty df for invalid data") in {
    spark.sql("SELECT * FROM mwsInvalidSchemaRecords").count() should be (0)
  }

  ("mwsParsedArrayStruct" should "have two rows") in {
    // before exploding arrays
    // both messages have one row tag only
    val parsedDF: DataFrame = spark.sql("SELECT * FROM mwsParsedArrayStruct")
    parsedDF.show()

    parsedDF.count() should be (2)
  }

  /**
   before exploding arrays

   both messages have multiple test steps --> this view covers msgs with one test step only, i.e. should have 0 rows

   added condition to filter out null records from further processing:
   {{{
   WHERE parsed.row.TTNR IS NOT NULL
   }}}
   */
  ("mwsParsedWithoutArrayStruct" should "not contain any rows") in {
    val parsedDF: DataFrame = spark.sql("SELECT * FROM mwsParsedWithoutArrayStruct")
    parsedDF.show()

    parsedDF.count() should be (0)
  }

  ("the final view for mws_xml" should "have two rows") in {
    val finalDF: DataFrame = spark.sql("SELECT * FROM mwsCastedUnion")
    finalDF.show()

    finalDF.count() should be (2)
  }

  ("the final view" should "have 9 rows") in {
    val finalDF: DataFrame = spark.sql("SELECT * FROM mwsExplodedTeststepsArray")
    finalDF.show()

    // test file 1 has 6 test steps --> 6 rows
    // test file 2 has 3 test steps --> 3 rows
    finalDF.count() should be (9)
  }
}
