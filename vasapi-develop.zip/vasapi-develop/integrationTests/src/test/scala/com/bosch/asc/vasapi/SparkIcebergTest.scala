/*
 * Copyright (c) 2024 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */

package com.bosch.asc.vasapi

import org.apache.spark.SparkConf
import org.apache.spark.internal.Logging
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.scalatest.flatspec.AnyFlatSpec
import org.scalatest.{BeforeAndAfter, BeforeAndAfterAll}
import org.scalatest.matchers.should.Matchers

class SparkIcebergTest extends AnyFlatSpec with Matchers
  with BeforeAndAfter with BeforeAndAfterAll with Logging {

  val warehouseDir: String = "spark-warehouse/test"

  lazy val conf: SparkConf = new SparkConf()
  // this needs to match the version of iceberg used in Dependencies.scala
  .set("spark.jars.packages", "org.apache.iceberg:iceberg-spark-runtime-3.3_2.12:1.3.0.3.3.7190.3-1")
  .set("spark.sql.extensions", "org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions")
  .set("spark.sql.catalog.spark_catalog", "org.apache.iceberg.spark.SparkSessionCatalog")
  .set("spark.sql.catalog.local", "org.apache.iceberg.spark.SparkCatalog")
  .set("spark.sql.catalog.local.type", "hadoop")
  .set("spark.sql.catalog.local.warehouse", warehouseDir)

  implicit lazy val spark: SparkSession =
    SparkSession
      .builder()
      .master("local[*]")
      .config(conf)
      .enableHiveSupport()
      .getOrCreate()


  override def afterAll(): Unit = {
    spark.stop()
  }


  ("instantiating a spark session with iceberg support" should "allow to create an iceberg table") in {
    spark.sql("CREATE TABLE local.db.table (id int, data string) USING iceberg").show()
    spark.sql("show tables in local.db").count() should be(1)
  }

  (it should "allow to insert data into an iceberg table") in {
    spark.sql("INSERT INTO local.db.table VALUES (1, 'a'), (2, 'b')")
    val df: DataFrame = spark.sql("SELECT * FROM local.db.table")
    df.count() should be(2)
  }

  (it should "allow to insert more data into a table") in {
    spark.sql("INSERT INTO local.db.table VALUES (3, 'a'), (4, 'b')")
    val df: DataFrame = spark.sql("SELECT * FROM local.db.table")
    df.count() should be(4)
  }

  (it should "allow to read data from table with spark read format iceberg") in {
    spark.read.format("iceberg").load("local.db.table").createOrReplaceTempView("source")
    val df: DataFrame = spark.sql("SELECT * from source")
    df.count() should be(4)
  }


  (it should "Merge into allows merging and inserting data when it does not match the target table data") in {
    spark.sql("CREATE TABLE local.db.table2 (id int, data string) USING iceberg").show()
    spark.sql("INSERT INTO local.db.table2 VALUES (3, 'a'), (5, 'c')")
    // (3, 'a') would be a duplicate --> should not be written
    spark.sql(
      """MERGE INTO local.db.table2 t
        |USING (SELECT * FROM source) t2
        |ON t.id = t2.id
        |WHEN NOT MATCHED THEN INSERT *"""
        .stripMargin)

    val df: DataFrame = spark.sql("SELECT * FROM local.db.table2")
    df.count() should be(5)
  }
}